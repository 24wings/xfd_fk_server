member 
- mobi 
+ type
+ level 枚举    
+ type
status 
* 正常
* 注销
* 冻结
* s


Card
creatorEpId 

联合主键 (mktId,cardNo)


ReachargeWithDraw
+ mkt

FeeList
creatorEpId;
createTime

PayFeeMember

PayFeeRecord
+ startChargeDt
+ endChargeDt


MemberLog
comment
subjectId

MemberAccountLog
comment
subjectId