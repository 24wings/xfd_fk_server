package com.fastsun.market.entity.transOrder;

import com.fastsun.framework.entity.queryTemplate.EntityMetaData;
import com.fastsun.market.entity.enums.CreateWay;
import com.fastsun.market.entity.enums.OrderStatus;
import com.fastsun.market.entity.enums.PayType;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
@Table(name = "b_order",uniqueConstraints = {@UniqueConstraint(columnNames = "orderNo")})
@Entity
@EntityMetaData(objectName = "order",groupName = "sellerMemName",pkKey = "id")
public class Order implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String orderNo;
    //买卖双方信息
    private Integer buyerMemId;//买方id
    private Integer buyerCustId;//买方操作员
    private String buyerMemNo;
    private String buyerInfo;//匿名买方信息
    private Integer sellerMemId;//卖方id
    private String sellerMemNo;
    private String sellerMemName;
    private Integer sellerCustId;//买方操作员
    private BigDecimal apAmt;//应付货款
    private BigDecimal payAmt;//交易货款
    private BigDecimal totalWeight;
    private BigDecimal buyerFee;//买方手续费
    private BigDecimal sellerFee;// 卖方手续费

    @Enumerated(EnumType.ORDINAL)
    private PayType payType;//支付方式
//    @Convert(converter = OrderStatus.Convert.class)
    @Enumerated(EnumType.ORDINAL)
    private OrderStatus status;//订单状态
    private CreateWay createWay;//订单来源
    private Integer mktId;//所属市场id
    private Integer transAreaId;
    private Date createTime;//创建时间
    private Integer creatorId;//创建人Id

    private String creator;//创建人
    private Date actTime;//结算时间
    private Integer actorId;//结算员Id
    private String actor;//结算员
    private String remark;

    @OneToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER, mappedBy = "order", orphanRemoval = true)
    private List<OrderDetail> orderDetails;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSellerMemId() {
        return sellerMemId;
    }

    public void setSellerMemId(Integer sellerMemId) {
        this.sellerMemId = sellerMemId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Integer getBuyerMemId() {
        return buyerMemId;
    }

    public void setBuyerMemId(Integer buyerMemId) {
        this.buyerMemId = buyerMemId;
    }

    public Integer getBuyerCustId() {
        return buyerCustId;
    }

    public void setBuyerCustId(Integer buyerCustId) {
        this.buyerCustId = buyerCustId;
    }

    public String getBuyerInfo() {
        return buyerInfo;
    }

    public void setBuyerInfo(String buyerInfo) {
        this.buyerInfo = buyerInfo;
    }

    public String getSellerMemNo() {
        return sellerMemNo;
    }

    public void setSellerMemNo(String sellerMemNo) {
        this.sellerMemNo = sellerMemNo;
    }

    public Integer getSellerCustId() {
        return sellerCustId;
    }

    public void setSellerCustId(Integer sellerCustId) {
        this.sellerCustId = sellerCustId;
    }

    public BigDecimal getApAmt() {
        return apAmt;
    }

    public void setApAmt(BigDecimal apAmt) {
        this.apAmt = apAmt;
    }

    public BigDecimal getPayAmt() {
        return payAmt;
    }

    public void setPayAmt(BigDecimal payAmt) {
        this.payAmt = payAmt;
    }

    public BigDecimal getBuyerFee() {
        return buyerFee;
    }

    public void setBuyerFee(BigDecimal buyerFee) {
        this.buyerFee = buyerFee;
    }

    public BigDecimal getSellerFee() {
        return sellerFee;
    }

    public void setSellerFee(BigDecimal sellerFee) {
        this.sellerFee = sellerFee;
    }

    public PayType getPayType() {
        return payType;
    }

    public void setPayType(PayType payType) {
        this.payType = payType;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getActTime() {
        return actTime;
    }

    public void setActTime(Date actTime) {
        this.actTime = actTime;
    }

    public Integer getActorId() {
        return actorId;
    }

    public void setActorId(Integer actorId) {
        this.actorId = actorId;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public List<OrderDetail> getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(List<OrderDetail> orderDetails) {
        this.orderDetails = orderDetails;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public CreateWay getCreateWay() {
        return createWay;
    }

    public void setCreateWay(CreateWay createWay) {
        this.createWay = createWay;
    }

    public Integer getTransAreaId() {
        return transAreaId;
    }

    public void setTransAreaId(Integer transAreaId) {
        this.transAreaId = transAreaId;
    }

    public BigDecimal getTotalWeight() {
        return totalWeight;
    }

    public void setTotalWeight(BigDecimal totalWeight) {
        this.totalWeight = totalWeight;
    }

    public String getBuyerMemNo() {
        return buyerMemNo;
    }

    public void setBuyerMemNo(String buyerMemNo) {
        this.buyerMemNo = buyerMemNo;
    }

    public String getSellerMemName() {
        return sellerMemName;
    }

    public void setSellerMemName(String sellerMemName) {
        this.sellerMemName = sellerMemName;
    }

    public Order() {
    }

    public void addOrderDetail(OrderDetail orderDetail){
        if (!orderDetails.contains(orderDetail)){
            orderDetail.setOrder(this);
            this.orderDetails.add(orderDetail);
        }
    }
}
