package com.fastsun.market.entity.synthesizeFee;

import javax.persistence.*;

import com.fastsun.market.entity.enums.PayType;
import org.hibernate.annotations.Cascade;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "payfee_record")
public class PayFee implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false)
    private String title;
    @Column(nullable = false)
    private Integer subjectId;
    @Column(nullable = false)
    private Integer memberId;
    @Column(nullable = false)
    private BigDecimal arAmount;
    @Column(nullable = false)
    private BigDecimal realAmount;
    private PayType payType;// 支付方式
    private String remark;

    private Integer mktId;// 所属市场id
    private Date createTime;// 创建时间
    private Integer creatorId;// 创建人Id
    private String creator;// 创建人

    private Date actTime;// 结算时间
    private Integer actorId;// 结算员Id
    private String actor;// 结算员
    // @JsonIgnore
    // @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy =
    // "payfeeRecord", orphanRemoval = true)
    // @Cascade(value = { org.hibernate.annotations.CascadeType.ALL,
    // org.hibernate.annotations.CascadeType.DELETE,
    // org.hibernate.annotations.CascadeType.SAVE_UPDATE })
    @Transient
    public List<PayFeeDetail> payDetails;

    public PayFee() {
    }

    public void addPayFeeList(PayFeeDetail payDetail) {
        if (!payDetails.contains(payDetail)) {
            // payDetail.setPayFee(this);
            this.payDetails.add(payDetail);
        }
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    /**
     * @return the arAmount
     */
    public BigDecimal getArAmount() {
        return arAmount;
    }

    /**
     * @param arAmount the arAmount to set
     */
    public void setArAmount(BigDecimal arAmount) {
        this.arAmount = arAmount;
    }

    /**
     * @return the realAmount
     */
    public BigDecimal getRealAmount() {
        return realAmount;
    }

    /**
     * @param realAmount the realAmount to set
     */
    public void setRealAmount(BigDecimal realAmount) {
        this.realAmount = realAmount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getActTime() {
        return actTime;
    }

    public void setActTime(Date actTime) {
        this.actTime = actTime;
    }

    public Integer getActorId() {
        return actorId;
    }

    public void setActorId(Integer actorId) {
        this.actorId = actorId;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public List<PayFeeDetail> getPayDetails() {
        return payDetails;
    }

    public void setPayDetails(List<PayFeeDetail> payDetails) {
        this.payDetails = payDetails;
    }

    public PayType getPayType() {
        return payType;
    }

    public void setPayType(PayType payType) {
        this.payType = payType;
    }
}