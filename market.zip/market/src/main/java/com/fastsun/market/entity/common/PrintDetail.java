package com.fastsun.market.entity.common;

/**
 * Created by lwm on 2017/2/16.
 */
public class PrintDetail {
    String Goodsname;

    String Goodscount;

    String Weight;

    String Goodsamount;
String Goodsprice;
    public String getGoodsname() {
        return Goodsname;
    }

    public void setGoodsname(String goodsname) {
        Goodsname = goodsname;
    }
    public String getgoodsprice() {
        return Goodsprice;
    }

    public void setgoodsprice(String goodsprice) {
        Goodsprice = goodsprice;
    }
    public String getGoodscount() {
        return Goodscount;
    }

    public void setGoodscount(String goodscount) {
        Goodscount = goodscount;
    }

    public String getWeight() {
        return Weight;
    }

    public void setWeight(String weight) {
        Weight = weight;
    }

    public String getGoodsamount() {
        return Goodsamount;
    }

    public void setGoodsamount(String goodsamount) {
        Goodsamount = goodsamount;
    }


}