package com.fastsun.market.service.impl;

import com.fastsun.market.entity.common.TransArea;
import com.fastsun.market.jpa.TransAreaJPA;
import com.fastsun.framework.jpa.base.SimplePageBuilder;
import com.fastsun.framework.jpa.base.SimpleSpecificationBuilder;
import com.fastsun.framework.service.impl.BaseServiceImpl;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
@Service
public class TransAreaServiceImpl{


}
