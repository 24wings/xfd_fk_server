package com.fastsun.market.entity.member;
import com.fastsun.framework.entity.queryTemplate.EntityMetaData;
import com.fastsun.framework.entity.queryTemplate.FieldMetaData;
import com.fastsun.market.entity.enums.PayType;
import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
@Table(name = "b_recharge_withdraw",uniqueConstraints = {@UniqueConstraint(columnNames = "billNo")})
@Entity
@EntityMetaData(objectName="RechargeWithDraw",pkKey ="id")
public class RechargeWithDraw implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String billNo;
    @Enumerated(EnumType.ORDINAL)
    private BusinessType businessType;//是否存款
    @FieldMetaData(recno=7,alias = "支付方式",isQuery = true,displayWidth = 30)
    private PayType payType;//支付方式
    @FieldMetaData(recno=1,alias = "商户id",isQuery = true,displayWidth = 30)
    private Integer memberId;
    @FieldMetaData(recno=2,alias = "用户id",isQuery = false,displayWidth = 30)
    private Integer customerId;
    @FieldMetaData(recno=3,alias = "金额",isQuery = false,displayWidth = 30)
    private BigDecimal amount;
    @FieldMetaData(recno=4,alias = "余额",isQuery = false,displayWidth = 30)
    private BigDecimal afterBalAmt;

    private Integer mktId;//所属市场id
    private Date createTime;//创建时间
    private Integer creatorId;//创建人Id
    private String creator;//创建人
    private String memberName;//充值会员名
    private String idCardNo;//会员身份证号
    private Date actTime;//结算时间
    private Integer actorId;//结算员Id
    private String actor;//结算员
    private String remark;
    @Transient
    private String payPassword;
    private String cardNo;

    public RechargeWithDraw(){}

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public BusinessType getBusinessType() {
        return businessType;
    }

    public void setBusinessType(BusinessType businessType) {
        this.businessType = businessType;
    }

    public PayType getPayType() {
        return payType;
    }

    public void setPayType(PayType payType) {
        this.payType = payType;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getAfterBalAmt() {
        return afterBalAmt;
    }

    public void setAfterBalAmt(BigDecimal afterBalAmt) {
        this.afterBalAmt = afterBalAmt;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getActTime() {
        return actTime;
    }

    public void setActTime(Date actTime) {
        this.actTime = actTime;
    }

    public Integer getActorId() {
        return actorId;
    }

    public void setActorId(Integer actorId) {
        this.actorId = actorId;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getPayPassword() {
        return payPassword;
    }

    public void setPayPassword(String payPassword) {
        this.payPassword = payPassword;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo;
    }

    public enum BusinessType{
        RECHARGE,WITHDRAW
    }
}
