package com.fastsun.market.bean;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Setter
@Getter
@NoArgsConstructor
public class AccountRepayRq {

    private Integer deptId;
    private Integer memberId;
    @NotNull
    private BigDecimal repayAmt;
    private String payPassword;
}
