package com.fastsun.market.entity.enums;

import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.Member;

public enum CertWayEnum {

    WEB_PASS_NOAUTH, APP_AUTH, FOURELEMENTS_AUTH;
    public static String getLogString(CertWayEnum logEnum, Member member) {
        switch (logEnum) {
        case WEB_PASS_NOAUTH:
            if (member.getMemberType().equals(MemberType.PERSONAL)) {
                return "个体用户:" + member.getName() + "  web柜台无认证成功 \n 身份证号" + member.getIdCardNo();
            } else {
                return "企业用户:" + member.getName() + "  web柜台企业无人认证成功 \n 身份证号" + member.getIdCardNo();
            }
        default:
            return "app实名认证";
        }
    }
}
