package com.fastsun.market.controller.app;

import cn.jpush.api.push.PushResult;

import java.util.HashMap;
import java.util.Map;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.market.entity.enums.ViewEnum;
import com.fastsun.market.service.impl.JPushServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

//import cn.jmessage.api.JMessageClient;
import cn.jpush.api.*;
import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;

//import java.util.List;

@Api(description = "极光推送", tags = { "market.app.Im" })
@RestController
@RequestMapping("/app/im")
public class IMController extends BaseController {
        @Autowired
        private JPushServiceImpl jpushServiceImpl;

        @ApiOperation(value = "获取会员id", notes = "", httpMethod = "Get")
        @RequestMapping(value = "/mob", method = RequestMethod.GET)
        public ResponseBean sendMsg() throws Exception {
                ResponseBean res = null;
                JPushClient client = new JPushClient("4224dcca3494ab5279be4705", "35f14808673591baceed2d61");
                IosNotification iosNotification = IosNotification.newBuilder().setAlert("alert").setBadge(5)
                                .setSound("happy").addExtra("from", "JPush").addExtra("from", "JPush").build();
                AndroidNotification androidNotification = AndroidNotification.newBuilder().setAlert("alert")
                                .addExtra("from", "JPush").addExtra("from", "JPush").build();
                PushPayload payload = PushPayload.newBuilder().setPlatform(Platform.all())
                                .setNotification(Notification.newBuilder().addPlatformNotification(iosNotification)
                                                .addPlatformNotification(androidNotification).build())

                                .setAudience(Audience.all()).setMessage(Message.content("hehda")).build();
                // Message
                PushResult result = client.sendPush(payload);
                res = ResponseUtil.createRespBean(true, 200, result.toString());
                return res;

        }

        @ApiOperation(value = "获取会员id", notes = "", httpMethod = "Get")
        @RequestMapping(value = "/test", method = RequestMethod.GET)
        public ResponseBean test() throws Exception {
                Map<String, String> extral = new HashMap<String, String>();
                extral.put("view", ViewEnum.MemberInvite.toString());
                // extral.put("memberInviteId", memberInvite.getId().toString());
                this.jpushServiceImpl.sendRegistrationIdNotify("test", "13065ffa4e5f13ceb10", extral);
                return ResponseUtil.createRespBean(true, 200, "s");
        }

        public static PushPayload buildPushObject_all_all_alert() {
                return PushPayload.alertAll("alert");
        }

}