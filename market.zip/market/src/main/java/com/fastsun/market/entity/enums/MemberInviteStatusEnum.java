package com.fastsun.market.entity.enums;

public enum MemberInviteStatusEnum {
    Active, Del, Agree, Refuse
}
