package com.fastsun.market.jpa;

import com.fastsun.framework.jpa.base.BaseRepository;
import com.fastsun.market.entity.synthesizeFee.PayFee;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface PayFeeJPA extends BaseRepository<PayFee, Integer>, JpaSpecificationExecutor<PayFee> {

}
