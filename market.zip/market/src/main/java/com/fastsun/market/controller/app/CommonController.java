package com.fastsun.market.controller.app;

import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ImageUtil;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.enums.QcodeBizType;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.utils.StatusMsgEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.fastsun.market.service.impl.common.MsgServiceImpl;

import com.fastsun.market.bean.*;
import com.fastsun.market.jpa.*;
import com.fastsun.framework.jpa.*;
import com.fastsun.market.entity.common.*;
import com.fastsun.market.entity.enums.AccountStatus;
import com.fastsun.framework.entity.rbac.*;
import com.fastsun.market.entity.member.*;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import javax.validation.Valid;
import java.util.*;
import java.util.stream.Collectors;

import com.fastsun.market.service.impl.*;
import io.swagger.annotations.Api;

import com.fastsun.market.MarketApi.CommonApi;

@Api(description = "分析", tags = { "market.app.Common" })
@RestController("appCommonController")
@RequestMapping(CommonApi.PREFIX)
public class CommonController extends BaseController {
    @Autowired
    private MarketJPA marketJPA;
    @Autowired
    private MsgServiceImpl msgServiceImpl;
    @Autowired
    private SMSLogJPA smsLogJPA;
    @Autowired
    private HotKeyJPA hotKeyJPA;
//    @Autowired
//   private RequestUtil requestUtil;
    @Autowired
    private CommonEntityService commonEntityService;
    private ResponseBean responseBean;

    @ApiOperation(value = CommonApi.marketList, notes = "", httpMethod = "GET")
    @RequestMapping(value = CommonApi.marketList, method = RequestMethod.GET)
    public ResponseBean listMarket() {
        ResponseBean res = ResponseUtil.createRespBean(true, 200, "成功获取列表");
        List<Market> markets = marketJPA.findAll();
        res.getData().put("markets", markets);
        return res;
    }

    @ApiOperation(value = "app用户手机验证码", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/sada", method = RequestMethod.GET)
    public CheckAuthcode findbyMobi2(@RequestParam String phone, @RequestParam Integer mktId) {
        return null;
    }

    @ApiOperation(value = "app用户手机验证码", notes = "", httpMethod = "GET")
    @RequestMapping(value = CommonApi.sendAuthcode, method = RequestMethod.GET)
    public ResponseBean authcode(@RequestParam Integer mktId, @RequestParam String phone,
            @RequestParam String verifyType) throws Exception {
        SendSmsResponse response = this.msgServiceImpl.sendAppAuthcode(phone, mktId, verifyType);
        ResponseBean res;
        if (response != null) {
            if (response.getCode().toLowerCase().equals("ok")) {
                res = ResponseUtil.createRespBean(true, StatusMsgEnum.ACTIVE_SUCCESS.getStatus(),
                        StatusMsgEnum.ACTIVE_SUCCESS.getMsg());
                return res;
            } else {
                res = ResponseUtil.createRespBean(false, StatusMsgEnum.SMS_FALSE.getStatus(),
                        StatusMsgEnum.SMS_FALSE.getMsg());
            }
            res.getData().put("msg", response);
            return res;
        } else {
            return ResponseUtil.createRespBean(false, 400, "短信费用不足");
        }
    }

    @ApiOperation(value = "app校验验证码合法性", notes = "", httpMethod = "GET")
    @RequestMapping(value = CommonApi.checkAuthcode, method = RequestMethod.GET)
    public ResponseBean checkAuthcode(@RequestParam String phone, @RequestParam String authcode,
            @RequestParam String verifyType, @RequestParam Integer mktId) {
        SMSLog msg = smsLogJPA.findFirstByIsVerifySmsAndVerifyTypeAndMobiOrderByCreateTimeDesc(true, verifyType, phone);
        if (msg != null) {
            if (msg.getVerifyCode().equals(authcode)) {
                return ResponseUtil.createRespBean(true, 200, "信息正确");
            } else {
                return ResponseUtil.createRespBean(false, 400, "验证码错误");
            }
        } else {
            return ResponseUtil.createRespBean(false, 400, "尚未发送验证码");
        }

    }

    @PostMapping("/hotkey/create")
    public ResponseBean createHotKey(@RequestBody HotKey hotKey){
        HotKey hotKeyDB = null;
        Paging<HotKey> paging = this.commonEntityService.findPagedEntity(RequestUtil.getQueryParameter(hotKey,"and","hotKeyIndex","memberId","mktId","txnId"),hotKey.getClass());
        if(paging.getRows().size() == 0){
            hotKeyDB = this.hotKeyJPA.save(hotKey);
        }else if(paging.getRows().size() == 1){
            hotKeyDB =  paging.getRows().get(0);
            hotKeyDB.setProductId(hotKey.getProductId());
            this.commonEntityService.update(hotKeyDB);
        }
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("hotKey",hotKeyDB);
        return responseBean;
    }

    @GetMapping("/hotkey/list")
    public ResponseBean getHotKeyList(@RequestParam Integer mktId,@RequestParam Integer txnId,@RequestParam Integer memberId){
        List<HotKey> hotKeys = this.hotKeyJPA.findAllByMktIdAndTxnIdAndMemberId(mktId,txnId,memberId);
        hotKeys.stream().forEach(hotKey -> {
            hotKey.getProduct().setProdCatId(hotKey.getProduct().getProdCatalog().getId());
            hotKey.getProduct().setProdCatName(hotKey.getProduct().getProdCatalog().getCatName());
        });
        Map<Integer,Product> map = hotKeys.stream().collect(Collectors.toMap(HotKey::getHotKeyIndex,HotKey::getProduct));
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("hotkeys",map);
        return responseBean;
    }

    @GetMapping("/getQCode")
    public ResponseBean getQCode(@RequestParam Integer memberId,@RequestParam Integer mktId){
        String memberIdAndMktId = memberId+","+mktId;
        String qCodeBase64Str = ImageUtil.convertString(memberIdAndMktId);
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("qCodeBase64Str",qCodeBase64Str);
        responseBean.getData().put("qcodeBizType",QcodeBizType.QUERY_CREDIT);
        return  responseBean;
    }
}
