package com.fastsun.market.entity.common;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fastsun.market.entity.enums.PriceUnit;
import com.fastsun.market.entity.enums.PriceWayEnum;
import com.fastsun.market.entity.enums.ProductStatus;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "b_product")
public class Product implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.EAGER,cascade = CascadeType.PERSIST,optional = false)
    @JoinColumn(name = "prodCatId", updatable = false)
    @JsonBackReference
    private ProdCatalog prodCatalog;
    @Transient
    private Integer prodCatId;
    @Transient
    private String prodCatName;
    @Column(nullable = false)
    private String name;// 操作类型
    @Column(nullable = false)
    private BigDecimal price;
    private Date createTime = new Date();// 创建时间
    private PriceWayEnum priceWay;
    @Enumerated(EnumType.ORDINAL)
    @Column(nullable = false)
    private PriceUnit priceUnit;// 计价单位
    private BigDecimal pcsWgt;// 单件重量
    private Integer quantity;//数量
    private Integer memberId;// 所属会员
    private Integer custId;// 创建者Id
    private Integer mktId;
    @Enumerated(EnumType.ORDINAL)
    private ProductStatus status = ProductStatus.Active;// 计价单位

    /**
     * @return the priceWay
     */
    public PriceWayEnum getPriceWay() {
        return priceWay;
    }

    /**
     * @param priceWay the priceWay to set
     */
    public void setPriceWay(PriceWayEnum priceWay) {
        this.priceWay = priceWay;
    }

    /**
     * @return the status
     */
    public ProductStatus getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(ProductStatus status) {
        this.status = status;
    }

    /**
     * @return the mktId
     */
    public Integer getMktId() {
        return mktId;
    }

    /**
     * @param mktId the mktId to set
     */
    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Product() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    @JsonProperty
    public ProdCatalog getProdCatalog() {
        return prodCatalog;
    }

    public void setProdCatalog(ProdCatalog prodCatalog) {
        this.prodCatalog = prodCatalog;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public PriceUnit getPriceUnit() {
        return priceUnit;
    }

    public void setPriceUnit(PriceUnit priceUnit) {
        this.priceUnit = priceUnit;
    }

    public BigDecimal getPcsWgt() {
        return pcsWgt;
    }

    public void setPcsWgt(BigDecimal pcsWgt) {
        this.pcsWgt = pcsWgt;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public Integer getCustId() {
        return custId;
    }

    public void setCustId(Integer custId) {
        this.custId = custId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getProdCatId() {
        return prodCatId;
    }

    public void setProdCatId(Integer prodCatId) {
        this.prodCatId = prodCatId;
    }

    public String getProdCatName() {
        return prodCatName;
    }

    public void setProdCatName(String prodCatName) {
        this.prodCatName = prodCatName;
    }
}
