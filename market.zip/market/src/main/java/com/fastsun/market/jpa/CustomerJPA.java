package com.fastsun.market.jpa;

import com.fastsun.market.entity.member.Customer;

import java.util.List;

import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface CustomerJPA extends BaseRepository<Customer, Integer>, JpaSpecificationExecutor<Customer> {
    // List<Category> findByMktIdAndParentIdIsNull();
    Customer findByMobi(String mobi);

    Customer findByCardId(Integer cardId);

    Customer findByMktIdAndMobi(Integer mktId, String phone);

    List<Customer> findByMktIdAndMemberIdIsNull(Integer mktId);

    List<Customer> findByMemberId(Integer memberId);

    List<Customer> findByNameContaining(String name);

    List<Customer> findByMobiContaining(String mobi);

    Customer findByMktIdAndAndId(Integer mktId, Integer customerId);
}
