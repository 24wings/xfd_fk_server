package com.fastsun.market.bean;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.math.BigDecimal;
import java.util.Collection;

public class FinishRecord {
    private Integer recordId;
    private BigDecimal truepayMoney;
    private Integer epId;

    /**
     * @return the epId
     */
    public Integer getEpId() {
        return epId;
    }

    /**
     * @param epId the epId to set
     */
    public void setEpId(Integer epId) {
        this.epId = epId;
    }

    /**
     * @return the truepayMoney
     */
    public BigDecimal getTruepayMoney() {
        return truepayMoney;
    }

    /**
     * @param truepayMoney the truepayMoney to set
     */
    public void setTruepayMoney(BigDecimal truepayMoney) {
        this.truepayMoney = truepayMoney;
    }

    /**
     * @return the recordId
     */
    public Integer getRecordId() {
        return recordId;
    }

    /**
     * @param recordId the recordId to set
     */
    public void setRecordId(Integer recordId) {
        this.recordId = recordId;
    }
}