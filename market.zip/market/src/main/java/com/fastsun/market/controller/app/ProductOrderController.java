package com.fastsun.market.controller.app;

import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.transOrder.Order;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.entity.account.AccountDebt;
import com.fastsun.market.entity.common.ProdCatalog;
import com.fastsun.market.entity.common.Product;
import com.fastsun.market.entity.common.TransArea;
import com.fastsun.market.entity.enums.AccountType;
import com.fastsun.market.entity.enums.MemberStatus;
import com.fastsun.market.entity.enums.OrderStatus;
import com.fastsun.market.entity.enums.ProductStatus;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.jpa.AccountDebtJPA;
import com.fastsun.market.jpa.MemberJPA;
import com.fastsun.market.jpa.OrderJPA;
import com.fastsun.market.jpa.OrderNoJPA;
import com.fastsun.market.jpa.ProdCatalogJPA;
import com.fastsun.market.jpa.ProductJPA;
import com.fastsun.market.jpa.TransAreaJPA;
import com.fastsun.market.service.impl.MemberAccountServiceImpl;
import com.fastsun.market.service.impl.ProdCatalogServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.List;
import java.util.stream.Collectors;

import com.fastsun.market.MarketApi.ProductOrderApi;
import com.fastsun.market.bean.TransferResult;;

@Api(description = "商品订单", tags = { "market.app.ProductOrder" })
@RequestMapping(ProductOrderApi.PREFIX)
@RestController("appProductOrderController")
public class ProductOrderController extends BaseController {
    private ResponseBean responseBean;
    @Autowired
    private ProdCatalogServiceImpl prodCatalogServiceImpl;
    @Autowired
    private OrderNoJPA orderNoJPA;
    @Autowired
    private OrderJPA orderJPA;
    @Autowired
    private MemberJPA memberJPA;
    @Autowired
    MemberAccountServiceImpl memberAccountServiceImpl;
    @Autowired
    ProductJPA productJPA;
    @Autowired
    AccountDebtJPA accountDebtJPA;
    @Autowired
    ProdCatalogJPA prodCatalogJPA;
    @Autowired
    private TransAreaJPA transAreaJPA;

    @ApiOperation(value = "创建订单", notes = "", httpMethod = "POST")
    @RequestMapping(value = ProductOrderApi.orderCreate, method = RequestMethod.POST)
    public ResponseBean orderCreate(@RequestBody Order order) {
        /**
         * 1. 检查订单的必要参数 如 memberName,
         */
        if (order.getSellerMemId() != null) {
            order.setStatus(OrderStatus.TEMP);
            order = orderJPA.saveAndFlush(order);
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "创建成功");
            success.getData().put("order", order);
            return success;
        } else {
            return ResponseUtil.createRespBean(true, 400, "订单缺少卖家");
        }
    }

    @ApiOperation(value = "订单详情", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.orderDetail, method = RequestMethod.GET)
    public ResponseBean orderDetail(@RequestParam Integer orderId, @RequestParam Integer mktId) {
        Order order = orderJPA.findById(orderId).get();
        if (order != null) {
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
            success.getData().put("order", order);
            return success;
        } else {
            return ResponseUtil.createRespBean(false, 400, "订单不存在");
        }
    }

    @ApiOperation(value = "订单废弃", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.orderDisabled, method = RequestMethod.GET)
    public ResponseBean orderDisabled(@RequestParam Integer orderId, @RequestParam Integer mktId,
            @RequestParam Integer memberId) {
        Order order = orderJPA.findById(orderId).get();
        if (order != null) {
            if ((order.getStatus().toString().equals(OrderStatus.TEMP.toString())
                    || order.getStatus().toString().equals(OrderStatus.TOBE_PAY.toString()))
                    && order.getSellerMemId() == memberId) {
                order.setStatus(OrderStatus.CLOSED);
                orderJPA.saveAndFlush(order);
                return ResponseUtil.createRespBean(true, 200, "废弃订单成功");

            } else {
                return ResponseUtil.createRespBean(false, 400, "订单状态不允许修改");
            }

        } else {
            return ResponseUtil.createRespBean(false, 400, "错误");
        }
    }

    @ApiOperation(value = "在线支付订单", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.onlinePayOrder, method = RequestMethod.GET)
    public ResponseBean onlinePayOrder(@RequestParam Integer orderId, @RequestParam Integer mktId,
            @RequestParam Integer memberId) {
        Order order = orderJPA.findById(orderId).get();
        Member member = memberJPA.findById(memberId).get();
        Member recvAmtMember = memberJPA.findById(order.getSellerMemId()).get();
        if (order != null && member != null && recvAmtMember != null) {
            Account account = memberAccountServiceImpl.getMemberAccount(memberId, AccountType.MEMBER_CASH);
            Account toAccount = memberAccountServiceImpl.getMemberAccount(recvAmtMember.getId(),
                    AccountType.MEMBER_CASH);
            TransferResult result = null;
            try {
                result = this.memberAccountServiceImpl.transferAmt(account, toAccount, order.getApAmt(),member,recvAmtMember);
            } catch (Exception e) {
                e.printStackTrace();
            }
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "成功");
            success.getData().put("result", result);
            return success;
        } else {
            return ResponseUtil.createRespBean(false, 400, "订单或支付会员不存在");
        }
    }

//    @ApiOperation(value = "订单上传", notes = "", httpMethod = "GET")
//    @RequestMapping(value = ProductOrderApi.orderUpload, method = RequestMethod.GET)
//    public ResponseBean orderUpload(@RequestBody Order tempOrder) {
//        tempOrder.setStatus(OrderStatus.TEMP);
//        tempOrder = orderJPA.save(tempOrder);
//        ResponseBean success = ResponseUtil.createRespBean(true, 200, "订单上传成功");
//        success.getData().put("order", tempOrder);
//        return success;
//    }

//    @ApiOperation(value = "订单下载列表", notes = "", httpMethod = "GET")
//    @RequestMapping(value = ProductOrderApi.orderDowloadList, method = RequestMethod.GET)
//    public ResponseBean orderDowloadList(@RequestParam Integer memberId, @RequestParam Integer mktId) {
//        ResponseBean success = ResponseUtil.createRespBean(true, 200, "消息成功");
//        List<Order> orders = orderJPA.findBySellerMemIdAndStatus(memberId, OrderStatus.TEMP);
//        success.getData().put("orders", orders);
//        return success;
//    }

//    @ApiOperation(value = "下载订单", notes = "", httpMethod = "GET")
//    @RequestMapping(value = ProductOrderApi.orderDowload, method = RequestMethod.GET)
//    public ResponseBean orderDowload(@RequestParam Integer tempOrderId, @RequestParam Integer mktId) {
//        Order order = orderJPA.findById(tempOrderId).get();
//        if (order != null) {
//            if (order.getStatus().equals(OrderStatus.TEMP)) {
//                //TODO:订单下载之后删除订单
//                order.setStatus(OrderStatus.CLOSED);
//                orderJPA.saveAndFlush(order);
//                ResponseBean success = ResponseUtil.createRespBean(true, 200, "下载成功");
//                success.getData().put("order", order);
//                return success;
//            } else {
//                return ResponseUtil.createRespBean(false, 400, "订单状态不允许下载");
//            }
//        } else {
//            return ResponseUtil.createRespBean(false, 400, "订单不存在");
//        }
//    }

    @ApiOperation(value = "商品列表", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.productList, method = RequestMethod.GET)
    public ResponseBean productList(@RequestParam Integer memberId, @RequestParam Integer mktId) {
        List<Product> products = productJPA.findByMemberIdAndMktId(memberId, mktId);
        products = products.stream().peek(product -> product.setProdCatName(product.getProdCatalog().getCatName())).collect(Collectors.toList());
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
        success.getData().put("products", products);
        return success;
    }

    @ApiOperation(value = "商品列表状态过滤", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.productListByStatus, method = RequestMethod.GET)
    public ResponseBean productListByStatus(@RequestParam Integer memberId, @RequestParam Integer mktId,
            @RequestParam ProductStatus status) {
        List<Product> products = productJPA.findByMemberIdAndMktIdAndStatus(memberId, mktId, status);
        products = products.stream().peek(product -> {
            product.setProdCatName(product.getProdCatalog().getCatName());
            product.setProdCatId(product.getProdCatalog().getId());
        }).collect(Collectors.toList());
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
        success.getData().put("products", products);
        return success;
    }

    @ApiOperation(value = "商品列表状态过滤", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.productListByKeyword, method = RequestMethod.GET)
    public ResponseBean productListByKeyword(@RequestParam Integer memberId, @RequestParam Integer mktId,
            @RequestParam String keyword) {

        ResponseBean success = ResponseUtil.createRespBean(true, 200, "成功");
        List<Product> products = productJPA.findByMemberIdAndMktIdAndNameIsLike(memberId, mktId, keyword);
        success.getData().put("products", products);
        return success;
    }

    @ApiOperation(value = "推送订单到某会员`", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.sendOrderToMember, method = RequestMethod.GET)
    public ResponseBean sendOrderToMember(@RequestParam Integer memberId, @RequestParam Integer orderId,
            @RequestParam Integer fromMemberId) {
        Order order = orderJPA.findById(orderId).get();
        if (order != null) {
            if (order.getSellerMemId().equals(fromMemberId)) {
                // 消息系统
                ResponseBean success = ResponseUtil.createRespBean(true, 200, "成功");
                return success;
            } else {
                return ResponseUtil.createRespBean(false, 400, "非法的订单推送");
            }
        } else {
            return ResponseUtil.createRespBean(false, 200, "订单不存在");
        }
    }

    @ApiOperation(value = "推送订单到某会员`", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.debtRequest, method = RequestMethod.GET)
    public ResponseBean debtRequest(@RequestParam Integer orderId, @RequestParam Integer toMemberId,
            @RequestParam Integer fromMemberId) {
        Order order = orderJPA.findById(orderId).get();
        Member fromMember = memberJPA.findById(fromMemberId).get();
        Member toMember = memberJPA.findById(toMemberId).get();

        if (order != null && fromMember != null && toMember != null) {
            if (order.getSellerMemId() == fromMemberId
                    && toMember.getStatus().toString().equals(MemberStatus.ENABLE.toString())) {
                // 发送订单推送消息
                ResponseBean success = ResponseUtil.createRespBean(true, 200, "推送订单成功");
                return success;
            } else {
                return ResponseUtil.createRespBean(false, 400, "非法订单或会员冻结");
            }
            // 推送订单的消息
        } else {
            return ResponseUtil.createRespBean(false, 400, "订单或涉及会员不存在");
        }
    }

    @ApiOperation(value = "推送订单到某会员`", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.debtAgree, method = RequestMethod.GET)
    public ResponseBean debtAgree(@RequestParam Integer orderId, @RequestParam Integer memberId,
            @RequestParam Integer mktId) {
        Order order = orderJPA.findById(orderId).get();
        if (order != null) {
            if (order.getStatus().toString().equals(OrderStatus.TOBE_PAY.toString())
                    && order.getSellerMemId() == memberId) {
                order.setStatus(OrderStatus.PAID);
                /** 增加赊账订单 */

                orderJPA.saveAndFlush(order);
                ResponseBean success = ResponseUtil.createRespBean(true, 200, "参数不合法");
                return success;
            } else {
                return ResponseUtil.createRespBean(false, 400, "订单状态不允许拒绝或不属于你的订单");
            }

        } else {
            return ResponseUtil.createRespBean(false, 400, "参数不合法");
        }

    }

    @ApiOperation(value = "赊账拒绝`", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.debtRefuse, method = RequestMethod.GET)
    public ResponseBean debtRefuse(@RequestParam Integer orderId, @RequestParam Integer memberId) {
        Order order = orderJPA.findById(orderId).get();
        if (order != null) {
            if (order.getStatus().toString().equals(OrderStatus.TOBE_PAY.toString())
                    && order.getSellerMemId() == memberId) {
                order.setStatus(OrderStatus.CLOSED);
                orderJPA.saveAndFlush(order);
                ResponseBean success = ResponseUtil.createRespBean(true, 200, "参数不合法");
                return success;
            } else {
                return ResponseUtil.createRespBean(false, 400, "订单状态不允许拒绝或不属于你的订单");
            }

        } else {
            return ResponseUtil.createRespBean(false, 400, "参数不合法");
        }

    }

    @ApiOperation(value = "查看会员的欠债金额`", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.memberDebtMoney, method = RequestMethod.GET)
    public ResponseBean memberDebtMoney(@RequestParam Integer mktId, @RequestParam Integer memberId) {
        Member member = memberJPA.findById(memberId).get();
        if (member != null) {
            Account debttorAccount = memberAccountServiceImpl.getMemberAccount(memberId, AccountType.MEMBER_CASH);

            if (debttorAccount != null) {
                List<AccountDebt> accountDebts = accountDebtJPA.findByDebtorAccId(debttorAccount.getId());
                ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
                success.getData().put("accountDebts", accountDebts);
                return success;
            } else {
                return ResponseUtil.createRespBean(false, 400, "未开通会员现金账户");
            }

        } else {
            return ResponseUtil.createRespBean(false, 400, "会员不存在");

        }
    }

    @ApiOperation(value = "产品分类列表", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.productCatList, method = RequestMethod.GET)
    public ResponseBean productCatList(@RequestParam Integer parentId, @RequestParam Integer mktId) {
        List<ProdCatalog> productCatas = prodCatalogJPA.findByMktIdAndParentId(mktId, parentId);
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
        success.getData().put("productCatas", productCatas);
        return success;
    }

    @ApiOperation(value = "交易分区列表", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.txnList, method = RequestMethod.GET)
    public ResponseBean txnList(@RequestParam Integer mktId) {
        List<TransArea> areas = transAreaJPA.findByMktId(mktId);
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "响应成功");
        success.getData().put("areas", areas);
        return success;
    }

    @ApiOperation(value = "创建商品`", notes = "", httpMethod = "POST")
    @RequestMapping(value = ProductOrderApi.productCreate, method = RequestMethod.POST)
    public ResponseBean debtRequest(@RequestBody Product product) {
        Product productDB = this.prodCatalogServiceImpl.productCreate(product);
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("product",productDB);
        return responseBean;
    }

    @ApiOperation(value = "修改商品`", notes = "", httpMethod = "POST")
    @RequestMapping(value = ProductOrderApi.productUpdate, method = RequestMethod.POST)
    public ResponseBean productUpdate(@RequestBody Product product) {
        if (product.getCustId() != null && product.getMemberId() != null) {
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "创建商品成功");
            product = productJPA.saveAndFlush(product);
            success.getData().put("product", product);
            return success;
        } else {
            return ResponseUtil.createRespBean(false, 400, "未知的商户");
        }
    }

    @ApiOperation(value = "刪除商品`", notes = "", httpMethod = "GET")
    @RequestMapping(value = ProductOrderApi.productDel, method = RequestMethod.GET)
    public ResponseBean productDel(@RequestParam Integer productId, @RequestParam Integer mktId) {

        Product product = productJPA.findById(productId).get();
        if (product != null) {
            product.setStatus(ProductStatus.Del);
            productJPA.saveAndFlush(product);
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "删除成功");
            return success;
        } else {
            return ResponseUtil.createRespBean(false, 400, "不存在的商品");
        }
    }
}
