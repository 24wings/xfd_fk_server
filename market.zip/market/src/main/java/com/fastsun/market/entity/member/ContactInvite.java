package com.fastsun.market.entity.member;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fastsun.market.entity.enums.CommonStatusEnum;
import com.fastsun.market.entity.enums.MemberInviteStatusEnum;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.Date;
@Table(name = "b_contact_Invite")
@Entity
public class ContactInvite {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ApiModelProperty("会员编号")
    private Integer memberId;

    @ApiModelProperty("朋友会员编号")
    private Integer friendinvitemId;

    @ApiModelProperty("会员名称")
    private String memberName;

    @ApiModelProperty("朋友会员名称")
    private String friendinvitemName;

    @Enumerated(EnumType.ORDINAL)
    private MemberInviteStatusEnum status = MemberInviteStatusEnum.Active;

    @ApiModelProperty("内容")
    private String content;

    @ApiModelProperty("所属市场Id")
    private Integer mktId;

    @ApiModelProperty("创建时间")
    private Date createTime = new Date();

    @ApiModelProperty("确认时间")
    private Date confirmTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public Integer getFriendinvitemId() {
        return friendinvitemId;
    }

    public void setFriendinvitemId(Integer friendinvitemId) {
        this.friendinvitemId = friendinvitemId;
    }

    public MemberInviteStatusEnum getStatus() {
        return status;
    }

    public void setStatus(MemberInviteStatusEnum status) {
        this.status = status;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getConfirmTime() {
        return confirmTime;
    }

    public void setConfirmTime(Date confirmTime) {
        this.confirmTime = confirmTime;
    }


    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getFriendinvitemName() {
        return friendinvitemName;
    }

    public void setFriendinvitemName(String friendinvitemName) {
        this.friendinvitemName = friendinvitemName;
    }
}
