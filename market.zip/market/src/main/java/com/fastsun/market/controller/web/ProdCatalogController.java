package com.fastsun.market.controller.web;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.controller.base.BaseController;import com.fastsun.market.entity.common.ProdCatalog;
import com.fastsun.market.jpa.ProdCatalogJPA;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(description = "商品类目", tags = { "market.web.ProdCatalog" })
@RestController
@RequestMapping("/api/category")
public class ProdCatalogController extends BaseController {
    @Autowired
    ProdCatalogJPA prodCatalogJPA;

    @Autowired
    private CommonEntityService prodCatalogCommonEntityService;

    private ResponseBean responseBean = null;

    @ApiOperation(value = "创建商品类目", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ResponseBean addSubject(@RequestBody ProdCatalog category) {
        if (category == null) {
            responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return responseBean;
        }
        long count = this.prodCatalogCommonEntityService
                .getRecordCount(RequestUtil.getQueryParameter(category, "or", "catName", "catCode"), ProdCatalog.class);
        if (count > 0) {
            responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_REPEAT.getStatus(),
                    StatusMsgEnum.ADD_REPEAT.getMsg());
            return responseBean;
        }
        boolean flag = prodCatalogCommonEntityService.save(category);
        if (flag) {
            responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                    StatusMsgEnum.ADD_SUCCESS.getMsg());
        } else {
            responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_FAILED.getStatus(),
                    StatusMsgEnum.ADD_FAILED.getMsg());
        }
        return responseBean;
    }

    @ApiOperation(value = "修改商品类目", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseBean updateSubject(@RequestBody ProdCatalog category) {
        ProdCatalog newCategory = (ProdCatalog) prodCatalogCommonEntityService.update(category);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        responseBean.getData().put("category", newCategory);
        return responseBean;
    }

    @ApiOperation(value = "删除商品类目", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseBean deleteSubject(@RequestParam Integer cateId) {
        ResponseBean res = null;
        if (cateId == null) {
            res = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.UPDATE_SUCCESS.getMsg());
            return res;
        }
        prodCatalogCommonEntityService.delete(ProdCatalog.class, cateId);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.DELETE_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return res;
    }

    @ApiOperation(value = "查询商品品类", notes = "根据parentId查询分页列表，parentId可为空", httpMethod = "Post")
    @PostMapping(value = "/list")
    public ResponseBean getSysCateList(@RequestBody QueryParameter queryParameter) {
        Paging<ProdCatalog> paging = this.prodCatalogCommonEntityService.findPagedEntity(queryParameter,
                ProdCatalog.class);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("paging", paging);
        return responseBean;
    }
     @ApiOperation(value = "详情", notes = "根据catecode ", httpMethod = "Get")
     @GetMapping(value = "/detail")
     public ResponseBean getMarketCateList(@RequestParam String  catCode,@RequestParam Integer mktId){
     ProdCatalog prodCatalog = this.prodCatalogJPA.findByCatCodeAndMktId(catCode,mktId);
     responseBean = ResponseUtil.createRespBean(true,StatusMsgEnum.QUERY_SUCCESS.getStatus(),StatusMsgEnum.QUERY_SUCCESS.getMsg());
     responseBean.getData().put("prodCatalog",prodCatalog);
     return responseBean;
     }
}
