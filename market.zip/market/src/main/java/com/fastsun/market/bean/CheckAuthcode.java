package com.fastsun.market.bean;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "checkauthcode")
public class CheckAuthcode {
    private String authcode;
    private String phone;
    private Integer mktId;

    /**
     * @param authcode the authcode to set
     */
    public void setAuthcode(String authcode) {
        this.authcode = authcode;
    }

    /**
     * @param mktId the mktId to set
     */
    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the authcode
     */
    public String getAuthcode() {
        return authcode;
    }

    /**
     * @return the mktId
     */
    public Integer getMktId() {
        return mktId;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }
}