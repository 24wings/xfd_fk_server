package com.fastsun.market.jpa;

import com.fastsun.market.entity.common.RecvPaySubject;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public interface RecPaySubjectJPA extends BaseRepository<RecvPaySubject,Integer> ,JpaSpecificationExecutor<RecvPaySubject> {

        RecvPaySubject findBySubjectCode(String subject);
}
