package com.fastsun.market.entity.enums;

public enum CustCardStatus {
    ENABLE,DISABLE,CANCEL,ACTIVE,FROZEN
}
