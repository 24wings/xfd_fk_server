package com.fastsun.market.jpa;

import com.fastsun.market.entity.common.SMSLog;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface SMSLogJPA extends BaseRepository<SMSLog, Integer>, JpaSpecificationExecutor<SMSLog> {
    public SMSLog findFirstByIsVerifySmsAndVerifyTypeAndMobiOrderByCreateTimeDesc(Boolean isVerifySms,
            String verifyType, String mobi);
}
