package com.fastsun.market.utils;

public enum StatusMsgEnum {

    PARAM_NULL(101, "参数为空！"), ADD_SUCCESS(200, "添加成功！"),ADD_FAILED(201,"添加失败"), ADD_REPEAT(201, "重复添加(违反唯一约束)"), QUERY_SUCCESS(200, "查询成功！"),
    QUERY_FALSE(101, "查询失败！"), DELETE_SUCCESS(200, "删除成功！"), UPDATE_SUCCESS(200, "更新成功！"), LOGIN_SUCCESS(200, "登录成功！"),
    LOGIN_FALSE(101, "登录失败！"), RESET_PASSWORD_SUCCESS(200, "更新密码成功！"), ADD_ROLE_SUCCESS(200, "添加用户成功！"),
    DELETE_ROLE_SUCCESS(200, "删除用户成功！"), DISABLED_SUCCESS(200, "禁用成功！"), ACTIVE_SUCCESS(200, "启用成功！"),
    VOICE_SUCCESS(200, "语音听写成功！"),VOICE_FALSE(101, "语音听写失败！"),MEMBER_PRODUCT_FALSE(101, "用户无商品！"),
    PHONE_CUSTOMER_EXISIT(400, "手机已经被注册"), SMS_FALSE(101, "短信发送失败");

    private Integer status;

    private String msg;

    StatusMsgEnum(Integer status, String msg) {
        this.status = status;
        this.msg = msg;
    }

    public Integer getStatus() {
        return status;
    }

    public String getMsg() {
        return msg;
    }
}
