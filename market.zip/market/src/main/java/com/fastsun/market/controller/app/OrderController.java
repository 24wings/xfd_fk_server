package com.fastsun.market.controller.app;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.bean.TempOrderSimpleRq;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ImageUtil;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.utils.StatusMsgEnum;
import com.fastsun.market.MarketApi;
import com.fastsun.market.bean.OrderCreateRq;
import com.fastsun.market.bean.OrderPayRq;
import com.fastsun.market.bean.ProcatalogInfo;
import com.fastsun.market.bean.TransferResult;
import com.fastsun.market.entity.common.ProdCatalog;
import com.fastsun.market.entity.common.Product;
import com.fastsun.market.entity.transOrder.Order;
import com.fastsun.market.entity.transOrder.Order;
import com.fastsun.market.entity.enums.OrderStatus;
import com.fastsun.market.entity.enums.QcodeBizType;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.service.impl.MemberServiceImpl;
import com.fastsun.market.service.impl.OrderServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.math.BigDecimal;
import java.text.Collator;
import java.util.*;

@Api(description = "app订单",tags = "market.app.order")
@RestController("appOrderController")
@RequestMapping("/app/order")
public class OrderController extends BaseController {

    private ResponseBean responseBean;

    @Autowired
    OrderServiceImpl orderServiceImpl;
    @Autowired
    CommonEntityService commonEntityService;
    @Autowired
    MemberServiceImpl memberService;
    @ApiOperation(value = "orderCreate",notes = "创建订单",httpMethod = "POST")
    @PostMapping(value = "/orderCreate")
    public ResponseBean orderCreate(HttpServletRequest request,@RequestBody @Valid OrderCreateRq orderCreateRq){
        Order order = null;
        try {
            order = orderServiceImpl.orderCreate(request, orderCreateRq,null);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(false,201,"创建订单失败！");
            e.printStackTrace();
            return responseBean;
        }
        String str = order.getOrderNo() + ","+ QcodeBizType.TRANS_PAY;
        String qCodeBase64Str = ImageUtil.convertString(str);
        responseBean = ResponseUtil.createRespBean(true,200,"创建订单成功");
        responseBean.getData().put("qCodeBase64Str",qCodeBase64Str);
        responseBean.getData().put("qcodeBizType", QcodeBizType.TRANS_PAY);
        responseBean.getData().put("orderNo",order.getOrderNo());
        return responseBean;
    }
    @ApiOperation(value = "orderPay",notes = "订单支付",httpMethod = "POST")
    @PostMapping(value = "/orderPay")
    public ResponseBean orderPay(HttpServletRequest request,@RequestBody @Valid OrderPayRq orderPayRq){
        Order order = null;
        try {
            order = this.orderServiceImpl.oderPay(request,orderPayRq);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(false,201,"订单支付失败！");
            e.printStackTrace();
            return responseBean;
        }
        responseBean = ResponseUtil.createRespBean(true,200,"订单支付成功!");
        responseBean.getData().put("accountDebt",order);
        return responseBean;
    }
    @ApiOperation(value = "exeQCode",notes = "解码回填买家信息",httpMethod = "GET")
    @GetMapping(value = "/exeQCode")
    public ResponseBean exeQCode(@RequestParam String base64Str, @RequestParam Integer customerId) throws JsonProcessingException {
        Order order = null;
        String[] strings = null;
        try {
            order = this.orderServiceImpl.exeQCode(base64Str ,customerId);
            String str = ImageUtil.deConvertString(base64Str);
            strings = str.split(",");
        } catch (Exception e) {
            e.printStackTrace();
        }
        responseBean = ResponseUtil.createRespBean(true,200,"");
        if(strings[1].equals("TRANS_ACC")) {
            responseBean.getData().put("qcodeBizType", QcodeBizType.TRANS_ACC);
        }
        else if(strings[1].equals("TRANS_PAY")) {
            responseBean.getData().put("qcodeBizType", QcodeBizType.TRANS_PAY);
        }
        responseBean.getData().put("params", order);
        return responseBean;
    }

    @ApiOperation(value = "线上交易回填买家信息",notes = "线上交易回填买家信息",httpMethod = "POST")
    @PostMapping(value = "/writeBuyerInfo")
    public ResponseBean writeBuyerInfo(@RequestBody Member buyerMember,@RequestParam String orderNo){
        Order order = this.orderServiceImpl.getOrderInfo(orderNo);
        order.setBuyerMemId(buyerMember.getId());
        order.setBuyerInfo(buyerMember.getName());
        order.setBuyerMemNo(buyerMember.getNo());
        order.setBuyerCustId(buyerMember.getCustomerId());
        this.commonEntityService.update(order);
        responseBean = ResponseUtil.createRespBean(true,200,"");
        return responseBean;
    }

    @ApiOperation(value = "",notes = "轮询订单状态",httpMethod = "GET")
    @GetMapping(value = "/queryOrderStatus")
    public ResponseBean queryOrderStatus(@RequestParam String orderNo){
        OrderStatus status = this.orderServiceImpl.queryOrderStatus(orderNo);
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("status",status);
        return responseBean;
    }

    @ApiOperation(value = "",notes = "改变订单状态",httpMethod = "GET")
    @GetMapping(value = "/changeStatus")
    public ResponseBean changeStatus(@RequestParam String orderNo,@RequestParam OrderStatus status){
        Order order = this.orderServiceImpl.changeStatus(orderNo,status);
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("order",order);
        return responseBean;
    }

    @ApiOperation(value = "orderDetail",notes = "查询订单详情",httpMethod = "GET")
    @GetMapping("/getOrderDetail")
    public ResponseBean getOrderDetail(@RequestParam String orderNo){
        Order order = this.orderServiceImpl.orderDetail(orderNo);
        Member member = (Member) this.commonEntityService.findById(Member.class,order.getSellerMemId());
        responseBean = ResponseUtil.createRespBean(true,200,StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("order",order);
        responseBean.getData().put("memberName",member.getName());
        return responseBean;
    }

    @ApiOperation(value = "订单上传", notes = "", httpMethod = "POST")
    @RequestMapping(value = MarketApi.ProductOrderApi.orderUpload, method = RequestMethod.POST)
    public ResponseBean orderUpload(HttpServletRequest request,@RequestBody OrderCreateRq orderCreateRq) {
        Order order = null;
        try {
            order = this.orderServiceImpl.orderCreate(request,orderCreateRq,OrderStatus.TEMP);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "订单上传成功");
        success.getData().put("order", order);
        return success;
    }
    @ApiOperation(value = "tempOrderQuery",notes = "临时订单简单信息列表",httpMethod = "GET")
    @GetMapping(value = "/tempOrderQuery")
    public ResponseBean tempOrderQuery(@RequestParam Integer memberId,@RequestParam Integer mktId){
       List<TempOrderSimpleRq> list =  this.orderServiceImpl.getTempOrderSimpleList(memberId,mktId);
       responseBean = ResponseUtil.createRespBean(true, 200, StatusMsgEnum.QUERY_SUCCESS.getMsg());
       responseBean.getData().put("tempOrderSimpleRqs",list);
       return responseBean;
    }

    @ApiOperation(value = "订单下载列表", notes = "", httpMethod = "GET")
    @RequestMapping(value = MarketApi.ProductOrderApi.orderDowloadList, method = RequestMethod.GET)
    public ResponseBean orderDowloadList(@RequestParam String orderNo, @RequestParam Integer mktId) {
        ResponseBean success = ResponseUtil.createRespBean(true, 200, StatusMsgEnum.QUERY_SUCCESS.getMsg());
        Order order = this.orderServiceImpl.getTempOrder(orderNo,mktId);
        success.getData().put("order", order);
        return success;
    }
    @ApiOperation(value = "",notes = "订单查询分页",httpMethod = "POST")
    @PostMapping(value = "/page")
    public ResponseBean orderPage(@RequestBody QueryParameter queryParameter){
        Paging paging = this.orderServiceImpl.getOrderList(queryParameter);
        responseBean = ResponseUtil.createRespBean(true,200,StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("paging",paging);
        return responseBean;
    }

    @ApiOperation(value = "线上交易",notes = "线上交易",httpMethod = "POST")
    @GetMapping("/onlineOrderPay")
    public ResponseBean onlineOrderPay(HttpServletRequest request,@RequestParam String orderNo,@RequestParam Integer buyerMemId){
        try {
            this.orderServiceImpl.onlineOrderPay(request,orderNo,buyerMemId);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(false,201,"线上交易发起失败！");
            e.printStackTrace();
            return responseBean;
        }
        responseBean = ResponseUtil.createRespBean(true,200,"线上交易发起成功！");
        return responseBean;
    }

    @ApiOperation(value = "付款生成订单", notes = "", httpMethod = "GET")
    @RequestMapping(value ="/setReceiptMoney", method = RequestMethod.GET)
    public ResponseBean setReceiptMoney(@RequestParam BigDecimal accmoney, @RequestParam Integer memberId) throws Exception {
        if(accmoney == null && memberId == null)
        {
            return ResponseUtil.createRespBean(false,400,"参数值不能为空！");
        }
        Order order = this.orderServiceImpl.setReceiptMoney(accmoney,memberId);
        String str = order.getOrderNo() + ","+ QcodeBizType.TRANS_ACC;
        String qCodeBase64Str = ImageUtil.convertString(str);
        responseBean = ResponseUtil.createRespBean(true,200,"创建订单成功");
        responseBean.getData().put("qCodeBase64Str",qCodeBase64Str);
        responseBean.getData().put("qcodeBizType", QcodeBizType.TRANS_ACC);
        responseBean.getData().put("orderNo",order.getOrderNo());
        return responseBean;
    }



    @ApiOperation(value = "收款",notes="",httpMethod = "GET")
    @RequestMapping(value = "/payMent",method = RequestMethod.GET)
    public ResponseBean payMent(@RequestParam Integer memberId,@RequestParam String orderNo, @RequestParam String payPassword) throws Exception {
        if(memberId == null && orderNo == null && payPassword == null) {
            return ResponseUtil.createRespBean(false,400,"输入值不能为空！");
        }
        boolean flag = this.memberService.confirePayPassword(memberId,payPassword);
        if(flag) {
            Order order  = this.orderServiceImpl.payMent(memberId, orderNo);
            if (order == null)
            {
                return ResponseUtil.createRespBean(false, 400, "订单不存在！");
            }
            ResponseBean res = ResponseUtil.createRespBean(true,200,"成功！");
            res.getData().put("accountDebt",order);
            return res;
        } else {
            return ResponseUtil.createRespBean(false,400,"支付密码错误！");
        }
    }

    @ApiOperation(value = "商品列表", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/product/productList", method = RequestMethod.GET)
    public ResponseBean getProductList( @RequestParam Integer memberId, @RequestParam Integer mktId,@RequestParam Integer txnId) {
        List<ProdCatalog> list = orderServiceImpl.getProductList(memberId,mktId,txnId);
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
        success.getData().put("ProdCatalogInfo", list);
        return success;
    }

//    @ApiOperation(value = "商品列表", notes = "", httpMethod = "GET")
//    @RequestMapping(value = "/test", method = RequestMethod.GET)
//    public ResponseBean test( @RequestParam Integer memberId, @RequestParam Integer mktId)
//    {
//        List<ProcatalogInfo> list = orderServiceImpl.test(memberId,mktId);
//        ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
//        success.getData().put("ProdCatalogInfo", list);
//        return success;
//    }
}
