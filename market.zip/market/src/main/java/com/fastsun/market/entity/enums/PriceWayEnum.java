package com.fastsun.market.entity.enums;

public enum PriceWayEnum {
    WEIGHT, PIECE
}