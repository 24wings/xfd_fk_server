package com.fastsun.market.jpa;

import com.fastsun.market.entity.common.TransArea;

import java.util.List;

import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface TransAreaJPA extends BaseRepository<TransArea, Integer>, JpaSpecificationExecutor<TransArea> {
    List<TransArea> findByMktId(Integer mktId);
}
