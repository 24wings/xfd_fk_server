package com.fastsun.market.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.fastsun.framework.bean.HttpResult;
import com.fastsun.framework.service.impl.HttpAPIService;
import com.fastsun.framework.utils.*;
import com.fastsun.market.bean.XFvoicerespBean;
import com.fastsun.market.entity.transOrder.OrderDetail;
import com.fastsun.market.entity.common.Product;
import com.fastsun.market.jpa.ProductJPA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class VoiceRecognitionServiceImpl {

    @Value("${com.fastsun.xfvoice.url}")
    private String url;
    @Value("${com.fastsun.xfvoice.appid}")
    private String appid;
    @Value("${com.fastsun.xfvoice.apikey}")
    private String apikey;

    @Autowired
    ProductJPA productJPA;
    @Autowired
    HttpAPIService httpAPIService;

    public OrderDetail matchingOrderDetail(String voiceResult,Integer memberId,Integer mktId){
        List<Product> prods = productJPA.findByMemberIdAndMktId(memberId,mktId);
        Product p = takeProduct(voiceResult,prods);
        voiceResult = voiceResult.substring(p.getName().length());
        String price ="";
        String wight ="";
        String[] arr= voiceResult.split("元");
        if(arr.length==2){
            price = arr[0];
            wight = arr[1];
            if(price.contains("点")){
                String[] pricearr = price.split("点");
                price = ParticipleUtil.moneySmartConvert(pricearr[0])+"."+ParticipleUtil.moneySmartConvert(pricearr[1]);
            }else{
                price = ParticipleUtil.moneySmartConvert(price);
            }
            if(wight.contains("点")){
                String[] wightarr = wight.split("点");
                wight = ParticipleUtil.moneySmartConvert(wightarr[0])+"."+ParticipleUtil.moneySmartConvert(wightarr[1]);
            }else{
                wight = ParticipleUtil.moneySmartConvert(wight);
            }
        }
        return buildOrderDetail(p,price, wight);
    }

    public  XFvoicerespBean dovoice(String bodybase64)  {
        String xparam = "{\"engine_type\": \"sms16k\",\"aue\": \"raw\"}";
        String base64Xparam = ImageUtil.convertString(xparam);
        String timec = System.currentTimeMillis()/1000 + "";
        String checksum = MD5Util.MD5(apikey+timec+base64Xparam);
        Map<String,Object> paramss = new HashMap();
        Map<String,String> headers = new HashMap();
        paramss.put("audio",bodybase64);
        headers.put("X-Appid",appid);
        headers.put("X-CurTime",timec);
        headers.put("X-Param",base64Xparam);
        headers.put("X-CheckSum",checksum);
        HttpResult vice = null;
        try {
            vice = httpAPIService.doPost(url,paramss,headers);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return JSON.parseObject(vice.getBody(), new TypeReference<XFvoicerespBean>(){});
    }

    //获取匹配的商品
    private Product takeProduct(String voiceProd , List<Product> prods){
        //List<Product> prods = new ArrayList<Product>();
        int maxprodIdex = 0;
        boolean hasProd = false;
        String pricingmode = "";
        String weighth = "";
        String good_code = "";

        int maxdistance = 100;
        ChangeToPinYin changeToPinYin = new ChangeToPinYin();
        Product productc = null;
        for(int i = 0; i<prods.size(); i++){
            productc = prods.get(i);
            if(voiceProd.contains(productc.getName())){
                maxprodIdex = i;
                hasProd = true;
                break;
            }else{
                String pname = productc.getName();
                int crruntdistance =  ParticipleUtil.getLevenshteinDistance(voiceProd,pname);
                if(maxdistance > crruntdistance){
                    maxprodIdex = i;
                    maxdistance = crruntdistance;
                }
            }
        }
        productc = prods.get(maxprodIdex);
        //
        if (productc.getPriceUnit().name().equals("02")) {//1
            pricingmode = "计件";
            weighth = productc.getPcsWgt().toString();
        } else {
            pricingmode = "计重";
            weighth = "";
        }
        return productc;
    }

    private OrderDetail buildOrderDetail(Product p, String price, String weight){
        OrderDetail od = new OrderDetail();
        od.setPcsWgt(p.getPcsWgt());
        od.setPrice(new BigDecimal(price));
        od.setPriceUnit(p.getPriceUnit());
        od.setProductId(p.getId());
        od.setWeight(new BigDecimal(weight));
        od.setProductName(p.getName());
//        od.setProdCatCode(p.getProdCatalog().getCatCode());
        od.setProdCatName(p.getProdCatalog().getCatName());
        //ProdCatalog prodCatalog = this.prodCatalogJPA.findByCatCode(p.get);
        return od;
    }

    public XFvoicerespBean demo() throws IOException {
        String AUDIO_PATH = "d:/Rec_002.wav";
        InputStream in = new FileInputStream(AUDIO_PATH);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024 * 4];
        int n = 0;
        while ((n = in.read(buffer)) != -1) {
            out.write(buffer, 0, n);
        }
        return dovoice(ImageUtil.encoder.encode(out.toByteArray()));
    }
}
