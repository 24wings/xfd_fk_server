package com.fastsun.market.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fastsun.framework.bean.*;
import com.fastsun.framework.entity.rbac.Market;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.service.impl.OrderNoServiceImpl;
import com.fastsun.framework.utils.*;
import com.fastsun.market.bean.*;
import com.fastsun.framework.bean.Paging;
import com.fastsun.market.entity.common.ProdCatalog;
import com.fastsun.market.entity.common.Product;
import com.fastsun.market.entity.transOrder.Order;
import com.fastsun.market.entity.transOrder.OrderDetail;
import com.fastsun.market.entity.account.AccRecvPay;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.entity.account.AccountDebt;
import com.fastsun.market.entity.account.AccountRepay;
import com.fastsun.market.entity.common.AppMsgNotify;
import com.fastsun.market.entity.common.TransFeeRule;
import com.fastsun.market.entity.enums.*;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.jpa.*;
import com.fastsun.market.service.impl.common.MsgServiceImpl;
import net.sf.json.JsonConfig;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl {
    @Autowired
    private OrderJPA orderJPA;
    @Autowired
    private AccountRepayJPA accountRepayJPA;
    @Autowired
    private CommonEntityService commonEntityService;
    @Autowired
    MemberServiceImpl memberService;
    @Autowired
    PasswordEncoder encoder;
    @Autowired
    RequestUtil requestUtil;
    @Autowired
    MemberJPA memberJPA;
    @Autowired
    CustomerJPA customerJPA;
    @Autowired
    TransFeeRuleJPA transFeeRuleJPA;
    @Autowired
    RecPaySubjectJPA recPaySubjectJPA;
    @Autowired
    AccRecvPayJPA accRecvPayJPA;
    @Autowired
    AccountDebtJPA accountDebtJPA;
    @Autowired
    TransFeeRuleServiceImpl transFeeRuleService;
    @Autowired
    OrderNoServiceImpl orderNoService;

    @Autowired
    JPushServiceImpl jPushServiceImpl;
    @Autowired
    AppMsgNotifyJPA appMsgNotifyJPA;
    @Autowired
    MemberAccountJPA memberAccountJPA;
    @Autowired
    OrderServiceImpl orderService;
@Autowired
ProductJPA productJPA;
@Autowired
ProdCatalogJPA prodCatalogJPA;
@Autowired
RedisTemplate redisTemplate;
    @Autowired
    @PersistenceContext
    private EntityManager entityManager;
    private Session session;
    @Autowired
    private MsgServiceImpl msgService;



    /*
     * 订单创建并支付，订单状态为待支付-TOBE_PAY
     *  首先，通过cardNo查询出会员和账户的信息，
     *  计算手续费
     *  生成订单信息，和订单详细信息
     *  根据支付方式，如果是现金交易，更改员工现金账户余额  和 新增员工账户收支记录
     *  更改卖方账户余额，账户收支记录，更改市场手续费账户余额，收支记录
     *  如果是会员账户余额交易，更改买卖双方账户余额和账户收支记录，市场账户余额和收支记录
     *  最后更改订单的状态。
     *  需要考虑支付失败时，所有涉及到账户余额的变动，建议使用事务控制，失败统一回滚。
     */
    @Transactional(rollbackFor = {RuntimeException.class, Exception.class}, propagation = Propagation.NOT_SUPPORTED)
//一般情况下，spring管理事务只会回滚RunTimeException
    public Order orderCreate(HttpServletRequest request, OrderCreateRq orderCreateRq, OrderStatus status) throws Exception {

        Order order = new Order();
        String orderNo = null;
        orderNo = "M0001" + String.format("%05d", this.orderNoService.getOrderNo("orderNoCreateKey"));
        order.setOrderNo(orderNo);
        long count = this.commonEntityService.getRecordCount(RequestUtil.getQueryParameter(order, "or", "orderNo"), order.getClass());
        if (count > 0) {
            throw new Exception("订单号重复！");
        }
        if (status == null) {
            order.setStatus(OrderStatus.SUBMIT);
        } else {
            order.setStatus(status);
        }
        order.setApAmt(orderCreateRq.getApAmt());
        order.setTotalWeight(orderCreateRq.getTotalWeight());
        order.setCreateWay(orderCreateRq.getCreateWay());
        order.setMktId(orderCreateRq.getMktId());
        order.setTransAreaId(orderCreateRq.getTransAreaId());
        order.setCreateTime(new Date());
        order.setPayType(orderCreateRq.getPayType());
        if (orderCreateRq.getOrderDetails() != null) {
            orderCreateRq.getOrderDetails().forEach(orderDetail -> {
                if (orderDetail.getId() != null) {
                    orderDetail.setId(null);
                }
            });
        }
        order.setOrderDetails(orderCreateRq.getOrderDetails());
        //买家会员
        Member buyerMember = null;
        if (orderCreateRq.getCardNo() != null && !orderCreateRq.getCardNo().isEmpty()) {
            buyerMember = this.memberService.findMemberByCardNo(orderCreateRq.getCardNo());
            order.setBuyerInfo(buyerMember.getName());
        } else if (orderCreateRq.getBuyerMemId() != null) {
            buyerMember = this.memberJPA.findById(orderCreateRq.getBuyerMemId()).get();
            order.setBuyerInfo(buyerMember.getName());
        }
        if (buyerMember == null) {
            order.setBuyerInfo(orderCreateRq.getBuyerInfo());
        } else {
            order.setBuyerMemId(buyerMember.getId());
            order.setBuyerCustId(buyerMember.getCustomerId());
            order.setBuyerMemNo(buyerMember.getNo());
        }
        //卖家会员
        Member sellerMember = null;
        if (orderCreateRq.getSellerMemId() != null) {
            sellerMember = this.memberJPA.findById(orderCreateRq.getSellerMemId()).get();
        } else {
            sellerMember = this.memberJPA.findByNo(orderCreateRq.getSellerMemNo());
        }
        if (sellerMember == null) {
            throw new Exception("未查询到卖家信息！");
        }
        order.setSellerMemId(sellerMember.getId());
        order.setSellerMemNo(sellerMember.getNo());
        order.setSellerMemName(sellerMember.getName());
        order.setSellerCustId(orderCreateRq.getSellerCustId());
        computeFee(order, 1, false, null, null);
        order.setPayAmt(order.getApAmt().add(order.getBuyerFee()));
        //订单相关信息
        //TODO:订单号无前缀，需修改
        this.requestUtil.setCreatorAndCreatorId(order, requestUtil.getLoginUser(request));
        return this.saveOrder(order);
    }

    /**
     * @param request    HttpServletRequest(写订单支付的结算人员信息)
     * @param orderPayRq 订单支付DTO
     * @return 订单
     * @throws Exception
     */
    @Transactional(rollbackFor = {RuntimeException.class, Exception.class}, propagation = Propagation.NOT_SUPPORTED)
    public Order oderPay(HttpServletRequest request, OrderPayRq orderPayRq) throws Exception {
        Order order = this.orderJPA.findByOrderNo(orderPayRq.getOrderNo());
        //查询买家信息
        MemberAccTuple<Member, Account> sellerMemberAccTuple = this.memberService.findByMemNo(null, order.getSellerMemId());
        MemberAccTuple<Member, Account> buyerMemberAccTuple = null;
        if(order.getBuyerMemId() != null){
            buyerMemberAccTuple = this.memberService.findByMemNo(null, order.getBuyerMemId());
            BigDecimal buyerRealityAmt = order.getPayAmt().add(order.getBuyerFee());
            Member buyerMember = buyerMemberAccTuple.first;
            Integer count = buyerMember.getErrorCount();
            if (count == null) {
                count = 0;
            }
            if (count >= 10) {
                throw new Exception("错误次数超过10次，必须解锁!");
            }
            if (!encoder.matches(orderPayRq.getPayPassword(), buyerMember.getPayPassword())) {
                count++;
                buyerMember.setErrorCount(count);
                this.memberJPA.save(buyerMember);
                throw new Exception("支付密码有误！");
            }
            BigDecimal afterBlance = buyerMemberAccTuple.second.getBalAmt().subtract(buyerRealityAmt);
            if (afterBlance.compareTo(BigDecimal.ZERO) < 0) {
                throw new Exception("会员现金账户余额不足！");
            }
            createAccRecvPayAndSave(buyerMemberAccTuple.second, buyerMemberAccTuple.first, sellerMemberAccTuple.second, -1, order.getOrderNo(), order.getApAmt(), orderPayRq.getOrderType(), SubjectCodeEnum.TRANS_AMOUNT.getId(), SubjectCodeEnum.TRANS_AMOUNT.getName());
            createAccRecvPayAndSave(sellerMemberAccTuple.second, sellerMemberAccTuple.first, buyerMemberAccTuple.second, 1, order.getOrderNo(), order.getApAmt(), orderPayRq.getOrderType(), SubjectCodeEnum.TRANS_AMOUNT.getId(), SubjectCodeEnum.TRANS_AMOUNT.getName());
        }else{
            createAccRecvPayAndSave(sellerMemberAccTuple.second, sellerMemberAccTuple.first,null, 1, order.getOrderNo(), order.getApAmt(), orderPayRq.getOrderType(), SubjectCodeEnum.TRANS_AMOUNT.getId(), SubjectCodeEnum.TRANS_AMOUNT.getName());
        }
        if (order.getPayType().equals(PayType.CASH)) {
            UserAccTuple<User, Account> userAccTuple = this.memberService.findByUserId(order.getCreatorId());
            createAccRecvPayAndSave(userAccTuple.second, null, null, 1, order.getOrderNo(), order.getPayAmt(), orderPayRq.getOrderType(), null, null);
        }
        //市场账户的余额变动和账户收支记录
        MarketAccTuple<Market, Account> marketAccTuple = this.memberService.findByMarketId(order.getMktId());
        if (order.getBuyerFee().compareTo(BigDecimal.ZERO) > 0) {
            computeFee(order, -1, true, marketAccTuple.second, buyerMemberAccTuple.second);
        }
        if (order.getSellerFee().compareTo(BigDecimal.ZERO) > 0) {
            computeFee(order, -1, true, marketAccTuple.second, buyerMemberAccTuple.second);
        }
        this.requestUtil.setActorAndActorId(order, this.requestUtil.getLoginUser(request));
        if (order.getPayType() == null) {
            order.setPayType(orderPayRq.getPayType());
        }
        order.setActTime(new Date());
        order.setStatus(OrderStatus.PAID);
        return (Order) this.commonEntityService.update(order);
    }

    /**
     * 创建收支记录
     *
     * @param currentAccount 当前账户
     * @param targetAccount  来源账户
     * @param io             买卖标志
     * @param orderNo        订单号
     * @param transAmt       交易金额
     * @param orderType      订单类型
     * @return 收支记录
     */
    @Transactional(rollbackFor = {RuntimeException.class,Exception.class},propagation = Propagation.NOT_SUPPORTED)
    public AccRecvPay createAccRecvPayAndSave(Account currentAccount,Member currentMember,Account targetAccount, Integer io , String orderNo, BigDecimal transAmt, OrderType orderType,Integer subjectId,String subjectName) throws Exception {
        AccRecvPay accRecvPay = new AccRecvPay();
        accRecvPay.setAccountId(currentAccount.getId());
        accRecvPay.setAccountName(currentAccount.getName());
        accRecvPay.setFrozenAmt(currentAccount.getFrozenAmt());
        accRecvPay.setSubjectId(subjectId);
        accRecvPay.setSubjectName(subjectName);
        String recvPayNo = "P0001" + String.format("%05d", this.orderNoService.getOrderNo("recvPayNoCreateKey"));
        accRecvPay.setRecvPayNo(recvPayNo);
        StringBuffer stringBuffer = new StringBuffer("尊敬的用户，您的账户在"+DateUtil.parse(new Date())+", ");
        if (targetAccount != null) {
            accRecvPay.setToAccountId(targetAccount.getId());
            accRecvPay.setToAccountName(targetAccount.getName());
        }
        if (orderType != null) {
            accRecvPay.setOrderType(orderType);
        } else {
            accRecvPay.setOrderType(OrderType.TRANS);
        }
        if (orderNo != null) {
            accRecvPay.setOrderNo(orderNo);
        }
//        stringBuffer.append(accRecvPay.getOrderNo());
//        stringBuffer.append(" 的订单中");
        accRecvPay.setCreateTime(new Date());
        accRecvPay.setMktId(currentAccount.getMktId());
        BigDecimal balAmt = null;
        BigDecimal availAmt = null;
        if (io == -1) {
            balAmt = currentAccount.getBalAmt().subtract(transAmt);
            availAmt = currentAccount.getBalAmt().subtract(transAmt);
            accRecvPay.setIo(-1);
            accRecvPay.setAmount(transAmt);
            accRecvPay.setBalAmt(balAmt);
            accRecvPay.setAvailAmt(availAmt);
            stringBuffer.append("支出" + transAmt + "元，当前可用余额" + availAmt + "元");
        } else if (io == 1) {
            balAmt = currentAccount.getBalAmt().add(transAmt);
            availAmt = currentAccount.getBalAmt().add(transAmt);
            accRecvPay.setIo(1);
            accRecvPay.setAmount(transAmt);
            accRecvPay.setBalAmt(currentAccount.getBalAmt().add(transAmt));
            accRecvPay.setAvailAmt(currentAccount.getBalAmt().add(transAmt));
            stringBuffer.append("收入" + transAmt + "元，当前可用余额" + availAmt + "元");
        }
        //存收支，改余额，发通知
        this.accRecvPayJPA.save(accRecvPay);
        currentAccount.setBalAmt(balAmt);
        currentAccount.setAvailAmt(availAmt);
        this.commonEntityService.update(currentAccount);
        Customer memberOfCustomer = null;
        if (currentMember != null) {
            for (Customer customer : currentMember.getCustomers()) {
                if (currentMember.getCustomerId() == customer.getId()) {
                    memberOfCustomer = customer;
                    break;
                }
            }
        }
        if(memberOfCustomer != null ){
            if(memberOfCustomer.getRegistrationId() != null){
                JsonConfig jsonConfig = new JsonConfig();
                jsonConfig.registerJsonValueProcessor(Date.class , new JsonDateValueProcessorUtil());
                net.sf.json.JSONObject json = net.sf.json.JSONObject.fromObject(accRecvPay,jsonConfig);
                json.put("phone",memberOfCustomer.getMobi());
                json.put("no",currentAccount.getNo());
                if(!msgService.checkDisabledMsgTypes(currentMember.getCustomerId(),MsgType.ACC_AMT)) {
                    AppMsgNotify appMsgNotify = this.appMsgNotifyJPA.save(this.createAppMsg(null, currentMember, json.toString(), stringBuffer.toString(), "账户变动", MsgType.ACC_AMT));
                    Map<String, String> extral = new HashMap<String, String>();
                    extral.put("appMsgNotifyId", appMsgNotify.getId() + "");
                    this.jPushServiceImpl.sendRegistrationIdNotify(stringBuffer.toString(), memberOfCustomer.getRegistrationId(), extral);
                }
            }
        }
        return accRecvPay;
    }

    /**
     * 计算订单的交易手续费
     * @param order 订单信息
     * @param io 买卖标志
     * @param isOrderPay 是否是下单计算手续费
     * @return 已计算完手续费的订单信息
     * @throws Exception
     */
    public Order computeFee(Order order, Integer io, Boolean isOrderPay, Account marketAcc, Account memberAcc) throws Exception {
        PriceUnit priceUnit = order.getOrderDetails().get(0).getPriceUnit();
        TransFeeRule transFeeRule = new TransFeeRule();
        transFeeRule.setMktId(order.getMktId());
        transFeeRule.setTxnId(order.getTransAreaId());
        transFeeRule.setIo(io);
        transFeeRule.setEnabled(true);
        Paging<TransFeeRule> transFeeRules = this.transFeeRuleService.queryTransFeeRule(RequestUtil.getQueryParameter(transFeeRule, "and", "mktId", "txnId", "io", "enabled"));
        TransFeeRule transFeeRuleDB = null;
        BigDecimal feeRateAmt = new BigDecimal(0);
        BigDecimal feeRateWgt = new BigDecimal(0);
        BigDecimal feeFixed = new BigDecimal(0);
        BigDecimal reallyFee = new BigDecimal(0);
        BigDecimal totalFee = new BigDecimal(0);
        if (transFeeRules.getRows() != null) {
            for (int i = 0; i < transFeeRules.getRows().size(); i++) {
                transFeeRuleDB = transFeeRules.getRows().get(i);
                feeRateAmt = order.getApAmt().multiply(transFeeRuleDB.getFeeRateAmt().divide(new BigDecimal(1000)));
                feeFixed = transFeeRuleDB.getFeeFixed();
                if (PriceUnit.KG.equals(priceUnit)) {
                    feeRateWgt = order.getTotalWeight().multiply(transFeeRuleDB.getFeeRateWgt());
                } else if (PriceUnit.JIN.equals(priceUnit)) {
                    feeRateWgt = order.getTotalWeight().divide(new BigDecimal(2)).multiply(transFeeRuleDB.getFeeRateWgt());
                }
                reallyFee = feeRateAmt.add(feeRateWgt).add(feeFixed);
                if (reallyFee.compareTo(transFeeRuleDB.getFeeMin()) < 0) {
                    reallyFee = transFeeRuleDB.getFeeMin();
                } else if (reallyFee.compareTo(transFeeRuleDB.getFeeMax()) > 0) {
                    reallyFee = transFeeRuleDB.getFeeMax();
                }
                if (isOrderPay) {
                    this.createAccRecvPayAndSave(marketAcc, null, memberAcc, 1, order.getOrderNo(), reallyFee, OrderType.TRANS, transFeeRuleDB.getSubjectId(), transFeeRuleDB.getSubjectName());
                    this.createAccRecvPayAndSave(memberAcc, null, marketAcc, -1, order.getOrderNo(), reallyFee, OrderType.TRANS, transFeeRuleDB.getSubjectId(), transFeeRuleDB.getSubjectName());
                }
                totalFee = totalFee.add(reallyFee);
            }
        }
        if (io != null) {
            if (io == 1) {
                order.setSellerFee(totalFee);
            } else if (io == -1) {
                order.setBuyerFee(totalFee);
                return order;
            }
        }
        if (!isOrderPay) {
            return computeFee(order, -1, isOrderPay, null, null);
        }
        return order;
    }

    public Order saveOrder(Order order) {
        List<OrderDetail> orderDetails = order.getOrderDetails();
        OrderDetail orderDetail = null;
        for (int i = 0; i < orderDetails.size(); i++) {
            orderDetail = orderDetails.get(i);
            orderDetail.setOrder(order);
            order.addOrderDetail(orderDetail);
        }
        return this.orderJPA.saveAndFlush(order);
    }

    public Order getOrderInfo(String orderNo) {
        return this.orderJPA.findByOrderNo(orderNo);
    }

    /**
     * 回填买家的信息
     * @param base64Str base64密码二维码串，含订单号，业务类型BusenessType
     * @param customerId 买家的手机用户id
     * @return 订单信息
     * @throws Exception
     */
    public Order exeQCode(String base64Str, Integer customerId) throws Exception {
        String str = ImageUtil.deConvertString(base64Str);
        String[] strings = str.split(",");
        Order order = this.orderJPA.findByOrderNo(strings[0]);
        if (order == null) {
            throw new Exception("未查询到订单信息！");
        } else if (order.getStatus().equals(OrderStatus.PAID)) {
            throw new Exception("订单已支付成功！");
        }
        Customer customer = (Customer) this.commonEntityService.findById(Customer.class, customerId);
        Order orderDB = null;
        if (customer == null) {
            throw new Exception("未查询到买家信息！");
        } else {
            Member member = this.memberJPA.findById(customer.getMemberId()).get();
//            if(member.getId() == order.getSellerMemId()){
//               throw new Exception("买家不能和卖家相同！");
//            }else {
//                order.setBuyerCustId(customerId);
//                order.setBuyerMemId(member.getId());
//                order.setStatus(OrderStatus.TOBE_PAY);
//                orderDB = (Order) this.commonEntityService.update(order);
//            }
            order.setBuyerInfo(member.getName());
            order.setBuyerCustId(customerId);
            order.setBuyerMemId(member.getId());
            if (PayType.FS_C2B.equals(order.getPayType())) {
                order.setStatus(OrderStatus.TOBE_PAY);
            } else if (PayType.FS_CREDIT.equals(order.getPayType())) {
                order.setStatus(OrderStatus.SUBMIT);
            }
            orderDB = (Order) this.commonEntityService.update(order);
        }
        return orderDB;
    }

    /**
     * @param orderNo 订单号
     * @return 订单状态
     */
    public OrderStatus queryOrderStatus(String orderNo) {
        Order order = this.orderJPA.findByOrderNo(orderNo);
        return order.getStatus();
    }

    public Order changeStatus(String orderNo, OrderStatus status) {
        Order order = this.orderJPA.findByOrderNo(orderNo);
        if (status.equals(OrderStatus.SELLER_AGREE)) {
            order.setStatus(OrderStatus.TOBE_PAY);
        } else {
            order.setStatus(status);
        }
        return (Order) this.commonEntityService.update(order);
    }

    /**
     * 赊销支付，需要买卖双方出手续费
     *  两笔收支记录
     * @param orderPayRq 订单支付DTO
     * @return 赊销记录
     * @throws Exception
     */
    @Transactional
    public Order sellOnCreditOrderPay(OrderPayRq orderPayRq) throws Exception {
        Order order = this.orderJPA.findByOrderNo(orderPayRq.getOrderNo());
//        boolean flag = this.memberService.confirePayPassword(order.getBuyerMemId(),orderPayRq.getPayPassword());
//        if(!flag){
//            throw new Exception("支付密码错误！");
//        }
        MarketAccTuple<Market, Account> marketAccTuple = this.memberService.findByMarketId(order.getMktId());
        Account marketAccount = marketAccTuple.second;
        BigDecimal buyerFee = order.getBuyerFee();
        BigDecimal sellerFee = order.getSellerFee();
        MemberAccTuple<Member, Account> sellerMemberAcc = this.memberService.findByMemNo(null, order.getSellerMemId());
        Account account = sellerMemberAcc.second;
        if (sellerFee.compareTo(BigDecimal.ZERO) > 0) {
//            this.createAccRecvPayAndSave(marketAccount,account,1,order.getOrderNo(),sellerFee,OrderType.TRANS);
//            this.createAccRecvPayAndSave(account,marketAccount,-1,order.getOrderNo(),sellerFee,OrderType.TRANS);
            this.computeFee(order, null, true, marketAccount, account);
        }
        MemberAccTuple<Member, Account> buyerMemberAcc = this.memberService.findByMemNo(null, order.getBuyerMemId());
        Account buyerAcc = buyerMemberAcc.second;
        if (buyerFee.compareTo(BigDecimal.ZERO) > 0) {
//            this.createAccRecvPayAndSave(marketAccTuple.second,buyerAcc,1,order.getOrderNo(),buyerFee,OrderType.TRANS);
//            this.createAccRecvPayAndSave(buyerAcc,marketAccTuple.second,-1,order.getOrderNo(),buyerFee,OrderType.TRANS);
            this.computeFee(order, null, true, marketAccount, buyerAcc);
        }
        this.accountDebtJPA.save(this.createAccountDebt(account,buyerAcc,order));
        order.setStatus(OrderStatus.PAID);
        return (Order) this.commonEntityService.update(order);
    }

    /**
     *
     * @param sellerAccount 卖家会员账户
     * @param buyerAccount  买家会员账户
     * @param order         关联订单
     * @return 赊销记录
     */
    @Transactional
    public AccountDebt createAccountDebt(Account sellerAccount, Account buyerAccount, Order order) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        AccountDebt accountDebt = new AccountDebt();
        accountDebt.setCreateTime(new Date());
        //TODO:流水号前缀和取序号的key,需规范
        accountDebt.setDebtNo("M0001" + sdf.format(new Date()) + String.format("%05d", this.orderNoService.getOrderNo("debtNoCreateKey")));
        accountDebt.setDebtAmt(order.getApAmt());
        accountDebt.setDebteeAccId(sellerAccount.getId());
        accountDebt.setDebteeAccName(sellerAccount.getName());
        accountDebt.setDebtorAccId(buyerAccount.getId());
        accountDebt.setDebtorAccName(buyerAccount.getName());
        accountDebt.setSubjectId(1);
        accountDebt.setSubjectName("交易货款");
        accountDebt.setRepayAmt(new BigDecimal(0));
        accountDebt.setOrderType(OrderType.TRANS);
        accountDebt.setOrderNo(order.getOrderNo());
        accountDebt.setMktId(order.getMktId());
        accountDebt.setRepaymentDays(0);
        return accountDebt;
    }

    /**
     * 线上还款，直接发起支付，减掉还款方钱包余额，改还款方余额，改收款方余额，双方发送余额变动通知
     * @param accountRepayRq 还款记录DTO
     * @return 还款记录
     * @throws Exception
     */
    @Transactional
    public AccountRepay onlineRepay(AccountRepayRq accountRepayRq) throws Exception {
        BigDecimal reallyAmt = accountRepayRq.getRepayAmt();
        MemberAccTuple<Member, Account> debtorMemberAccTuple = this.memberService.findByMemNo(null, accountRepayRq.getMemberId());
        Member debtorMember = debtorMemberAccTuple.first;
        Account debtorAccount = debtorMemberAccTuple.second;
        Integer count = debtorMember.getErrorCount();
        if (count == null) {
            count = 0;
        }
        if (count >= 10) {
            throw new Exception("错误次数超过10次，必须解锁!");
        }
        if (!encoder.matches(accountRepayRq.getPayPassword(), debtorMember.getPayPassword())) {
            count++;
            debtorMember.setErrorCount(count);
            this.memberJPA.save(debtorMember);
            throw new Exception("支付密码不匹配！");
        }
        AccountDebt accountDebt = this.accountDebtJPA.findById(accountRepayRq.getDeptId()).get();
        if (reallyAmt.compareTo(new BigDecimal(0.01)) < 0) {
            throw new Exception("还款金额小于0.01！");
        }
        if (reallyAmt.compareTo(accountDebt.getDebtAmt().subtract(accountDebt.getRepayAmt())) > 0) {
            throw new Exception("还款金额大于所欠余额！");
        }
        Account debteeAccount = (Account) this.commonEntityService.findById(Account.class, accountDebt.getDebteeAccId());
        this.createAccRecvPayAndSave(debteeAccount, null, debtorAccount, 1, accountDebt.getOrderNo(), reallyAmt, OrderType.TRANS, accountDebt.getSubjectId(), accountDebt.getSubjectName());
        this.createAccRecvPayAndSave(debtorAccount, null, debteeAccount, -1, accountDebt.getOrderNo(), reallyAmt, OrderType.TRANS, accountDebt.getSubjectId(), accountDebt.getSubjectName());
        accountDebt.setRepayAmt(accountDebt.getRepayAmt().add(reallyAmt));
        this.commonEntityService.update(accountDebt);
        return this.accountRepayJPA.save(this.createAccountRepay(accountDebt, reallyAmt, false));
    }

    /**
     * 线下还款申请，买家发起申请，创建还款记录，推送通知到收款会员Customer
     * @param accountRepayRq 还款记录DTO
     * @return 新还款记录
     */
    public AccountRepay offlineRepayApply(AccountRepayRq accountRepayRq) {
        AccountDebt accountDebt = this.accountDebtJPA.findById(accountRepayRq.getDeptId()).get();
        AccountRepay accountRepay = this.accountRepayJPA.save(this.createAccountRepay(accountDebt, accountRepayRq.getRepayAmt(), false));
        Customer debteeCustomer = this.getMemberOfCustomer(accountDebt.getOrderNo(), 1);
        String content = "";
        try {
            this.jPushServiceImpl.sendRegistrationIdNotify(content, debteeCustomer.getRegistrationId(), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return accountRepay;
    }

    /**
     *  改还款记录confirmed,改赊销记录余额
     * @param id 还款记录Id
     * @return 还款记录
     */
    @Transactional
    public AccountRepay offlineRepayConfirm(HttpServletRequest request,String payPassword, Integer id) throws Exception {
        AccountRepay accountRepay = this.accountRepayJPA.findById(id).get();
        AccountDebt accountDebt = this.accountDebtJPA.findById(accountRepay.getDeptId()).get();
        Member debtorMember = this.getMemberByOrderNo(accountDebt.getOrderNo(), 1);
        Member member = this.getMemberByOrderNo(accountDebt.getOrderNo(), -1);
        if (member.getErrorCount() >= 10) {
            throw new Exception("支付密码错误次数超限！请到柜台解锁！");
        } else {
            if (!encoder.matches(payPassword, member.getPayPassword())) {
                member.setErrorCount(member.getErrorCount() + 1);
                this.commonEntityService.update(member);
                if (member.getErrorCount() < 10) {
                    throw new Exception("支付密码不匹配！还有" + (10 - member.getErrorCount()) + "次机会！");
                } else if (member.getErrorCount() == 10) {
                    throw new Exception("支付密码已锁定！请到柜台解锁！");
                }
            }
        }

        if (accountRepay.getRepayAmt().compareTo(new BigDecimal(0.01)) < 0) {
            throw new Exception("还款金额小于0.01！");
        }
        if (accountRepay.getRepayAmt().compareTo(accountDebt.getDebtAmt().subtract(accountDebt.getRepayAmt())) > 0) {
            throw new Exception("还款金额大于所欠余额！");
        }
        accountDebt.getDebtAmt().subtract(accountDebt.getRepayAmt()).subtract(accountRepay.getRepayAmt());
        this.commonEntityService.update(accountDebt);
        accountRepay.setRepayStatus(RepayStatus.RECEIVED);
        accountRepay.setConfirmTime(new Date());
        Order order = orderJPA.findByOrderNo(accountRepay.getOrderNo());
        Customer customer = this.customerJPA.findById(debtorMember.getCustomerId()).get();
        String content = "尊敬的用户，编号为"+debtorMember.getNo()+"的"+accountRepay.getAccountName()+",对您发起了线下还款，订单号为" +accountRepay.getOrderNo()+ ",金额：" + accountRepay.getRepayAmt() + ",已收到请确认!";;
        if(!msgService.checkDisabledMsgTypes(debtorMember.getCustomerId(),MsgType. REPAY_APPLY )) {
            AppMsgNotify appMsgNotify = this.createAppMsg(request, debtorMember, new ObjectMapper().writeValueAsString(accountRepay), content, "线下还款通知", MsgType. REPAY_APPLY );
            AppMsgNotify appMsgNotifyDB = this.appMsgNotifyJPA.save(appMsgNotify);
            Map<String, String> extral = new HashMap<>();
            extral.put("appMsgNotifyId", String.valueOf(appMsgNotifyDB.getId()));
            this.jPushServiceImpl.sendRegistrationIdNotify(content, customer.getRegistrationId(), extral);
        }
        return (AccountRepay) this.commonEntityService.update(accountRepay);
    }

    public void offlineRepayRefused(HttpServletRequest request,Integer id, RepayStatus repayStatus) throws Exception {
        AccountRepay accountRepay = this.accountRepayJPA.findById(id).get();
        AccountDebt accountDebt = this.accountDebtJPA.findById(accountRepay.getDeptId()).get();
        Member debtorMember = this.getMemberByOrderNo(accountDebt.getOrderNo(), 1);
        accountRepay.setRepayStatus(repayStatus);
        Customer customer = this.customerJPA.findById(debtorMember.getCustomerId()).get();
        String content = "尊敬的用户，编号为"+debtorMember.getNo()+"的"+accountRepay.getAccountName()+",对您发起了线下还款，订单号为" +accountRepay.getOrderNo()+ ",金额：" + accountRepay.getRepayAmt() + ",未收到请确认!";;
        if(!msgService.checkDisabledMsgTypes(debtorMember.getCustomerId(),MsgType.REPAY_APPLY)) {
            AppMsgNotify appMsgNotify = this.createAppMsg(request, debtorMember, new ObjectMapper().writeValueAsString(accountRepay), content, "现金还款", MsgType.REPAY_APPLY);
            AppMsgNotify appMsgNotifyDB = this.appMsgNotifyJPA.save(appMsgNotify);
            Map<String, String> extral = new HashMap<>();
            extral.put("appMsgNotifyId", String.valueOf(appMsgNotifyDB.getId()));
            this.jPushServiceImpl.sendRegistrationIdNotify(content, customer.getRegistrationId(), extral);
        }
        this.commonEntityService.update(accountRepay);
    }

    /**
     *
     * @param accountDebt 赊销记录
     * @param repayAmt    还款金额
     * @return 新还款记录
     */
    public AccountRepay createAccountRepay(AccountDebt accountDebt, BigDecimal repayAmt, Boolean isNeedConfirm) {
        AccountRepay accountRepay = new AccountRepay();
        accountRepay.setCreateTime(new Date());
        if (isNeedConfirm) {
            accountRepay.setRepayStatus(RepayStatus.WAITRECEIVED);
        } else {
            accountRepay.setRepayStatus(RepayStatus.RECEIVED);
            accountRepay.setConfirmTime(new Date());
        }
        accountRepay.setAccountName(accountDebt.getDebtorAccName());
        accountRepay.setDeptId(accountDebt.getId());
        accountRepay.setOrderNo(accountDebt.getOrderNo());
        accountRepay.setMktId(accountDebt.getMktId());
        accountRepay.setRepayAmt(repayAmt);
        accountRepay.setRepayNo("M0001" + String.format("%05d", this.orderNoService.getOrderNo("accountRepayNoCreateKey")));
        return accountRepay;
    }

    /**
     *
     * @param orderNo 订单号
     * @param flag    买卖标志
     * @return
     */
    public Customer getMemberOfCustomer(String orderNo, Integer flag) {
        Order order = this.orderJPA.findByOrderNo(orderNo);
        Member member = null;
        Customer customer = null;
        if (flag == -1) {
            member = this.memberJPA.findById(order.getBuyerMemId()).get();
        } else if (flag == 1) {
            member = this.memberJPA.findById(order.getSellerMemId()).get();
        }
        for (Customer customerDB : member.getCustomers()) {
            if (member.getCustomerId() == customerDB.getId()) {
                customer = customerDB;
                break;
            }
        }
        return customer;
    }

    public Customer getMemberOfCustomer(Member member) {
        Customer customer = null;
        for (Customer customerDB : member.getCustomers()) {
            if (member.getCustomerId() == customerDB.getId()) {
                customer = customerDB;
                break;
            }
        }
        return customer;
    }

    /**
     *
     * @param orderNo 订单号
     * @param flag    买卖标志
     * @return
     */
    public Member getMemberByOrderNo(String orderNo, Integer flag) {
        Order order = this.orderJPA.findByOrderNo(orderNo);
        Member member = null;
        Customer customer = null;
        if (order.getBuyerMemId() != null && flag == -1) {
            member = this.memberJPA.findById(order.getBuyerMemId()).get();
        } else if (order.getSellerMemId() != null && flag == 1) {
            member = this.memberJPA.findById(order.getSellerMemId()).get();
        }
        return member;
    }

    public List<AccountRepay> getAccountRepayList(QueryParameter queryParameter, Integer io,RepayStatus status) {
        Paging paging = getAccountDebtList(queryParameter, io);
        List<Integer> debtIds = new ArrayList<>();
        AccountDebt accountDebt = null;
        for (int i = 0; i < paging.getRows().size(); i++) {
            accountDebt = (AccountDebt) paging.getRows().get(i);
            debtIds.add(accountDebt.getId());
        }
        Optional<List<AccountRepay>> accountRepays = Optional.of(this.accountRepayJPA.findByDeptIdIn(debtIds));
        if(Objects.isNull(status) || StringUtils.isEmpty(String.valueOf(status))){
            return accountRepays.get();
        }
        return accountRepays.get().stream().filter(accountRepay -> accountRepay.getRepayStatus() == status).collect(Collectors.toList());
    }

    /**
     *
     * @param queryParameter 查询QueryParameter，有memberId,先拿到再剔除
     * @param io             -1 我欠别人的，1 别人欠我的
     * @return
     */
    public Paging getAccountDebtList(QueryParameter queryParameter, Integer io) {
            Integer memberId = null;
        for (QueryCondition queryCondition : queryParameter.getQueryConditions()) {
            if ("memberId".equals(queryCondition.getField())) {
                memberId = (Integer) queryCondition.getValue();
                queryParameter.getQueryConditions().remove(queryCondition);
                break;
            }
        }
        MemberAccTuple<Member, Account> memberAccTuple = null;
        if (memberId != null) {
            try {
                memberAccTuple = this.memberService.findByMemNo(null, memberId);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (io == -1) {
            queryParameter.getQueryConditions().add(new QueryCondition("debtorAccId", "=", memberAccTuple.second.getId(), "and"));
        } else {
            queryParameter.getQueryConditions().add(new QueryCondition("debteeAccId", "=", memberAccTuple.second.getId(), "and"));
        }
        return this.commonEntityService.findPagedEntity(queryParameter, AccountDebt.class);
    }

    public List<AccountDebt> getAccountDebts(Integer debtorAccId,Integer debteeAccId){
        List<AccountDebt> accountDebts = this.accountDebtJPA.findByDebtorAccIdAndDebteeAccId(debtorAccId,debteeAccId);
        accountDebts.stream().forEach(accountDebt -> {
            List<AccountRepay> accountRepays = this.accountRepayJPA.findByDeptIdAndRepayStatus(accountDebt.getId(),RepayStatus.WAITRECEIVED);
            BigDecimal bigDecimal = new BigDecimal(
                    accountRepays.stream().mapToDouble(accountRepay-> accountRepay.getRepayAmt().doubleValue()).sum()).setScale(2,BigDecimal.ROUND_UP);
            accountDebt.setTbConfireAmt(bigDecimal);
        });
        return accountDebts;
    }

    /**
     * 通过memberId查询出账户Id,再通过此Id和mktId查询出欠款的集合，统计所欠总金额
     * @param orderNo  订单号
     * @return 当前买家会员所欠总金额
     */
    public BigDecimal qryBuyerCredit(String orderNo) throws Exception {
        Order order = this.orderJPA.findByOrderNo(orderNo);
        Integer buyerMemberId = order.getBuyerMemId();
        if (buyerMemberId == null) {
            return null;
        }
        return qryBuyerCredit(buyerMemberId, order.getMktId());
    }

    public String[] qryBuyerCreditByQcode(String base64Str) throws Exception {
        String memberIdAndMktId = Optional.ofNullable(ImageUtil.deConvertString(base64Str)).orElseThrow(()->new Exception(""));
        Integer memberId = Optional.of(memberIdAndMktId.split(",")[0]).map(Integer::parseInt).get();
        Member member = this.memberJPA.findById(memberId).get();
        Integer mktId = Optional.of(memberIdAndMktId.split(",")[0]).map(Integer::parseInt).get();
        return new String[]{member.getName(),String.valueOf(qryBuyerCredit(memberId,mktId))};
    }

    public BigDecimal qryBuyerCredit(Integer memberId, Integer mktId) throws Exception {
        MemberAccTuple<Member, Account> memberAccTuple = this.memberService.findByMemNo(null, memberId);
        List<AccountDebt> accountDebts = this.accountDebtJPA.findByDebtorAccIdAndMktId(memberAccTuple.second.getId(), mktId);
        return new BigDecimal(accountDebts.stream().mapToDouble(accountDebt -> accountDebt.getDebtAmt().doubleValue()).sum()).setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    public Order orderDetail(String orderNo) {
        return this.orderJPA.findByOrderNo(orderNo);

    }

    public List<TempOrderSimpleRq> getTempOrderSimpleList(Integer memberId, Integer mktId) {
        List<Order> orders = this.orderJPA.findBySellerMemIdAndStatus(memberId, OrderStatus.TEMP);
        List<TempOrderSimpleRq> tempOrderSimpleRqs = new ArrayList<>();
        TempOrderSimpleRq tempOrderSimpleRq = null;
        Customer customer = null;
        for (Order order : orders) {
            tempOrderSimpleRq = new TempOrderSimpleRq();
            tempOrderSimpleRq.setOrderNo(order.getOrderNo());
            tempOrderSimpleRq.setCreateTime(DateUtil.parse(order.getCreateTime()));
            customer = (Customer) this.commonEntityService.findById(Customer.class, order.getSellerCustId());
            tempOrderSimpleRq.setName(customer.getName());
            tempOrderSimpleRq.setPhoneNo(customer.getMobi());
            tempOrderSimpleRqs.add(tempOrderSimpleRq);
        }
        return tempOrderSimpleRqs;
//        if(orders != null){
//            orders.forEach(order -> {
//                this.commonEntityService.delete(order);
//            });
//        }
    }

    public Order getTempOrder(String orderNo, Integer mktId) {
        Order order = this.orderJPA.findByOrderNo(orderNo);
        this.commonEntityService.delete(Order.class, order.getId());
        return order;
    }

    public void batchRepay(BatchRepayRq batchRepayRq) throws Exception {
        MemberAccTuple<Member, Account> memberAccTuple = this.memberService.findByMemNo(null, batchRepayRq.getMemberId());
        Member member = memberAccTuple.first;
        if (member.getErrorCount() == null) {
            member.setErrorCount(0);
        }
        if (member.getErrorCount() >= 10) {
            throw new Exception("支付密码错误次数超限！请到柜台解锁！");
        } else {
            if (!encoder.matches(batchRepayRq.getPayPassword(), member.getPayPassword())) {
                member.setErrorCount(member.getErrorCount() + 1);
                this.commonEntityService.update(member);
                if (member.getErrorCount() < 10) {
                    throw new Exception("支付密码不匹配！还有" + (10 - member.getErrorCount()) + "次机会！");
                } else if (member.getErrorCount() == 10) {
                    throw new Exception("支付密码已锁定！请到柜台解锁！");
                }
            }
        }
        AccountDebt accountDebt = null;
        MemberAccTuple<Member,Account> toMemberAccTuple = null;
        for (SimpleRepay simpleRepay : batchRepayRq.getSimpleRepays()) {
            accountDebt = this.accountDebtJPA.findById(simpleRepay.getDeptId()).get();
            toMemberAccTuple = this.memberService.findByAccountDept(accountDebt);
            if (accountDebt.getDebtAmt().subtract(accountDebt.getRepayAmt()).compareTo(simpleRepay.getRepayAmt()) < 0) {
                throw new Exception("还款金额大于所欠金额！");
            } else {
                this.accountRepayJPA.save(this.createAccountRepay(accountDebt, simpleRepay.getRepayAmt(), false));
                accountDebt.setRepayAmt(accountDebt.getRepayAmt().add(simpleRepay.getRepayAmt()));
                this.commonEntityService.update(accountDebt);
                this.createAccRecvPayAndSave(memberAccTuple.second, member,toMemberAccTuple.second,-1, accountDebt.getOrderNo()
                        ,simpleRepay.getRepayAmt(),OrderType.TRANS, SubjectCodeEnum.SERVICE_REPAY.getId(),SubjectCodeEnum.SERVICE_REPAY.getName());
                this.createAccRecvPayAndSave(toMemberAccTuple.second, toMemberAccTuple.first,memberAccTuple.second,1, accountDebt.getOrderNo()
                        ,simpleRepay.getRepayAmt(),OrderType.TRANS, SubjectCodeEnum.SERVICE_REPAY.getId(),SubjectCodeEnum.SERVICE_REPAY.getName());
            }
        }


    }

    public String createOrderPrintStr(Order order){
//        List<OrderDetail> orderDetails = order.getOrderDetails().stream().map(orderDetail -> {
//            if(orderDetail.getPriceWay() == PriceWayEnum.WEIGHT){
//                orderDetail.setAmount(orderDetail.getPrice().multiply(orderDetail.getWeight()).setScale(2));
//            }else if(orderDetail.getPriceWay() == PriceWayEnum.PIECE){
//                orderDetail.setAmount(orderDetail.getPrice().multiply(orderDetail.getQty()).setScale(2));
//            }
//            return orderDetail;
//        }).collect(Collectors.toList());
        String[] masterFields = {"订单号", "买方姓名", "买方编号", "买方手续费", "卖方姓名", "卖方编号", "卖方手续费",
                "货款金额", "货物总重", "支付金额", "支付时间", "支付方式"};
        String[] masterDataIndex = {"orderNo", "buyerInfo", "buyerMemNo", "buyerFee", "sellerMemName", "sellerMemNo", "sellerFee", "apAmt", "totalWeight", "payAmt", "createTime", "payType"};
        String[] detailFields = {"重量单位", "品类名称", "价格", "重量", "数量", "计价方式", "总额", "皮重", "毛重", "净重"};
        String[] dataIndex = {"priceUnit", "prodCatName", "price", "weight", "qty", "priceWay", "amount", "tareWgt", "grossWgt", "pcsWgt"};
        List<JSONObject> detailData = CreatePrintJsonUtils.createDetailData(JSON.toJSONString(order.getOrderDetails()), masterFields.length, detailFields, dataIndex);
        List<JSONObject> convertedDetailData = detailData.stream().map(data -> {
            if (PriceWayEnum.WEIGHT.equals(data.get("Feild17"))) {
                data.put("Feild17", "计重");
            } else if (PriceWayEnum.PIECE.equals(data.get("Feild17"))) {
                data.put("Feild17", "计件");
            }
            return data;
        }).collect(Collectors.toList());
        JSONObject masterData = CreatePrintJsonUtils.createMasterData(JSON.toJSONString(order), masterDataIndex, masterFields);
        masterData.put("Feild11", convertChinese(masterData.getString("Feild11")));
        List<JSONObject> masterDatas = new ArrayList<>();
        masterDatas.add(masterData);
        return CreatePrintJsonUtils.createPrintStr(masterFields, detailFields, masterDatas, convertedDetailData);
    }

    public String convertChinese(String payType) {
        if (PayType.FS_IC.equals(payType)) {
            return "IC卡";
        } else if (PayType.WX_C2B.equals(payType) || PayType.WX_B2C.equals(payType)) {
            return "微信";
        } else if (PayType.ALI_C2B.equals(payType) || PayType.ALI_B2C.equals(payType)) {
            return "支付宝";
        } else if (PayType.POS_PAY.equals(payType)) {
            return "POS";
        } else if (PayType.FS_C2B.equals(payType) || PayType.FS_B2C.equals(payType)) {
            return "钱包支付";
        } else if (PayType.FS_CREDIT.equals(payType)) {
            return "赊销";
        } else if (PayType.CASH.equals(payType)) {
            return "现金";
        } else if (PayType.SLIP.equals(payType)) {
            return "凭条";
        }
        return "";
    }

    public void onlineOrderPay(HttpServletRequest request, String orderNo, Integer buyerMemId) throws Exception {
        Order order = this.orderJPA.findByOrderNo(orderNo);
        Member sellerMember = this.memberJPA.findById(order.getSellerMemId()).get();
        Member buyerMember = this.memberJPA.findById(buyerMemId).get();
        Customer buyerCustomer = this.customerJPA.findById(buyerMember.getCustomerId()).get();
        String content = "编号为" + sellerMember.getNo() + "的卖家" + sellerMember.getName()
                + "，对您发起了线上交易，订单号为" + orderNo + ",金额：" + order.getPayAmt() + ",请确认";
        if(!msgService.checkDisabledMsgTypes(buyerMember.getCustomerId(),MsgType.ONLINE_ORDERPAY)) {
            AppMsgNotify appMsgNotify = this.createAppMsg(request, buyerMember, new ObjectMapper().writeValueAsString(order), content, "线上交易", MsgType.ONLINE_ORDERPAY);
            AppMsgNotify appMsgNotifyDB = this.appMsgNotifyJPA.save(appMsgNotify);
            Map<String, String> extral = new HashMap<>();
            extral.put("appMsgNotifyId", String.valueOf(appMsgNotifyDB.getId()));
            this.jPushServiceImpl.sendRegistrationIdNotify(content, buyerCustomer.getRegistrationId(), extral);
        }
    }

    public void batchOfflineRepayApply(HttpServletRequest request, BatchRepayRq batchRepayRq) throws Exception {
        Member currentMember = this.memberJPA.findById(batchRepayRq.getMemberId()).get();
        AccountDebt accountDebt = null;
        AccountRepay accountRepay = null;
        StringBuffer content = new StringBuffer("编号为" + currentMember.getNo() + "的会员" + currentMember.getName() + "正在申请线下还款，金额为");
        Map<String, String> extral = null;
        AppMsgNotify appMsgNotify = null;
        StringBuffer secondBuffer = null;
        Customer sendMsgCustomer = null;
        for (SimpleRepay simpleRepay : batchRepayRq.getSimpleRepays()) {
            secondBuffer = new StringBuffer(content);
            extral = new HashMap<>();
            accountDebt = this.accountDebtJPA.findById(simpleRepay.deptId).get();
            sendMsgCustomer = this.getMemberOfCustomer(accountDebt.getOrderNo(), 1);
            accountRepay = this.accountRepayJPA.save(this.createAccountRepay(accountDebt, simpleRepay.getRepayAmt(), true));
            secondBuffer.append(simpleRepay.getRepayAmt());
            secondBuffer.append("，请确认查收!");
            if(!msgService.checkDisabledMsgTypes(sendMsgCustomer,MsgType.REPAY_CONFIRM)) {
                appMsgNotify = this.appMsgNotifyJPA.save(this.createAppMsg(request, sendMsgCustomer.getMember(), new ObjectMapper().writeValueAsString(accountRepay), secondBuffer.toString(), "还款申请", MsgType.REPAY_CONFIRM));
                extral.put("appMsgNotifyId", String.valueOf(appMsgNotify.getId()));
                this.jPushServiceImpl.sendRegistrationIdNotify(content.toString(), sendMsgCustomer.getRegistrationId(), extral);
            }
        }
    }

    public AppMsgNotify createAppMsg(HttpServletRequest request, Member member, String addition, String content, String title, MsgType msgType) {
        AppMsgNotify appMsgNotify = new AppMsgNotify();
        appMsgNotify.setCreateTime(new Date());
        appMsgNotify.setMemberId(member.getId());
        appMsgNotify.setCustId(this.getMemberOfCustomer(member).getId());
        appMsgNotify.setAddition(addition);
        appMsgNotify.setContent(content);
        appMsgNotify.setIsRead(false);
        appMsgNotify.setTitle(title);
        appMsgNotify.setMsgType(msgType);
        if (request != null) {
            requestUtil.setCreatorAndCreatorId(appMsgNotify, requestUtil.getLoginUser(request));
        }
        return appMsgNotify;
    }

    public Paging getOrderList(QueryParameter queryParameter){
//        List<QueryCondition> queryConditions = queryParameter.getQueryConditions().stream().map(
////                queryCondition->{
////                    if(queryCondition.getField().equals("orderStatus")){
////                        queryCondition.setValue(OrderStatus.valueOf(String.valueOf(queryCondition.getValue())).getKey());
////                    }
////                    return queryCondition;
////                }).collect(Collectors.toList());
//        queryParameter.setQueryConditions(queryConditions);
        return this.commonEntityService.findPagedEntity(queryParameter,Order.class);
    }

    public Order setReceiptMoney(BigDecimal accmoney, Integer memberId )
    {
        Member member = this.memberJPA.findById(memberId).get();
        Order order = new Order();
        String orderNo = "M0001" + String.format("%05d", this.orderNoService.getOrderNo("orderNoCreateKey"));
        order.setOrderNo(orderNo);
        order.setCreateTime(new Date());
        order.setStatus(OrderStatus.SUBMIT);
        order.setApAmt(accmoney);
        order.setPayType(PayType.FS_C2B);
        order.setCreateWay(CreateWay.APP);
        order.setSellerMemId(memberId);
        order.setPayAmt(accmoney);
        order.setSellerMemName(member.getName());
        order.setSellerMemNo(member.getNo());
        order.setSellerCustId(member.getCustomerId());
        order.setMktId(member.getMktId());
        this.orderJPA.saveAndFlush(order);
        return order;
    }


    public Order payMent(Integer memberId, String orderNo) throws Exception {
        Order order = this.orderJPA.findByOrderNo(orderNo);
        Integer tomemberId = order.getSellerMemId();
        MemberAccTuple<Member, Account> memberAccTuple = this.memberService.findByMemNo(null, memberId);
        MemberAccTuple<Member, Account> tomemberAccTuple = this.memberService.findByMemNo(null, tomemberId);
        Account account = memberAccTuple.second;
        Account toaccount = tomemberAccTuple.second;
        BigDecimal apAmt = order.getApAmt();
        TransferResult result = new TransferResult();
        if (order != null) {
            if (account.getStatus().equals(AccountStatus.ENABLE) &&
                    toaccount.getStatus().equals(AccountStatus.ENABLE) &&
                    account.getAvailAmt().compareTo(apAmt) > 0 && account.getAccountType().equals(toaccount.getAccountType())) {
                AccRecvPay accRecvPay = this.orderService.createAccRecvPayAndSave(account, memberAccTuple.first, toaccount, -1, orderNo, apAmt, null, SubjectCodeEnum.SERVICE_TRANFER.getId(), SubjectCodeEnum.SERVICE_TRANFER.getName());
                AccRecvPay toaccRecvPay = this.orderService.createAccRecvPayAndSave(toaccount, tomemberAccTuple.first, account, 1, orderNo, apAmt, null, SubjectCodeEnum.SERVICE_TRANFER.getId(), SubjectCodeEnum.SERVICE_TRANFER.getName());
                order.setBuyerMemId(memberId);
                order.setBuyerCustId(memberAccTuple.first.getCustomerId());
                order.setBuyerMemNo(memberAccTuple.first.getNo());
                order.setActTime(new Date());
                this.orderJPA.save(order);
            } else {
                throw new Exception("账户不一致或余额不足！");
            }
        }
        return order;
    }

    public List<ProdCatalog> getProductList(Integer memberId,Integer mktId,Integer txnId){
        //TODO:后期优化，考虑列表存入redis缓存
        List<ProdCatalog> prodCatalogs = this.prodCatalogJPA.findByMktIdAndTxnId(mktId,txnId);
        prodCatalogs = prodCatalogs.stream().peek(prodCatalog -> prodCatalog.setPingYinName(ChangeToPinYin.getPinYin(prodCatalog.getCatName())))
                .peek(prodCatalog -> prodCatalog.setNameFirst(prodCatalog.getPingYinName().substring(0,1).toUpperCase()))
                .sorted(Comparator.comparing(ProdCatalog::getPingYinName)).collect(Collectors.toList());
        //List<Product> products = null;
        prodCatalogs.stream().forEach(prodCatalog -> {
            if(prodCatalog.getProducts() != null){
                prodCatalog.setProducts(prodCatalog.getProducts().stream().map(product -> {
                    if(product.getMemberId()== memberId && product.getMktId()==mktId){
                        product.setProdCatId(prodCatalog.getId());
                        product.setProdCatName(prodCatalog.getCatName());
                        return product;
                    }
                    return null;
                }).filter(product -> product != null).collect(Collectors.toList()));
            }
        });
        return prodCatalogs;
    }

    
//	 public List<ProcatalogInfo> getProductList(Integer memberId, Integer mktId) {
//        String hql = "SELECT pc.id,pc.catCode,pc.catName,pc.isShow,pc.linkId,pc.mktId," +
//                "pc.parentId,pc.txnId,p.id,p.mktId,p.ProdCatId,p.createTime,p.custId," +
//                "p.memberId,p.name,p.pcsWgt,p.price,p.priceUnit,p.priceWay,p.quantity,p.status " +
//                "FROM ProdCatalog AS pc LEFT JOIN Product AS p ON p.ProdCatId = pc.id " +
//                "WHERE pc.id in (select a.ProdCatId from Product as a where a.memberId = ? AND a.mktId = ?)";
//        session = entityManager.unwrap(org.hibernate.Session.class);
//        Query query = session.createQuery(hql);
//        query.setInteger(0, memberId);
//        query.setInteger(1, mktId);
//        List list = query.list();
//
//        List<ProcatalogInfo> procatalogInfoList = new ArrayList<>();
//        if(list==null || list.size()==0)
//        {
//            return null;
//        }
//        Map<String, Object[]> map = new HashMap<String, Object[]>();
//        String names[] = new String[list.size()];
//        for (int i = 0; i <list.size() ; i++) {
//            Object[] object = (Object[]) list.get(i);
//            String name = object[2].toString();
//            names[i] = name;
//            map.put(name, (Object[])list.get(i));
//        }
//        names = sort(names);
//        list.clear();
//        for(String name : names){
//            if(map.containsKey(name))
//                list.add(map.get(name));
//        }
//        for (int i = 0; i <list.size() ; i++) {
//            ProcatalogInfo procatalogInfo = new ProcatalogInfo();
//            Product product = new Product();
//            Object[] object = (Object[]) list.get(i);
//            procatalogInfo.setId((Integer)object[0]);
//            procatalogInfo.setCatCode(object[1].toString());
//            procatalogInfo.setCatName(object[2].toString());
//            procatalogInfo.setIsShow((Boolean) object[3]);
//            procatalogInfo.setLinkId((Integer)object[4]);
//            procatalogInfo.setMktId((Integer) object[5]);
//            procatalogInfo.setParentId((Integer)object[6]);
//            procatalogInfo.setTxnId((Integer)object[7]);
//            product.setId((Integer)object[8]);
//            product.setMktId((Integer)object[9]);
//            product.setCreateTime((Date) object[11]);
//            product.setCustId((Integer)object[12]);
//            product.setMemberId((Integer)object[13]);
//            product.setName(object[14].toString());
//            product.setPcsWgt((BigDecimal) object[15]);
//            product.setPrice((BigDecimal)object[16]);
//            product.setPriceUnit((PriceUnit)object[17]);
//            product.setPriceWay((PriceWayEnum) object[18]);
//            product.setQuantity((Integer)object[19]);
//            product.setStatus((ProductStatus) object[20]);
//            procatalogInfo.products = product;
//            procatalogInfoList.add(procatalogInfo);
//        }
//        return procatalogInfoList;
//    }

//    public static String[] sort(String [] data){
//        if(data==null || data.length==0){
//            return null;
//        }
//        Comparator<Object> comparator = Collator.getInstance(java.util.Locale.CHINA);
//        Arrays.sort(data, comparator);
//        return data;
//    }

//    public List<ProcatalogInfo> test(Integer memberId, Integer mktId)
//    {   List<ProcatalogInfo> procatalogInfos = new ArrayList<>();
//        ProcatalogInfo procatalogInfo = new ProcatalogInfo();
//        List<Product> product = this.productJPA.findByMemberIdAndMktId(memberId,mktId);
//        for (Product items:product) {
//            Integer procatId = items.getProdCatId();
//            ProdCatalog prodCatalog = this.prodCatalogJPA.findById(procatId).get();
//            //String name = prodCatalog.getCatName();
//            procatalogInfo.products = items;
//            procatalogInfo.setId(prodCatalog.getId());
//            procatalogInfo.setCatCode(prodCatalog.getCatCode());
//            procatalogInfo.setCatName(prodCatalog.getCatName());
//            procatalogInfo.setIsShow(prodCatalog.getIsShow());
//            procatalogInfo.setLinkId(prodCatalog.getLinkId());
//            procatalogInfo.setMktId(prodCatalog.getMktId());
//            procatalogInfo.setParentId(prodCatalog.getParentId());
//            procatalogInfo.setTxnId(prodCatalog.getTxnId());
//            procatalogInfo.setTxn(prodCatalog.getTxn());
//            procatalogInfos.add(procatalogInfo);
//        }
//        return procatalogInfos;
//    }
}