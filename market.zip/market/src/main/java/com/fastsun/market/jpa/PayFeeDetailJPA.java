package com.fastsun.market.jpa;

import com.fastsun.framework.jpa.base.BaseRepository;
import com.fastsun.market.entity.synthesizeFee.PayFeeDetail;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
public interface PayFeeDetailJPA extends BaseRepository<PayFeeDetail, Integer>, JpaSpecificationExecutor<PayFeeDetail> {
    List<PayFeeDetail> findByIdIn(List<Integer> ids);

}
