package com.fastsun.market.entity.account;

import com.fastsun.market.entity.enums.AccountStatus;
import com.fastsun.market.entity.enums.AccountType;
import com.fastsun.market.entity.enums.CommonStatusEnum;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Table(name = "b_account", uniqueConstraints = { @UniqueConstraint(columnNames = { "no" }) })
@Entity
public class Account implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ApiModelProperty("账户号")
    private String no;

    @ApiModelProperty("账户名")
    private String name;

    @ApiModelProperty("账户余额(可用金额+未结算金额)")
    private BigDecimal balAmt;

    @ApiModelProperty("可用金额")
    private BigDecimal availAmt;

    @ApiModelProperty("冻结金额")
    private BigDecimal frozenAmt;

    @Enumerated(EnumType.ORDINAL)
    @ApiModelProperty("账户类型")
    private AccountType accountType;

    @Enumerated(EnumType.ORDINAL)
    @ApiModelProperty("账户状态")
    private AccountStatus status;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("所属市场Id")
    private Integer mktId;

    @ApiModelProperty("创建时间")
    private Date createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getFrozenAmt() {
        return frozenAmt;
    }

    public void setFrozenAmt(BigDecimal frozenAmt) {
        this.frozenAmt = frozenAmt;
    }

    public Enum<AccountType> getAccountType() {
        return accountType;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    public AccountStatus getStatus() {
        return status;
    }

    public void setStatus(AccountStatus status) {
        this.status = status;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public BigDecimal getAvailAmt() {
        return availAmt;
    }

    public void setAvailAmt(BigDecimal availAmt) {
        this.availAmt = availAmt;
    }

    public BigDecimal getBalAmt() {
        return balAmt;
    }

    public void setBalAmt(BigDecimal balAmt) {
        this.balAmt = balAmt;
    }

    public Account() {
    }
}
