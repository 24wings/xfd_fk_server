package com.fastsun.market.entity.enums;

public enum MemberType {
    PERSONAL,//个人
    COMPANY//企业
}
