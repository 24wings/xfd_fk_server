package com.fastsun.market.controller.web;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.member.RechargeWithDraw;
import com.fastsun.market.service.impl.RechargeWithDrawServiceImpl;
import com.fastsun.market.utils.StatusMsgEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Api;
import javax.servlet.http.HttpServletRequest;

@Api(description = "商品类目", tags = { "market.web.RechargeWithDraw" })
@RestController
@RequestMapping("/api/reWithDr")
public class RechargeWithDrawController extends BaseController {
        private ResponseBean responseBean;
        @Autowired
        private RechargeWithDrawServiceImpl rechargeWithDrawServiceImpl;

        @ApiOperation(value = "充值", notes = "", httpMethod = "POST")
        @RequestMapping(value = "/recharge", method = RequestMethod.POST)
        public ResponseBean recharge(HttpServletRequest request, @RequestBody RechargeWithDraw rechargeWithDraw)
                        throws Exception {
                RechargeWithDraw rechargeWithDrawDB = this.rechargeWithDrawServiceImpl.saveRechargeInfo(request,
                                rechargeWithDraw);
                String printStr = this.rechargeWithDrawServiceImpl.createRechargePrintStr(rechargeWithDrawDB);
                responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                                StatusMsgEnum.ADD_SUCCESS.getMsg());
                responseBean.getData().put("recharge", rechargeWithDrawDB);
                responseBean.getData().put("printStr",printStr);
                return responseBean;
        }

        @ApiOperation(value = "提现", notes = "", httpMethod = "POST")
        @PostMapping(value = "/withDraw")
        public ResponseBean withDraw(HttpServletRequest request, @RequestBody RechargeWithDraw rechargeWithDraw)
                        throws Exception {
                RechargeWithDraw rechargeWithDrawDB = this.rechargeWithDrawServiceImpl.saveWithDraw(request,
                                rechargeWithDraw);
                responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                                StatusMsgEnum.ADD_SUCCESS.getMsg());
                responseBean.getData().put("recharge", rechargeWithDrawDB);
                return responseBean;
        }
        @ApiOperation(value = "",notes = "充值提现明细",httpMethod = "GET")
        @GetMapping("/detail")
        public ResponseBean rechargeWithDrawDetail(@RequestParam Integer id){
             RechargeWithDraw rechargeWithDraw = this.rechargeWithDrawServiceImpl.getDetail(id);
             responseBean = ResponseUtil.createRespBean(true,200,StatusMsgEnum.QUERY_SUCCESS.getMsg());
             responseBean.getData().put("rechargeWithDraw",rechargeWithDraw);
             return responseBean;
        }
}
