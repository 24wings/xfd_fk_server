package com.fastsun.market.service.impl;

import cn.jpush.api.push.PushResult;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.utils.ResponseUtil;

//import cn.jmessage.api.JMessageClient;
import cn.jpush.api.*;
import cn.jpush.api.push.model.PushPayload;

//import java.util.List;

public class JpushIMServiceImpl {

    public ResponseBean sendMsg() throws Exception {
        ResponseBean res = null;
        JPushClient client = new JPushClient("4224dcca3494ab5279be4705", "35f14808673591baceed2d61");
        // JMessageClient msgclient = new JMessageClient("35f14808673591baceed2d61",
        // "4224dcca3494ab5279be4705");
        // PushPayload hehe = PushPayload.alertAll("hehe");
        PushPayload payload = buildPushObject_all_all_alert();
        PushResult result = client.sendPush(payload);
        res = ResponseUtil.createRespBean(true, 200, result.toString());
        return res;

    }

    public static PushPayload buildPushObject_all_all_alert() {
        return PushPayload.alertAll("alert");
    }
}