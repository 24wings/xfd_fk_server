package com.fastsun.market.bean;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;
@Setter
@Getter
@NoArgsConstructor
public class BatchRepayRq {
    @NotNull(message = "还款会员不能为Null!")
    private Integer memberId;
    private String payPassword;
    private BigDecimal amount;
    @Size(min = 1, message = "还款条数小于1！")
    private List<SimpleRepay> simpleRepays;

}
