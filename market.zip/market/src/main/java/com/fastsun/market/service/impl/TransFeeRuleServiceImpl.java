package com.fastsun.market.service.impl;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.framework.bean.Paging;
import com.fastsun.market.entity.common.TransFeeRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@Service
public class TransFeeRuleServiceImpl {
    @Autowired
    CommonEntityService transFeeRuleCommonEntityService;
    @Autowired
    RequestUtil requestUtil;

    public void saveTransFeeRule(HttpServletRequest request,TransFeeRule transFeeRule){
          transFeeRule.setEnabled(true);
          transFeeRule.setCreateTime(new Date());
          requestUtil.setCreatorAndCreatorId(transFeeRule,requestUtil.getLoginUser(request));
          this.transFeeRuleCommonEntityService.save(transFeeRule);
    }

    public Paging<TransFeeRule> queryTransFeeRule(QueryParameter queryParameter){
        return this.transFeeRuleCommonEntityService.findPagedEntity(queryParameter,TransFeeRule.class);
    }
}
