package com.fastsun.market.entity.enums;

public enum  BusinessType {
    RECHARGE,
    WITHDRAW,
    TRNASORDER,

}
