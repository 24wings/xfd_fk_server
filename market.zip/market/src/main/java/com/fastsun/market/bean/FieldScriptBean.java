package com.fastsun.market.bean;

import lombok.Data;

/**
 * Created by ww on 2018-07-03 10:56
 * mataField表中的 字段对应的脚本
 */
@Data
public class FieldScriptBean {
    /**
     * input / dropdownlist /calendar/calendar-sd(日期起止组件)
     **/
    String ctrl_type;
    /**
     * 预设值 如果为 [] 如[男,女]则忽略脚本值，如果是另外一个表的值，这里则为 另一个查询名称如 dict,
     **/
    String prevalue;
    /**
     * 字典表的其他内容 生成结果为 select key,value from d_dict where type=1 其中  type=1 为  privalue_where内容
     **/
    String prevalue_where;
    /**
     * 此字段对应的 内置JAVA方法 如 getGuid(), getCurrentUserId()
     **/
    String innerconf;
    /**
     * 此字段是否由其他 字段生成如   sex/10 * 100+"%"
     **/
    String exp;

    /**
     * 比较符 默认 like
     **/
    String opter;

    /**
     * 是否必填  0---不，1--必
     **/
    int isRequired;

    /**
     * 此字段的显示规则  ": "background-color': this.user.age>18? '#red' : '#green'" ---------- 需前台协助设定此列显示规则
     **/
    String style;

    /**
     * ”:"$_"或" _%"  下划线在前，表示是前缀，在后表示后缀  或是 0.00 之类
     **/
    String displayFormat;
}
