package com.fastsun.market.entity.enums;

public enum RepayStatus {
    UNRECEIVED(0,"还款未收到"),RECEIVED(1,"还款已收到"),WAITRECEIVED(2,"待确认");
    String value;
    Integer key;
    RepayStatus(Integer key,String value){
        this.key = key;
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }
}
