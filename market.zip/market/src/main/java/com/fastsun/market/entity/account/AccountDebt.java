package com.fastsun.market.entity.account;

import com.fastsun.market.entity.enums.OrderType;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Table(name = "b_acc_debt")
@Entity
public class AccountDebt {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String debtNo; // 欠款流水号
    private Integer debteeAccId; // 债权人账户Id
    private String debteeAccName; // 债权账户Id
    private Integer debtorAccId; // 债务账户Id
    private String debtorAccName; // 债务账户名称
    private Integer subjectId; // 收支科目Id
    private String subjectName;// 收支科目名称
    private BigDecimal debtAmt; // 欠款金额
    private BigDecimal repayAmt; // 已还金额
    @Transient
    private BigDecimal tbConfireAmt;//待确认还款总额
    private OrderType orderType; // 订单类型
    private String orderNo; // 订单编号
    private String remark; // 备注
    private Date createTime; // 创建时间
    private Integer repaymentDays; // 账期
    private Integer mktId;// 所属市场id

    public AccountDebt() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDebtNo() {
        return debtNo;
    }

    public void setDebtNo(String debtNo) {
        this.debtNo = debtNo;
    }

    public Integer getDebteeAccId() {
        return debteeAccId;
    }

    public void setDebteeAccId(Integer debteeAccId) {
        this.debteeAccId = debteeAccId;
    }

    public String getDebteeAccName() {
        return debteeAccName;
    }

    public void setDebteeAccName(String debteeAccName) {
        this.debteeAccName = debteeAccName;
    }

    public Integer getDebtorAccId() {
        return debtorAccId;
    }

    public void setDebtorAccId(Integer debtorAccId) {
        this.debtorAccId = debtorAccId;
    }

    public String getDebtorAccName() {
        return debtorAccName;
    }

    public void setDebtorAccName(String debtorAccName) {
        this.debtorAccName = debtorAccName;
    }

    public BigDecimal getDebtAmt() {
        return debtAmt;
    }

    public void setDebtAmt(BigDecimal debtAmt) {
        this.debtAmt = debtAmt;
    }

    public BigDecimal getRepayAmt() {
        return repayAmt;
    }

    public void setRepayAmt(BigDecimal repayAmt) {
        this.repayAmt = repayAmt;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public void setOrderType(OrderType orderType) {
        this.orderType = orderType;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getRepaymentDays() {
        return repaymentDays;
    }

    public void setRepaymentDays(Integer repaymentDays) {
        this.repaymentDays = repaymentDays;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public BigDecimal getTbConfireAmt() {
        return tbConfireAmt;
    }

    public void setTbConfireAmt(BigDecimal tbConfireAmt) {
        this.tbConfireAmt = tbConfireAmt;
    }
}
