package com.fastsun.market.entity.enums;

public enum PayType {
    WX_C2B,ALI_C2B,WX_B2C,ALI_B2C,POS_PAY,FS_C2B,FS_B2C,FS_IC,FS_CREDIT,CASH,SLIP
}
