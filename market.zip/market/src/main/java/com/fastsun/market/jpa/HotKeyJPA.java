package com.fastsun.market.jpa;

import com.fastsun.framework.jpa.base.BaseRepository;
import com.fastsun.market.entity.common.HotKey;

import java.util.List;

public interface HotKeyJPA extends BaseRepository<HotKey,Integer> {

    List<HotKey> findAllByMktIdAndTxnIdAndMemberId(Integer mktId,Integer txnId,Integer memberId);
}
