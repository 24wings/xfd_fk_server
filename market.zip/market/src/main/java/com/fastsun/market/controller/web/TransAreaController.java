package com.fastsun.market.controller.web;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.common.TransArea;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

@Api(description = "交易区管理", tags = { "market.web.TransArea" })

@RestController
@RequestMapping("/api/txnArea")
public class TransAreaController extends BaseController {

    @Autowired
    private CommonEntityService transAreaCommonEntityService;

    private ResponseBean responseBean = null;

    @ApiOperation(value = "交易区新增", notes = "", httpMethod = "POST")
    @PostMapping(value = "/create")
    public ResponseBean save(@RequestBody TransArea txnArea) {
        boolean flag = this.transAreaCommonEntityService.save(txnArea);
        if (flag) {
            responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                    StatusMsgEnum.ADD_SUCCESS.getMsg());
        } else {
            responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_FAILED.getStatus(),
                    StatusMsgEnum.ADD_FAILED.getMsg());
        }
        return responseBean;
    }

    @ApiOperation(value = "交易区删除", notes = "", httpMethod = "GET")
    @GetMapping(value = "/delete")
    public ResponseBean delete(@RequestParam Integer txnId) {
        this.transAreaCommonEntityService.delete(TransArea.class, txnId);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.DELETE_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return responseBean;
    }

    @ApiOperation(value = "交易区信息修改", notes = "", httpMethod = "POST")
    @PostMapping(value = "/update")
    public ResponseBean update(@RequestBody TransArea transArea) {
        TransArea trans = (TransArea) this.transAreaCommonEntityService.update(transArea);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        responseBean.getData().put("transArea", trans);
        return responseBean;
    }

    @ApiOperation(value = "查询交易区列表", notes = "查询市场所有交易区", httpMethod = "GET")
    @PostMapping(value = "/list")
    public ResponseBean findAllByMktId(@RequestBody QueryParameter queryParameter) {
        Paging<TransArea> paging = this.transAreaCommonEntityService.findPagedEntity(queryParameter, TransArea.class);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("paging", paging);
        return responseBean;
    }

    @ApiOperation(value = "查询单个交易区", notes = "查询详细信息", httpMethod = "GET")
    @GetMapping(value = "/detail")
    public ResponseBean findOneTransArea(@RequestParam Integer txnId) {
        TransArea txnArea = (TransArea) this.transAreaCommonEntityService.findById(TransArea.class, txnId);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("txnArea", txnArea);
        return responseBean;
    }
}
