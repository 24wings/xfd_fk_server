package com.fastsun.market.jpa;

import com.fastsun.framework.jpa.base.BaseRepository;
import com.fastsun.market.entity.account.AccountRepay;
import com.fastsun.market.entity.enums.RepayStatus;

import java.util.List;

public interface AccountRepayJPA extends BaseRepository<AccountRepay,Integer> {
    List<AccountRepay> findByDeptIdIn(List<Integer> debtIds);
    List<AccountRepay> findByDeptIdAndRepayStatus(Integer deptId, RepayStatus repayStatus);
}
