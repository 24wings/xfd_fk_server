package com.fastsun.market.service.impl;

import com.fastsun.framework.bean.MemberAccTuple;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.entity.enums.CommonStatusEnum;
import com.fastsun.market.entity.member.CustCard;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.entity.enums.CreateWay;
import com.fastsun.market.jpa.CustCardJPA;
import com.fastsun.market.jpa.CustomerJPA;
import com.fastsun.market.jpa.MemberJPA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Random;

@Service
public class CustomerServiceImpl {

    @Autowired
    private PasswordEncoder encoder;
    @Autowired
    private MemberJPA memberJPA;
    @Autowired
    private CustCardJPA custCardJPA;
    @Autowired
    private CustomerJPA customerJPA;
    @Autowired
     RequestUtil requestUtil;
    @Autowired
    MemberServiceImpl memberServiceImpl;
    @Autowired
    private CommonEntityService commonEntityService;

    public Customer findByMobi(Integer mktId, String mobi) {
        return this.customerJPA.findByMktIdAndMobi(mktId, mobi);
    }

    public Customer saveCustomer(HttpServletRequest request ,Integer memberId, Customer customer) {
        if (memberId != null) {
            Member member = this.memberJPA.findById(memberId).get();
            requestUtil.setCreatorAndCreatorId(customer,requestUtil.getLoginUser(request));
            customer = createCustomer(customer, member);
        }else{
            customer.setCreateTime(new Date());
            customer.setPassword(encoder.encode(customer.getPassword()));
            customer.setPwdEncrypted(true);
            customer.setStatus(CommonStatusEnum.ENABLE);
        }
        return this.customerJPA.save(customer);
    }

    public Customer saveCustomer(Member member) {
        Customer customer = createCustomer(null, member);
        return this.customerJPA.save(customer);
    }

    public Customer createCustomer(Customer customer, Member member) {
        if (customer == null) {
            customer = new Customer();
            customer.setCreator(member.getCreator());
            customer.setCreatorId(member.getCreatorId());
            customer.setMemberId(member.getId());
            customer.setMobi(member.getMobi());
            customer.setName(member.getName());
            customer.setMktId(member.getMktId());
        }
        String password = generateCaptha(6);
        customer.setPassword(encoder.encode(password));
        customer.setPwdEncrypted(true);
        customer.setCreateTime(new Timestamp(System.currentTimeMillis()));
        customer.setCreateWay(CreateWay.WEB);
        customer.setStatus(CommonStatusEnum.ENABLE);
        return customer;
    }

    public String generateCaptha(int number) {
        String captha = "";
        int[] numbers = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        Random random = new Random();
        for (int i = 0; i < number; i++) {
            int index = random.nextInt(10000);
            captha += numbers[index % 10];
        }
        return captha;
    }

    public Customer relationCard(HttpServletRequest request,Customer customer) throws Exception {
        CustCard card = customer.getCard();
        long count = this.commonEntityService.getRecordCount(RequestUtil.getQueryParameter(card,"or","no"),card.getClass());
        if(count>0){
            throw new Exception("卡号已被绑定！");
        }
        requestUtil.setCreatorAndCreatorId(card,requestUtil.getLoginUser(request));
        Date date = new Date(System.currentTimeMillis());
        card.setCreateTime(date);
        card.setStatus(CommonStatusEnum.ENABLE);
        card = this.custCardJPA.save(card);
        customer.setCardId(card.getId());
        return (Customer) this.commonEntityService.update(customer);
    }

    public Boolean relieveCard(String cardNo){
        Boolean flag = false;
        CustCard custCard = this.custCardJPA.findByNo(cardNo);
        Customer customer = this.customerJPA.findByCardId(custCard.getId());
        customer.setCardId(null);
        this.commonEntityService.update(customer);
        this.commonEntityService.delete(CustCard.class,custCard.getId());
        flag = true;
        return flag;
    }

    public CustCard changeStatus(Integer cardId, CommonStatusEnum status) {
        CustCard card = this.custCardJPA.findById(cardId).get();
        card.setStatus(status);
        return (CustCard) this.commonEntityService.update(card);
    }

    public MemberAccTuple<Member,Account> findByCardNo(String cardNo) throws Exception {
         return this.memberServiceImpl.findByCardNo(cardNo);
    }

    public Customer modifyPassword(String oldPassword, String newPassword, Integer customerId) throws Exception {
        Customer customer = (Customer) this.commonEntityService.findById(Customer.class,customerId);
        if (!this.encoder.matches(oldPassword, customer.getPassword())) {
            throw new Exception("密码不匹配！");
        }
        customer.setPassword(newPassword);
        customer.setPassword(encoder.encode(newPassword));
        return (Customer) this.commonEntityService.update(customer);
    }

    public Customer update(Customer customer){
        return (Customer) this.commonEntityService.update(customer);
    }
}
