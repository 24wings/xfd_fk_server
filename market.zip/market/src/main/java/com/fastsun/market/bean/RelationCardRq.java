package com.fastsun.market.bean;


import com.fastsun.market.entity.member.CustCard;
import com.fastsun.market.entity.member.Customer;

public class RelationCardRq {

    private Customer customer;
    private CustCard custCard;

    public RelationCardRq(){}

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public CustCard getCustCard() {
        return custCard;
    }

    public void setCustCard(CustCard custCard) {
        this.custCard = custCard;
    }
}
