package com.fastsun.market.entity.transOrder;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fastsun.market.entity.enums.PriceUnit;
import com.fastsun.market.entity.enums.PriceWayEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
@Entity
@Table(name = "b_order_detail")
public class OrderDetail implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @JsonBackReference
    @ManyToOne(fetch = FetchType.EAGER,cascade = CascadeType.PERSIST,optional = false)
    @JoinColumn(name = "orderId",updatable = false)
    private Order order;
    private  Integer productId;
    private  String productName;
    private String prodCatName;
    private Integer prodCatId;

    private BigDecimal qty;
    private BigDecimal pcsWgt;//件重
    private BigDecimal grossWgt;//毛重
    private BigDecimal tareWgt;//皮重
    private BigDecimal weight;
    private BigDecimal price;
    private BigDecimal amount;
    @Enumerated(EnumType.ORDINAL)
    private PriceUnit priceUnit;
    @Enumerated(EnumType.ORDINAL)
    private PriceWayEnum priceWay;
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getProdCatId() {
        return prodCatId;
    }

    public void setProdCatId(Integer prodCatId) {
        this.prodCatId = prodCatId;
    }

    public BigDecimal getQty() {
        return qty;
    }

    public void setQty(BigDecimal qty) {
        this.qty = qty;
    }

    public BigDecimal getPcsWgt() {
        return pcsWgt;
    }

    public void setPcsWgt(BigDecimal pcsWgt) {
        this.pcsWgt = pcsWgt;
    }

    public BigDecimal getGrossWgt() {
        return grossWgt;
    }

    public void setGrossWgt(BigDecimal grossWgt) {
        this.grossWgt = grossWgt;
    }

    public BigDecimal getTareWgt() {
        return tareWgt;
    }

    public void setTareWgt(BigDecimal tareWgt) {
        this.tareWgt = tareWgt;
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public PriceUnit getPriceUnit() {
        return priceUnit;
    }

    public void setPriceUnit(PriceUnit priceUnit) {
        this.priceUnit = priceUnit;
    }

    public String getProdCatName() {
        return prodCatName;
    }

    public void setProdCatName(String prodCatName) {
        this.prodCatName = prodCatName;
    }

    public PriceWayEnum getPriceWay() {
        return priceWay;
    }

    public void setPriceWay(PriceWayEnum priceWay) {
        this.priceWay = priceWay;
    }

    public OrderDetail() {
    }
}
