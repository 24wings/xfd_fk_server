package com.fastsun.market.entity.enums;

import io.swagger.annotations.ApiModel;

public enum AccountType {
    MARKET_MSG(0,"市场短信账户"), MARKET_FEE(1,"市场手续费账户"), MEMBER_CASH(2,"会员现金账户"), MEMBER_SCORE(3,"会员积分账户"),
    USER_CASH(4,"员工现金账户");
    private Integer key;
    private String value;
    AccountType(Integer key,String value) {
        this.key = key;
        this.value = value;
    }
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }
}
