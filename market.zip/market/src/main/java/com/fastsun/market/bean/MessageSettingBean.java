package com.fastsun.market.bean;

public class MessageSettingBean {
    public String newMsgSetting = "";

}