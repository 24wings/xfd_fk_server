package com.fastsun.market.jpa;

import com.fastsun.framework.jpa.base.BaseRepository;
import com.fastsun.market.entity.member.MemberInvite;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface MemberInviteJPA extends BaseRepository<MemberInvite, Integer>, JpaSpecificationExecutor<MemberInvite> {
    public List<MemberInvite> findByRecvCustId(Integer recvCustId);

    public List<MemberInvite> findBySendCustId(Integer sendCustId);

    public List<MemberInvite> findByMemberIdAndMktId(Integer memberId,Integer mktId);
}
