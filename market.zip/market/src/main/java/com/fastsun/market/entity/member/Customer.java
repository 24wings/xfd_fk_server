package com.fastsun.market.entity.member;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fastsun.market.entity.enums.CommonStatusEnum;
import com.fastsun.market.entity.enums.CreateWay;
import com.fastsun.market.entity.enums.CustomerStatus;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Table(name = "b_customer", uniqueConstraints = { @UniqueConstraint(columnNames = { "mobi" }) })
@Entity
public class Customer implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String mobi;// 手机号
    private String password;// 登陆密码
    private Boolean pwdEncrypted;// 密码是否已加密
    private String avatarUrl;// 头像URL
    private Integer cardId;

    private Integer memberId;// 所属会员id
    @OneToOne(fetch = FetchType.EAGER, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinColumn(name = "cardId", updatable = false, insertable = false, foreignKey = @ForeignKey(name = "cardId", value = ConstraintMode.NO_CONSTRAINT))
    private CustCard card;// 当前卡

    private String disabledMsgTypes;//
    @Enumerated(EnumType.ORDINAL)
    private CommonStatusEnum status;
    @Enumerated(EnumType.ORDINAL)
    private CreateWay createWay;// 创建途径

    private Integer mktId;// 所属市场id
    private Date createTime;// 创建时间
    private Integer creatorId;// 创建人Id
    private String creator;// 创建人
    private String teamComment;
    private String registrationId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "memberId", updatable = false, insertable = false, foreignKey = @ForeignKey(name = "memberId", value = ConstraintMode.NO_CONSTRAINT))
    @JsonIgnore
    private Member member;

    public Customer() {
    }

    /**
     * @return the registrationId
     */
    public String getRegistrationId() {
        return registrationId;
    }

    /**
     * @param registrationId the registrationId to set
     */
    public void setRegistrationId(String registrationId) {
        this.registrationId = registrationId;
    }

    /**
     * @return the pwdEncrypted
     */
    public Boolean getPwdEncrypted() {
        return pwdEncrypted;
    }

    /**
     * @param teamComment the teamComment to set
     */
    public void setTeamComment(String teamComment) {
        this.teamComment = teamComment;
    }

    /**
     * @return the teamComment
     */
    public String getTeamComment() {
        return teamComment;
    }

    @Transient
    private List<String> authorities;

    /**
     * @return the authorities
     */
    public List<String> getAuthorities() {
        return authorities;
    }

    /**
     * @param authorities the authorities to set
     */
    public void setAuthorities(List<String> authorities) {
        this.authorities = authorities;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getMobi() {
        return mobi;
    }

    public void setMobi(String mobi) {
        this.mobi = mobi;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public CommonStatusEnum getStatus() {
        return status;
    }

    public void setStatus(CommonStatusEnum status) {
        this.status = status;
    }

    public Enum<CreateWay> getCreateWay() {
        return createWay;
    }

    public void setCreateWay(CreateWay createWay) {
        this.createWay = createWay;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }
    public CustCard getCard() {
        return card;
    }
    public void setCard(CustCard card) {
        this.card = card;
    }

    public String getDisabledMsgTypes() {
        return disabledMsgTypes;
    }

    public void setDisabledMsgTypes(String disabledMsgTypes) {
        this.disabledMsgTypes = disabledMsgTypes;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Integer getCardId() {
        return cardId;
    }

    public void setCardId(Integer cardId) {
        this.cardId = cardId;
    }

    public Boolean isPwdEncrypted() {
        return pwdEncrypted;
    }

    public void setPwdEncrypted(Boolean pwdEncrypted) {
        this.pwdEncrypted = pwdEncrypted;
    }

}
