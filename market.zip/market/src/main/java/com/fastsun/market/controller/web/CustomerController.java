package com.fastsun.market.controller.web;

import com.fastsun.framework.bean.MemberAccTuple;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.entity.enums.CommonStatusEnum;
import com.fastsun.market.entity.member.CustCard;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.service.impl.CustomerServiceImpl;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;

import javax.servlet.http.HttpServletRequest;

@Api(description = "用户", tags = { "market.web.Customer" })
@RestController
@RequestMapping("/api/customer")
public class CustomerController extends BaseController {

    private ResponseBean responseBean = null;

    @Autowired
    private CustomerServiceImpl customerServiceImpl;
    @Autowired
    private CommonEntityService customerCommonEntityService;

    @GetMapping(value = "/findByMobi")
    public ResponseBean findByMobi(@RequestParam Integer mktId, @RequestParam String mobi) {
        Customer customer = this.customerServiceImpl.findByMobi(mktId, mobi);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("customer", customer);
        return responseBean;
    }

    @PostMapping(value = "/create")
    public ResponseBean createCustomer(HttpServletRequest request, @RequestBody Customer customer) {
        Customer customerDB = this.customerServiceImpl.saveCustomer(request, customer.getMemberId(), customer);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        responseBean.getData().put("customer", customerDB);
        return responseBean;
    }

    @PostMapping(value = "/relationCard")
    public ResponseBean relationCard(HttpServletRequest request, @RequestBody Customer customer) {
        Customer customerDB = null;
        try {
            customerDB = this.customerServiceImpl.relationCard(request, customer);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(false, 201, e.getMessage());
            e.printStackTrace();
            return responseBean;
        }
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(), "关联成功！");
        responseBean.getData().put("customerDB", customerDB);
        return responseBean;
    }

    @GetMapping(value = "/changeCardStatus")
    public ResponseBean changeCardStatus(@RequestParam Integer cardId, @RequestParam CommonStatusEnum status) {
        CustCard custCard = this.customerServiceImpl.changeStatus(cardId, status);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        responseBean.getData().put("custCard",custCard);
        return responseBean;
    }

    @GetMapping(value = "/findById")
    public ResponseBean findById(@RequestParam Integer id) {
        Customer customer = (Customer) this.customerCommonEntityService.findById(Customer.class, id);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("customer", customer);
        return responseBean;
    }

    @GetMapping(value = "/findByCardNo")
    public ResponseBean findByCardNo(@RequestParam String cardNo){
        MemberAccTuple<Member, Account> memberAccTuple = null;
        try {
            memberAccTuple = this.customerServiceImpl.findByCardNo(cardNo);
        }catch (Exception e){
            responseBean = ResponseUtil.createRespBean(true,StatusMsgEnum.QUERY_FALSE.getStatus(),e.getMessage());
            return responseBean;
        }
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("member", memberAccTuple.first);
        responseBean.getData().put("account", memberAccTuple.second);
        return responseBean;
    }

    @ApiOperation(value = "修改登陆密码",notes = "",httpMethod = "GET")
    @GetMapping(value = "/modifyPassword")
    public ResponseBean modifyPassword(String oldPassword, String newPassword, Integer customerId){
        Customer customer = null;
        try {
            customer = this.customerServiceImpl.modifyPassword(oldPassword,newPassword,customerId);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(false,201,e.getMessage());
            e.printStackTrace();
            return responseBean;
        }
        responseBean = ResponseUtil.createRespBean(true,200,"修改成功！");
        responseBean.getData().put("customer",customer);
        return  responseBean;
    }
}
