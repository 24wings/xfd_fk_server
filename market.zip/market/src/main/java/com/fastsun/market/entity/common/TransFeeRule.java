package com.fastsun.market.entity.common;

import javax.persistence.*;

import com.fastsun.market.entity.enums.AccountStatus;
import com.fastsun.market.entity.enums.AccountType;
import com.fastsun.market.entity.enums.OrderType;
import com.fastsun.market.entity.enums.PayType;
import com.fastsun.market.entity.enums.RuleFeeTypeEnum;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Table(name = "b_txn_area_rule")
@Entity
public class TransFeeRule implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer mktId;
    private Integer txnId;
    /** 交易重量收费率 千分之几 */
    private BigDecimal feeRateWgt;
    /** 交易金额收费率 */
    private BigDecimal feeRateAmt;
    private BigDecimal feeFixed;//固定收费
    private Integer subjectId;
    private String subjectName;
    /** 买卖标志 -1,1 */
    private Integer io;
    private Boolean enabled;
    private BigDecimal feeMax;
    private BigDecimal feeMin;
    private Date createTime;
    private String creator;
    private Integer creatorId;

    public TransFeeRule() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Integer getTxnId() {
        return txnId;
    }

    public void setTxnId(Integer txnId) {
        this.txnId = txnId;
    }

    public BigDecimal getFeeRateWgt() {
        return feeRateWgt;
    }

    public void setFeeRateWgt(BigDecimal feeRateWgt) {
        this.feeRateWgt = feeRateWgt;
    }

    public BigDecimal getFeeRateAmt() {
        return feeRateAmt;
    }

    public void setFeeRateAmt(BigDecimal feeRateAmt) {
        this.feeRateAmt = feeRateAmt;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Integer getIo() {
        return io;
    }

    public void setIo(Integer io) {
        this.io = io;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public BigDecimal getFeeMax() {
        return feeMax;
    }

    public void setFeeMax(BigDecimal feeMax) {
        this.feeMax = feeMax;
    }

    public BigDecimal getFeeMin() {
        return feeMin;
    }

    public void setFeeMin(BigDecimal feeMin) {
        this.feeMin = feeMin;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public BigDecimal getFeeFixed() {
        return feeFixed;
    }

    public void setFeeFixed(BigDecimal feeFixed) {
        this.feeFixed = feeFixed;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }
}
