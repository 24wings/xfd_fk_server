package com.fastsun.market.jpa;

import com.fastsun.framework.jpa.base.BaseRepository;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.entity.enums.AccountType;

public interface AccountJPA extends BaseRepository<Account, Integer> {
    // public Account findByMemeberIdAndAccountType(Integer memberId,
    // AccountStatusEnum status);
    Account findByAccountTypeAndNo(AccountType accountType,String no);
    public Account findByNo(String no);
}
