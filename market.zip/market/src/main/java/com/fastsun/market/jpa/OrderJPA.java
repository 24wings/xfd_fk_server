package com.fastsun.market.jpa;

import com.fastsun.market.entity.transOrder.Order;
import com.fastsun.market.entity.enums.OrderStatus;

import java.util.List;

import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface OrderJPA extends BaseRepository<Order, Integer>, JpaSpecificationExecutor<Order> {
    public List<Order> findBySellerMemIdAndStatus(Integer sellerMemId, OrderStatus orderstatus);

    Order findByOrderNo(String orderNo);
}
