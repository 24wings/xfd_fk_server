package com.fastsun.market.controller.app;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.market.entity.transOrder.Order;
import com.fastsun.market.utils.FreeMarkerTest;
import com.fastsun.market.utils.PrinterUtil;
import com.fastsun.market.utils.StatusMsgEnum;
import freemarker.template.TemplateException;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/common/print")

public class CommonPrintController extends BaseController {
    @Autowired
    FreeMarkerTest freemarket;

    ResponseBean responseBean;
    @ApiOperation(value = "打印小票", notes = "打印小票", httpMethod = "GET")
    @RequestMapping(value = "/common/print" ,method = RequestMethod.GET)
    public ResponseBean print(@RequestParam String orderNo) {
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        String printer = null;
        try {
            printer = freemarket.pay(orderNo);
        } catch (TemplateException e) {
            e.printStackTrace();
        }
        String base64Str = (new sun.misc.BASE64Encoder()).encode(PrinterUtil.getSendBuffer(printer));
        byte[]  buffer = PrinterUtil.getSendBuffer(printer);

        responseBean.getData().put("base64Str", base64Str);
        responseBean.getData().put("printDetail", printer);
        responseBean.getData().put("buffer", buffer);
        return responseBean;
    }

}
