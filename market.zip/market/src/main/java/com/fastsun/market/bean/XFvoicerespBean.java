package com.fastsun.market.bean;

public class XFvoicerespBean {
    /**
     * 返回值为 json 串，各字段如下：
     *
     * 参数	类型	说明
     * code	string	结果码(具体见错误码)
     * data	string	语音识别后文本结果
     * desc	string	描述
     * sid	string	会话ID
     */
    private String code;
    private String data;
    private String desc;
    private String sid;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }
}
