package com.fastsun.market.entity.enums;

public enum SubjectCodeEnum {

    TRANS_AMOUNT(1,"交易货款"),
    SERVICE_RECHARGE (2,"充值"),
    SERVICE_WITHDRAW(3,"提现"),
    SERVICE_TRANFER(4,"转账"),
    SERVICE_REPAY(5,"还款");
    Integer id;
    String name;
    SubjectCodeEnum(Integer id,String name){
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
