package com.fastsun.market.jpa;

import com.fastsun.market.entity.common.AppMsgNotify;
import com.fastsun.market.entity.enums.MsgType;

import java.util.List;

import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface AppMsgNotifyJPA extends BaseRepository<AppMsgNotify, Integer>, JpaSpecificationExecutor<AppMsgNotify> {
    // AppMsgNotify findFirstByPhoneAndMktIdAndTypeOrderBySendTimeDesc(String phone,
    // Integer mktId, String type);
    // List<AppMsgNotify> findByCustIdAndIsReadAndMsgTypeNotIn(Integer cusId,
    // boolean isRead, List<String> msgTypes);

    List<AppMsgNotify> findByCustId(Integer cusId);
}
