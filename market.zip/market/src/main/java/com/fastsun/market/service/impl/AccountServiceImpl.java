package com.fastsun.market.service.impl;

import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.market.entity.account.AccRecvPay;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.jpa.AccRecvPayJPA;
import com.fastsun.market.jpa.AccountJPA;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AccountServiceImpl{

    @Autowired
    private AccRecvPayJPA accRecvPayJPA;
    @Autowired
    private AccountJPA accountJPA;
    @Autowired
    CommonEntityService accountCommonEntityService;
    //创建账户
    public Account createAccount(Account entity){
        //todo:检查账户名是否已经存在
        long count = accountCommonEntityService.getRecordCount(RequestUtil.getQueryParameter(entity,"or","no"),Account.class);
        if(count > 0){
            return null;
        }
        return this.accountJPA.save(entity);
    }

    //todo:更改账户状态(禁用，启用，冻结，销户)

    //创建收支记录并更新账户余额
    public AccRecvPay createRecvPay(AccRecvPay entity){
        Account account =this.accountJPA.findById(entity.getAccountId()).get();
        if(account!=null){
            BigDecimal io=new BigDecimal(entity.getIo());
            account.setBalAmt(account.getBalAmt().add(entity.getAmount().multiply(io)));
            account.setAvailAmt(account.getAvailAmt().add(entity.getAmount().multiply(io)));
        }
        return accRecvPayJPA.save(entity);
    }

    //todo:查询收支记录,可以使用通用查询接口
    //todo:查询账户信息,可以使用通用查询接口

    //todo:查询收支记录相关订单信息,以键值对形式返回
    public List<Map<String,String>> findOrderInfo(Integer id) {

        return new ArrayList<>();
    }
}
