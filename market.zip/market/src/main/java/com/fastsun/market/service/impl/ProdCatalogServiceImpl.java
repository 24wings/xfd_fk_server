package com.fastsun.market.service.impl;

import com.fastsun.market.entity.common.ProdCatalog;
import com.fastsun.market.entity.common.Product;
import com.fastsun.market.entity.common.RecvPaySubject;
import com.fastsun.market.jpa.ProdCatalogJPA;
import com.fastsun.framework.jpa.base.SimplePageBuilder;
import com.fastsun.framework.jpa.base.SimpleSpecificationBuilder;
import com.fastsun.framework.service.impl.BaseServiceImpl;
import com.fastsun.market.jpa.ProductJPA;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProdCatalogServiceImpl {


     @Autowired
    ProductJPA productJPA;
     @Autowired
     ProdCatalogJPA prodCatalogJPA;


    /*
     * 查询平台国标品类，一般情况下，数据库marketId为0的，为平台国标品类
     */
    public Page<ProdCatalog> findAll(String parentId, Integer page, Integer pageSize, Integer mktId) {
        SimpleSpecificationBuilder ssb = null;
        if (!StringUtils.isEmpty(parentId)) {
            ssb = new SimpleSpecificationBuilder<>("parentId", "=", parentId);
        } else {
            return this.prodCatalogJPA.findAll(new SimpleSpecificationBuilder<>("parentId", "=", "-1")
                    .add("mktId", "=", 0).generateSpecification(), SimplePageBuilder.generate(page, pageSize, null));
        }
        if (ssb == null) {
            ssb = new SimpleSpecificationBuilder("mktId", "=", mktId);
            return this.prodCatalogJPA.findAll(ssb.generateSpecification(),
                    SimplePageBuilder.generate(page, pageSize, null));
        }
        ssb = ssb.add("mktId", "=", mktId);
        return this.prodCatalogJPA.findAll(ssb.generateSpecification(),
                SimplePageBuilder.generate(page, pageSize, null));
    }

    public List<ProdCatalog> findAll(Integer mktId) {
        SimpleSpecificationBuilder ssb = new SimpleSpecificationBuilder<>("mktId", "=", mktId);
        return this.prodCatalogJPA.findAll(ssb.generateSpecification());
    }

    public Long count(String name, String code) {
        SimpleSpecificationBuilder<RecvPaySubject> ssb = new SimpleSpecificationBuilder("cateName", "=", name);
        ssb.addOr("cateCode", "=", code);
        return this.prodCatalogJPA.count(ssb.generateSpecification());
    }

    public Product productCreate(Product product){
        ProdCatalog prodCatalog = this.prodCatalogJPA.findById(product.getProdCatId()).get();
        product.setProdCatalog(prodCatalog);
        return this.productJPA.save(product);
    }
}
