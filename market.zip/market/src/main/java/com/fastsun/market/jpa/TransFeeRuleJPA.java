package com.fastsun.market.jpa;

import com.fastsun.framework.jpa.base.BaseRepository;
import com.fastsun.market.entity.common.TransFeeRule;

public interface TransFeeRuleJPA extends BaseRepository<TransFeeRule,Integer> {
}
