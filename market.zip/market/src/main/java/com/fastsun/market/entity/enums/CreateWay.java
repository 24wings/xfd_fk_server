package com.fastsun.market.entity.enums;

public enum CreateWay {
    WEB,APP,POS;
}
