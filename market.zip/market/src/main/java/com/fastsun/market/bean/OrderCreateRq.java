package com.fastsun.market.bean;

import com.fastsun.market.entity.transOrder.OrderDetail;
import com.fastsun.market.entity.enums.CreateWay;
import com.fastsun.market.entity.enums.PayType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
public class OrderCreateRq {
//    private String orderNo;
    private String cardNo;
    private Integer buyerMemId;
    private Integer buyerCustId;
    private String buyerInfo;
    private String sellerMemNo;
    @NotNull
    private Integer sellerMemId;
    @NotNull
    private Integer sellerCustId;
    @NotNull
    private PayType payType;
    @NotNull
    private CreateWay createWay;
    @NotNull
    private Integer mktId;
    @NotNull
    private Integer transAreaId;
    @NotNull
    private BigDecimal apAmt;
    @NotNull
    @Size(min = 1) // 被注释的元素的大小必须在指定的范围内
    private List<OrderDetail> orderDetails;
    @NotNull
    private BigDecimal totalWeight;
}
