package com.fastsun.market.bean;

public class ViewInfo {
}
