package com.fastsun.market.entity.enums;

public enum ParamsType {

    TEXT,
    IMAGE,
    SELECT,
    SWITCH
}
