package com.fastsun.market.jpa;

import com.fastsun.market.entity.enums.AccountType;
import com.fastsun.market.entity.member.MemberAccount;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public interface MemberAccountJPA
        extends BaseRepository<MemberAccount, Integer>, JpaSpecificationExecutor<MemberAccount> {
     List<MemberAccount> findByRelationId(Integer relationId);
     List<MemberAccount> findByAccountNo(String accountNo);
     MemberAccount findByRelationIdAndAccountType(Integer relationId, AccountType accountType);
}
