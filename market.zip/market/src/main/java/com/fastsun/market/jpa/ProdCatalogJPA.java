package com.fastsun.market.jpa;

import com.fastsun.market.entity.common.ProdCatalog;

import java.util.List;

import com.fastsun.framework.jpa.base.BaseRepository;
import io.swagger.models.auth.In;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.transaction.annotation.Transactional;

public interface ProdCatalogJPA extends BaseRepository<ProdCatalog, Integer>, JpaSpecificationExecutor<ProdCatalog> {
    List<ProdCatalog> findByMktIdAndParentId(Integer mktId, Integer parentId);
    ProdCatalog findByCatCodeAndMktId(String catCode, Integer mktId);
    List<ProdCatalog> findByMktIdAndTxnId(Integer mktId,Integer txnId);
}
