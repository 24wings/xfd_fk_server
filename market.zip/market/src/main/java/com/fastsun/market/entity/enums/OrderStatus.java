package com.fastsun.market.entity.enums;

import javax.persistence.AttributeConverter;

public enum OrderStatus {
    TEMP(0,"暂存"),SUBMIT(1,"下单"),SELLER_AGREE(2,"卖家同意"),TOBE_PAY(3,"待付"),CLOSED(4,"关闭"),TOBE_CONFIRM(5,"待确定"),PAID(6,"已付"),PAY_FAIL(7,"支付失败"),REFUNDED(8,"退货");

    private Integer key;
    private String value;

    OrderStatus(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey() {
        return key;
    }
    public String getValue() {
        return value;
    }

//    public static class Convert implements AttributeConverter<OrderStatus,Integer> {
//
//        @Override
//        public Integer convertToDatabaseColumn(OrderStatus status) {
//            return status == null ? null : status.getKey();
//        }
//
//        @Override
//        public OrderStatus convertToEntityAttribute(Integer integer) {
//            for (OrderStatus type : OrderStatus.values()){
//                if(integer.equals(type.getKey())){
//                    return type;
//                }
//            }
//            throw new RuntimeException("Unknown database value: " + integer);
//        }
//    }
}
