package com.fastsun.market.controller.web;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ImageUtil;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.utils.StatusMsgEnum;
import com.fastsun.market.bean.OrderCreateRq;
import com.fastsun.market.bean.OrderPayRq;
import com.fastsun.market.entity.transOrder.Order;
import com.fastsun.market.entity.enums.CreateWay;
import com.fastsun.market.entity.enums.OrderStatus;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.jpa.MemberJPA;
import com.fastsun.market.service.impl.OrderServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import io.swagger.annotations.Api;

@Api(description = "订单", tags = { "market.web.Order" })
@RestController
@RequestMapping("/api/order")
public class OrderController extends BaseController {

    private ResponseBean responseBean;
    @Autowired
    private OrderServiceImpl orderServiceImpl;
    @Autowired
    private MemberJPA memberJPA;
    @Autowired
    private CommonEntityService commonEntityService;

    @PostMapping(value = "/orderCreate")
    public ResponseBean orderCreate(HttpServletRequest request, @RequestBody @Valid OrderCreateRq orderCreateRq){
        Order order = null;
        try {
            order = orderServiceImpl.orderCreate(request, orderCreateRq,null);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(false,201,"创建订单失败！");
            e.printStackTrace();
            return responseBean;
        }
        String qCodeBase64Str = ImageUtil.convertString(order.getOrderNo());
        responseBean = ResponseUtil.createRespBean(true,200,"创建订单成功");
        responseBean.getData().put("order",order);
        return responseBean;
    }

    @GetMapping(value = "/getOrderInfo")
    public ResponseBean getOrderInfo(@RequestParam String orderNo){
        Order order = this.orderServiceImpl.getOrderInfo(orderNo);
        Member sellerMember = this.memberJPA.findById(order.getSellerMemId()).get();
        Member buyerMember = null;
        if(order.getBuyerMemId()!= null){
            buyerMember = this.memberJPA.findById(order.getBuyerMemId()).get();
        }
        responseBean = ResponseUtil.createRespBean(true,StatusMsgEnum.QUERY_SUCCESS.getStatus(),StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("order",order);
        responseBean.getData().put("sellerMember",sellerMember);
        responseBean.getData().put("buyerMember",buyerMember);
        return  responseBean;
    }
    @GetMapping(value = "/refund")
    public ResponseBean orderRefund(@RequestParam String orderNo, @RequestParam OrderStatus status){
        Order order = this.orderServiceImpl.getOrderInfo(orderNo);
        order.setStatus(status);
        Order orderDB = (Order)this.commonEntityService.update(order);
        responseBean = ResponseUtil.createRespBean(true,200,"退货成功！");
        responseBean.getData().put("order",orderDB);
        return  responseBean;
    }

    @PostMapping(value = "/orderPay")
    public ResponseBean orderPay(HttpServletRequest request,@RequestBody @Valid OrderPayRq orderPayRq){
        Order order = null;
        try {
            order = this.orderServiceImpl.oderPay(request,orderPayRq);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(false,201,"订单支付失败！");
            e.printStackTrace();
            return responseBean;
        }
        responseBean = ResponseUtil.createRespBean(true,200,"订单支付成功!");
        if(CreateWay.WEB.equals(order.getCreateWay())){
            String printStr = this.orderServiceImpl.createOrderPrintStr(order);
            responseBean.getData().put("printStr",printStr);
        }
        responseBean.getData().put("order",order);
        return responseBean;
    }
}
