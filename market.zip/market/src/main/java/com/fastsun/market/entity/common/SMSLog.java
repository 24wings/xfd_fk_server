package com.fastsun.market.entity.common;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name = "sms_log")
public class SMSLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    // @Column(nullable = false)
    private Boolean isVerifySms = true;// 是否验证码短信
    private String verifyCode;// 验证码
    private String verifyType;// 验证类型
    private String mobi;// 手机号
    private String content;// 短信内容
    private Date createTime = new Date();// 创建时间
    private Integer mktId;
    private String smsSupplier;// 短信服务商

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the isVerifySms
     */
    public Boolean getIsVerifySms() {
        return isVerifySms;
    }

    /**
     * @param isVerifySms the isVerifySms to set
     */
    public void setIsVerifySms(Boolean isVerifySms) {
        this.isVerifySms = isVerifySms;
    }

    public String getVerifyCode() {
        return verifyCode;
    }

    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }

    public String getMobi() {
        return mobi;
    }

    public void setMobi(String mobi) {
        this.mobi = mobi;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public String getSmsSupplier() {
        return smsSupplier;
    }

    public void setSmsSupplier(String smsSupplier) {
        this.smsSupplier = smsSupplier;
    }

    public SMSLog() {
    }

    public String getVerifyType() {
        return verifyType;
    }

    public void setVerifyType(String verifyType) {
        this.verifyType = verifyType;
    }
}
