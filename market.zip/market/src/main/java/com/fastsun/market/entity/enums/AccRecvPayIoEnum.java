package com.fastsun.market.entity.enums;

public class AccRecvPayIoEnum {
    public static Integer Out = -1;
    public static Integer In = 1;
}
