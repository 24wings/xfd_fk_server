package com.fastsun.market.controller.web;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.bean.Paging;
import com.fastsun.market.entity.common.RecvPaySubject;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(description = "市场自定义收支科目", tags = { "market.web.Subject" })
@RestController
@RequestMapping("/api/subject")
public class SubjectController extends BaseController {

        @Autowired
        private CommonEntityService recvPaySubjectCommonEntityService;

        private ResponseBean responseBean;

        @ApiOperation(value = "创建自定义收支科目", notes = "新建并判重", httpMethod = "POST")
        @RequestMapping(value = "/custom-create", method = RequestMethod.POST)
        public ResponseBean addSubject(@RequestBody RecvPaySubject subject) {
                if (subject == null) {
                        responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                                        StatusMsgEnum.PARAM_NULL.getMsg());
                        return responseBean;
                }
                // Long count =
                // this.subjectServiceImpl.count(subject.getSubjectName(),subject.getSubjectCode());
                long count = this.recvPaySubjectCommonEntityService
                                .getRecordCount(RequestUtil.getQueryParameter(subject, "or", "", ""), subject.getClass());
                if (count > 0) {
                        responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_REPEAT.getStatus(),
                                        StatusMsgEnum.ADD_REPEAT.getMsg());
                        return responseBean;
                }
                boolean flag = this.recvPaySubjectCommonEntityService.save(subject);
                if (flag) {
                        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                                        StatusMsgEnum.ADD_SUCCESS.getMsg());
                } else {
                        responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_FAILED.getStatus(),
                                        StatusMsgEnum.ADD_FAILED.getMsg());
                }
                return responseBean;
        }

        @ApiOperation(value = "修改自定义收支科目", notes = "", httpMethod = "POST")
        @RequestMapping(value = "/custom-update", method = RequestMethod.POST)
        public ResponseBean updateSubject(@RequestBody RecvPaySubject subject) {
                RecvPaySubject newSubject = (RecvPaySubject) this.recvPaySubjectCommonEntityService.update(subject);
                responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
                responseBean.getData().put("subject", newSubject);
                return responseBean;
        }

        // @ApiOperation(value = "删除固定收费项目",notes = "" ,httpMethod = "GET")
        // @RequestMapping(value = "/delete",method = RequestMethod.GET)
        // public ResponseBean deleteSubject(@RequestParam Integer subId) {
        // if (subId == null) {
        // responseBean = ResponseUtil.createRespBean(false,
        // StatusMsgEnum.PARAM_NULL.getStatus(), StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        // return responseBean;
        // }
        // subjectServiceImpl.deleteSubject(subId);
        // responseBean =
        // ResponseUtil.createRespBean(true,StatusMsgEnum.DELETE_SUCCESS.getStatus(),StatusMsgEnum.DELETE_SUCCESS.getMsg());
        // return responseBean;
        // }

        @ApiOperation(value = "查询自定义收支列表", notes = "根据parentId查询", httpMethod = "GET")
        @PostMapping(value = "/custom-subjects")
        public ResponseBean getListSubject(@RequestBody QueryParameter queryParameter) {
                Paging<RecvPaySubject> subjects = this.recvPaySubjectCommonEntityService.findPagedEntity(queryParameter,
                                RecvPaySubject.class);
                responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                                StatusMsgEnum.QUERY_SUCCESS.getMsg());
                responseBean.getData().put("subjects", subjects);
                return responseBean;
        }

        @ApiOperation(value = "查询固定收支列表(平台定义)", notes = "根据市场Id查询", httpMethod = "Post")
        @RequestMapping(value = "/internal-list", method = RequestMethod.POST)
        public ResponseBean getFixedList(@RequestBody QueryParameter queryParameter) {
                Paging<RecvPaySubject> subjects = this.recvPaySubjectCommonEntityService.findPagedEntity(queryParameter,
                        RecvPaySubject.class);
                responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                        StatusMsgEnum.QUERY_SUCCESS.getMsg());
                responseBean.getData().put("paging", subjects);
                return responseBean;
        }
}
