package com.fastsun.market.controller.web;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.market.bean.FinishRecord;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.bean.Paging;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.entity.synthesizeFee.FeeList;
import com.fastsun.market.entity.synthesizeFee.PayFee;
import com.fastsun.market.entity.synthesizeFee.PayFeeDetail;
import com.fastsun.market.jpa.*;
import com.fastsun.market.service.impl.synthesizeFee.FeelistServicelmpl;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@Api(description = "收费", tags = { "market.web.Feelist" })
@RestController
@RequestMapping("/api/feelist")
public class FeelistController extends BaseController {
    private FeelistServicelmpl feelistServicelmpl;
    private MemberJPA memberJPA;
    private FeeListJPA feeListJPA;

    @Autowired
    private PayFeeJPA payFeeRecordJPA;
    @Autowired
    private PayFeeDetailJPA payFeeListJPA;
    private ResponseBean responseBean = null;
    @Autowired
    private CommonEntityService feeListCommonEntityService;

    @Autowired
    public FeelistController(FeelistServicelmpl feelistServicelmpl, MemberJPA memberJPA, FeeListJPA feelistJPA) {
        this.feelistServicelmpl = feelistServicelmpl;
        this.memberJPA = memberJPA;
        this.feeListJPA = feelistJPA;

    }

    // /payFeeList/query
    @ApiOperation(value = "账单查询", notes = "", httpMethod = "Get")
    @RequestMapping(value = "/payFeeList/query", method = RequestMethod.GET)
    public ResponseBean payFeeListQuery(@RequestParam Integer recordId) {
        ResponseBean res = ResponseUtil.createRespBean(true, 200, "确认消息");
        PayFeeDetail lists = payFeeListJPA.findById(recordId).get();
        res.getData().put("payFeeLists", lists);
        return res;
    }

    @ApiOperation(value = "完结账单", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/payFeeRecord/finish", method = RequestMethod.POST)
    public ResponseBean recordFinish(@RequestBody FinishRecord finishRecord) {
//        ResponseBean res = ResponseUtil.createRespBean(true, 200, "查询成功");
//        MemberPayFee record = payFeeRecordJPA.findById(finishRecord.getMasterId()).get();
//        if (record != null) {
//            if (finishRecord.getMasterId() != 0 && finishRecord.getEpId() != 0
//                    && finishRecord.getTruepayMoney() != null) {
////                EmployeeAccount empAccount = this.empAccountService.getOrCreateEmployeeAccount(finishRecord.getEpId(),
////                        record.getMktId());if (empAccount != null) {
////
//                    record.setRealChargeMoney(finishRecord.getTruepayMoney());
//                    // record.set
////                    EmployeeAccountLog log = new EmployeeAccountLog();
////                    log.setActorEpId(finishRecord.getEpId());
////                    log.setMemberId(record.getPayFeeMemberId());
////                    log.setEmployeeId(finishRecord.getEpId());
////                    log.setMoney(finishRecord.getTruepayMoney());
////                    log.setMktId(empAccount.getMktId());
////                    log.setMoney(finishRecord.getTruepayMoney());
////                    empAccount.setBalance(empAccount.getBalance().add(finishRecord.getTruepayMoney()));
////                    this.employeeAccountLogJPA.saveAndFlush(log);
//
//                    this.employeeAccountJPA.saveAndFlush(empAccount);
//                    this.payFeeRecordJPA.saveAndFlush(record);
//                    record.setStatus("finish");
//                    record.setRealChargeMoney(finishRecord.getTruepayMoney());
//                    payFeeRecordJPA.saveAndFlush(record);
//                } else {
//                    res = ResponseUtil.createRespBean(false, 400, "找不到员工账户");
//                }
//
//            } else {
//                res = ResponseUtil.createRespBean(false, 400, "不合法的参数");
//            }
//
//        } else {
//            res = ResponseUtil.createRespBean(false, 400, "找不到记录");
//        }
//
//        return res;
        return null;
    }

    @ApiOperation(value = "查询收费账单详情", notes = "", httpMethod = "Get")
    @RequestMapping(value = "/payFeeRecord/detail", method = RequestMethod.GET)
    public ResponseBean recordDetail(@RequestParam Integer recordId) {
        ResponseBean res = ResponseUtil.createRespBean(true, 200, "获取详情");
        PayFee record = payFeeRecordJPA.findById(recordId).get();
        if (record != null) {
            List<PayFeeDetail> payFeeBills = record.getPayDetails();
            List<Integer> payFeeListIdArray = new ArrayList<Integer>();
            for (PayFeeDetail payFeeBill : payFeeBills) {
                payFeeListIdArray.add(payFeeBill.getId());
            }

            payFeeBills = payFeeListJPA.findByIdIn(payFeeListIdArray);

            res.getData().put("payFeeLists", payFeeBills);
            res.getData().put("payFeeListIdSet", payFeeListIdArray);
        } else {
            res = ResponseUtil.createRespBean(false, 200, "记录不存在");
        }
        return res;
    }

    @ApiOperation(value = "新增收费单", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/payFeeRecord/create", method = RequestMethod.POST)
    public ResponseBean addPayFeeRecord(@RequestBody PayFee payFee) {
        payFee.setActorId(payFee.getPayDetails().get(0).getId());
        payFee = this.payFeeRecordJPA.saveAndFlush(payFee);
        for (PayFeeDetail payfeeBill : payFee.getPayDetails()) {
            // payfeeBill.setMasterId(payFee.getId());
        }

        payFee = this.payFeeRecordJPA.saveAndFlush(payFee);

        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        responseBean.getData().put("payFeeRecord", payFee);
        return responseBean;
    }

    @ApiOperation(value = "更新收费列表状态", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/status/update", method = RequestMethod.POST)
    public ResponseBean updateFeeListStatus(@RequestBody Integer[] feeListIds, @RequestParam String status) {
        ResponseBean res = ResponseUtil.createRespBean(true, 200, "成功");
        List<FeeList> feelists = feeListJPA.findByIdIn(feeListIds);
        for (FeeList feeList : feelists) {
            feeList.setStatus(status);
        }
        feeListJPA.saveAll(feelists);
        return res;
    }

    @ApiOperation(value = "新增费用清单", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/creat", method = RequestMethod.POST)
    public ResponseBean addFeeList(@RequestBody FeeList feelist) {
        if (feelist == null) {
            responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return responseBean;
        }
        Long count = this.feelistServicelmpl.count(feelist.getTitle(), feelist.getId());
        if (count > 0) {
            responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_REPEAT.getStatus(),
                    StatusMsgEnum.ADD_REPEAT.getMsg());
        }

        FeeList fee = this.feelistServicelmpl.saveFeelist(feelist);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        responseBean.getData().put("feelist", fee);
        return responseBean;
    }

    @ApiOperation(value = "修改费用清单", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseBean updateFeelist(@RequestBody FeeList feelist) {
        FeeList newFeelist = this.feelistServicelmpl.updateFeelist(feelist);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        responseBean.getData().put("feelist", newFeelist);
        return responseBean;
    }

    @ApiOperation(value = "删除", notes = "", httpMethod = "Get")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseBean deleteFeelist(@RequestParam Integer id) {
        ResponseBean res = null;
        if (id == null) {
            res = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return res;
        }
        this.feelistServicelmpl.deleteFeelist(id);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.DELETE_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return res;
    }

    @ApiOperation(value = "清单列表", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public ResponseBean listFee(@RequestBody QueryParameter queryParameter) {

        Paging<FeeList> paging = this.feeListCommonEntityService.findPagedEntity(queryParameter, FeeList.class);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("paging", paging);
        return responseBean;
    }

    @ApiOperation(value = "获取会员id", notes = "", httpMethod = "Get")
    @RequestMapping(value = "/mob", method = RequestMethod.GET)
    public ResponseBean mobFeelist(Integer mktId, String mobi) {
        ResponseBean res = null;
        Member member = memberJPA.findById(mktId).get();
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        res.getData().put("member", member);
        return res;
    }

}
