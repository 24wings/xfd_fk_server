package com.fastsun.market.entity.enums;

import io.swagger.annotations.ApiModel;

@ApiModel("account_status")
public enum AccountStatus {
    ENABLE(0,"可用"), DISABLE(1,"停用"), FROZEN(2,"冻结"), CANCEL(3,"注销");
    Integer key;
    String value;
    AccountStatus(Integer key ,String value) {
        this.key = key;
        this.value = value;
    }
    public Integer getKey() {
        return key;
    }
    public String getValue() {
        return value;
    }
}
