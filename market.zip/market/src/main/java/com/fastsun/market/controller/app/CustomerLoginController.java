package com.fastsun.market.controller.app;

import com.fastsun.framework.bean.RequestBean;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.framework.utils.JwtTokenUtil;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.utils.StatusMsgEnum;
import com.fastsun.market.MarketApi;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.jpa.CustomerJPA;
import com.fastsun.market.service.impl.CustomerServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Api(description = "customer",tags = {"market.app.CustomerLogin"})
@RestController
@RequestMapping("/customer")
public class CustomerLoginController extends BaseController {
    @Autowired
    CustomerServiceImpl customerService;

    @Autowired
    private CustomerJPA customerJPA;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    @Autowired
    private PasswordEncoder encoder;

    @ApiOperation(value = "app用户登陆", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ResponseBean signin(@RequestBody RequestBean requestBean) {
        ResponseBean res = null;
        try {
            Customer customer = this.customerJPA.findByMktIdAndMobi(requestBean.getMktId(),requestBean.getUserName());
            final UsernamePasswordAuthenticationToken upToken = new UsernamePasswordAuthenticationToken(
                    requestBean.getUserName()+","+ customer.getMktId() +"#customer", requestBean.getPassword());
            Authentication authentication = authenticationManager.authenticate(upToken);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            final UserDetails userDetails = userDetailsService.loadUserByUsername(requestBean.getUserName()+","+ customer.getMktId() +"#customer");
            final String token = jwtTokenUtil.generateToken(userDetails.getUsername(), "customer");
            res = ResponseUtil.createRespBean(true,StatusMsgEnum.LOGIN_SUCCESS.getStatus(),StatusMsgEnum.LOGIN_SUCCESS.getMsg());
            res.getData().put("customer",customer);
            res.getData().put("token",token);
        }catch (Exception  e){
            res = ResponseUtil.createRespBean(false,StatusMsgEnum.LOGIN_FALSE.getStatus(),StatusMsgEnum.LOGIN_FALSE.getMsg());
            return res;
        }
        return res;
    }

    @ApiOperation(value = "app用户注册", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/signup", method = RequestMethod.POST)
    public ResponseBean singup(HttpServletRequest request,@RequestBody Customer newCustomer, @RequestParam String authcode) throws Exception {
        // return ResponseUtil.createRespBean(true, 200, newCustomer.getMobi() +
        // newCustomer.getMktId());
        Customer exsitCustomer = customerJPA.findByMktIdAndMobi(newCustomer.getMktId(), newCustomer.getMobi());

        if (exsitCustomer == null) {
            Customer customer = this.customerService.saveCustomer(request,null,newCustomer);
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "");
            success.getData().put("customer", customer);
            return success;
        } else {
            ResponseBean fail = ResponseUtil.createRespBean(false, com.fastsun.market.utils.StatusMsgEnum.PHONE_CUSTOMER_EXISIT.getStatus(),
                    com.fastsun.market.utils.StatusMsgEnum.PHONE_CUSTOMER_EXISIT.getMsg());
            fail.getData().put("customer", null);
            return fail;
        }
    }

    @ApiOperation(value = "忘记密码", notes = "", httpMethod = "POST")
    @RequestMapping(value = MarketApi.CustomerApi.forgotPassword, method = RequestMethod.POST)
    public ResponseBean forgotPassword(@RequestBody Customer customer) throws Exception {
        Customer existCustomer = customerJPA.findByMktIdAndMobi(customer.getMktId(), customer.getMobi());
        if(existCustomer == null)
        {
            return ResponseUtil.createRespBean(false, 400, "该客户不存在！");
        }
        existCustomer.setPassword(encoder.encode(customer.getPassword()));
        customerJPA.saveAndFlush(existCustomer);
        return ResponseUtil.createRespBean(true, 200, "忘记密码成功");
    }
}
