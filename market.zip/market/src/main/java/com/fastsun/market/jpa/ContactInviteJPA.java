package com.fastsun.market.jpa;

import com.fastsun.framework.jpa.base.BaseRepository;
import com.fastsun.market.entity.enums.MemberInviteStatusEnum;
import com.fastsun.market.entity.member.ContactInvite;

import java.util.List;

public interface ContactInviteJPA extends BaseRepository<ContactInvite, Integer> {

    List<ContactInvite> findByMemberId(Integer memberId);

    List<ContactInvite> findByFriendinvitemId(Integer friendinvitemId);

    List<ContactInvite> findByMemberIdAndMktId(Integer memberId,Integer mktId);

    ContactInvite findByMemberIdAndFriendinvitemIdAndStatus(Integer memberId, Integer friendId, MemberInviteStatusEnum status);
}
