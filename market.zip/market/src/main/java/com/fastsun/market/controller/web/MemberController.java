package com.fastsun.market.controller.web;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.framework.jpa.UserJPA;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.enums.CommonStatusEnum;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.service.impl.MemberServiceImpl;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;
import javax.servlet.http.HttpServletRequest;

@Api(description = "会员", tags = { "market.app.Member" })
@RestController
@RequestMapping("/api/member")
public class MemberController extends BaseController {

    private ResponseBean responseBean = null;

    @Autowired
    private MemberServiceImpl memberServiceImpl;

    @Autowired
    private UserJPA userJPA;

    @Autowired
    private CommonEntityService memberCommonEntityService;

    @PostMapping(value = "/create")
    @ApiOperation(value = "新建会员帐号", notes = "", httpMethod = "POST")
    public ResponseBean createMember(HttpServletRequest request, @RequestBody Member member) {

        // Customer customer =
        // this.customerServiceImpl.findByMobi(member.getMobi());getQueryParameter
        // Long count =
        // this.memberServiceImpl.count(member.getMobi(),member.getIdCardNo());
        long count = this.memberCommonEntityService
                .getRecordCount(RequestUtil.getQueryParameter(member, "or", "phoneNo", "idCardNo"), Member.class);
        if (count > 0) {
            responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_REPEAT.getStatus(), "手机或身份证号已注册！");
            return responseBean;
        }
        Member memberDB = this.memberServiceImpl.saveMember(member, request);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        responseBean.getData().put("member", memberDB);
        return responseBean;
    }

    @PostMapping(value = "/page")
    public ResponseBean findAllTolist(@RequestBody QueryParameter queryParameter) {
        Paging<Member> paging = this.memberServiceImpl.findAll(queryParameter);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("paging", paging);
        return responseBean;
    }

    @PostMapping(value = "/like")
    public ResponseBean findLike(@RequestBody QueryParameter queryParameter) {
        Paging<Member> paging = this.memberServiceImpl.search(queryParameter);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("paging", paging);
        return responseBean;
    }

    @GetMapping(value = "/detail")
    public ResponseBean memberDetail(@RequestParam Integer memberId) {
        Member member = (Member) this.memberCommonEntityService.findById(Member.class, memberId);
        User user = this.userJPA.findById(member.getCreatorId()).get();
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("member", member);
        responseBean.getData().put("employee", user);
        return responseBean;
    }

    @PostMapping(value = "/likePage")
    public ResponseBean modifyPayPassword(@RequestBody QueryParameter queryParameter) {
        Paging<Member> paging = this.memberServiceImpl.search(queryParameter);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("paging", paging);
        return responseBean;
    }

//    @GetMapping(value = "/modifyPayPassword")
////    public ResponseBean

//    @GetMapping(value = "/demo")
//    public ResponseBean demo(@RequestParam String  cardNo) {
//        MemberAccTuple<Member,Account> paging = null;
//        try {
//            paging = this.memberServiceImpl.findByCardNo(cardNo);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
//                StatusMsgEnum.QUERY_SUCCESS.getMsg());
//        responseBean.getData().put("paging", paging);
//        return responseBean;
//    }

    @ApiOperation(value = "修改会员资料", notes ="", httpMethod = "GET")
    @RequestMapping(value ="/updateMember" ,method = RequestMethod.GET)
    public ResponseBean updateMemberInfo(@RequestBody Member member)
    {
        ResponseBean res = null;
        Member newMember =(Member) memberCommonEntityService.update(member);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        res.getData().put("member",newMember);
        return res;
    }

    @GetMapping("/modifyPayPassword")
    public ResponseBean modifyPayPassword(@RequestParam Integer memberId,@RequestParam String newPayPassword){
        Member member = this.memberServiceImpl.modifyPayPassword(newPayPassword,memberId);
        responseBean = ResponseUtil.createRespBean(true,200, com.fastsun.framework.utils.StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        responseBean.getData().put("member",member);
        return responseBean;
    }

    @GetMapping("/changeMemberStatus")
    public ResponseBean changeMemberStatus(@RequestParam Integer memberId,@RequestParam CommonStatusEnum status){
        Member member = this.memberServiceImpl.changeMemberStatus(memberId,status);
        responseBean = ResponseUtil.createRespBean(true,200, com.fastsun.framework.utils.StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        responseBean.getData().put("member",member);
        return responseBean;
    }
}
