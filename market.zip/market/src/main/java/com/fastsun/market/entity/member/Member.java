package com.fastsun.market.entity.member;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fastsun.framework.entity.queryTemplate.EntityMetaData;
import com.fastsun.framework.entity.queryTemplate.FieldMetaData;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.entity.enums.*;
import io.swagger.models.auth.In;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" })
@Table(name = "b_member", uniqueConstraints = { @UniqueConstraint(columnNames = { "no" }) })
@Entity
@EntityMetaData(objectName = "会员",pkKey = "id")
public class Member implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @FieldMetaData(alias = "会员编号",isQuery = true)
    private String no; // 会员编号
    @FieldMetaData(alias = "会员名称",isQuery = true)
    private String name; // 会员名
    @FieldMetaData(alias = "身份证号",isQuery = true)
    private String idCardNo; // 身份证号
    @Column(length = 1000)
    private String idcardImgUrl;// 身份证照片
    private MemberType memberType;
    private String legalName; // 法人姓名
    private String coLicImgUrl;// 公司营业执照照片
    private String taxNo;
    private String address;
    private String phoneNo;

    private CommonStatusEnum status;// 会员状态
    @Enumerated(EnumType.ORDINAL)
    private CreateWay createWay;// 创建途径

    private Integer mktId;// 所属市场id
    @FieldMetaData(alias = "创建时间",isQuery = true)
    private Date createTime;// 创建时间
    private Integer creatorId;// 创建人id
    private String creator;// 创建人
    private String payPassword;// 支付密码
    private boolean pwdEncrypted;// 密码是否已加密
    private boolean certificated;// 是否已经实名认证
    private Date certTime;// 实名认证时间
    @Enumerated(EnumType.ORDINAL)
    private CertWayEnum certWay;// 实名认证方法
    private String certLog;// 实名认证日志

    @Transient
    private String mobi;// 冗余字段mobi
    @Transient
    private BigDecimal creditAmount;//当前市场所欠总金额
    @Transient
    private String pinYinName;
    private Integer customerId;// 会员对应customer
    private Integer errorCount;
    private String frendIds;
    @OneToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER, mappedBy = "member", orphanRemoval = true)
    private List<Customer> customers;
    @Transient
    private List<Account> accounts;

    public List<Account> getAccounts() {
        return accounts;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo;
    }

    public String getIdcardImgUrl() {
        return idcardImgUrl;
    }

    public void setIdcardImgUrl(String idcardImgUrl) {
        this.idcardImgUrl = idcardImgUrl;
    }

    public CommonStatusEnum getStatus() {
        return status;
    }

    public void setStatus(CommonStatusEnum status) {
        this.status = status;
    }

    public CreateWay getCreateWay() {
        return createWay;
    }

    public void setCreateWay(CreateWay createWay) {
        this.createWay = createWay;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getPayPassword() {
        return payPassword;
    }

    public void setPayPassword(String payPassword) {
        this.payPassword = payPassword;
    }

    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }

    public String getMobi() {
        return mobi;
    }

    public void setMobi(String mobi) {
        this.mobi = mobi;
    }

    public boolean isPwdEncrypted() {
        return pwdEncrypted;
    }

    public void setPwdEncrypted(boolean pwdEncrypted) {
        this.pwdEncrypted = pwdEncrypted;
    }

    public String getCoLicImgUrl() {
        return coLicImgUrl;
    }

    public void setCoLicImgUrl(String coLicImgUrl) {
        this.coLicImgUrl = coLicImgUrl;
    }

    public String getTaxNo() {
        return taxNo;
    }

    public void setTaxNo(String taxNo) {
        this.taxNo = taxNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getLegalName() {
        return legalName;
    }

    public void setLegalName(String legalName) {
        this.legalName = legalName;
    }

    public boolean isCertificated() {
        return certificated;
    }

    public void setCertificated(boolean certificated) {
        this.certificated = certificated;
    }

    public Date getCertTime() {
        return certTime;
    }

    public void setCertTime(Date certTime) {
        this.certTime = certTime;
    }

    public CertWayEnum getCertWay() {
        return certWay;
    }

    public void setCertWay(CertWayEnum certWay) {
        this.certWay = certWay;
    }

    public String getCertLog() {
        return certLog;
    }

    public void setCertLog(String certLog) {
        this.certLog = certLog;
    }

    public MemberType getMemberType() {
        return memberType;
    }

    public void setMemberType(MemberType memberType) {
        this.memberType = memberType;
    }

    public Integer getErrorCount() {
        return errorCount;
    }

    public void setErrorCount(Integer errorCount) {
        this.errorCount = errorCount;
    }

    public String getFrendIds() {
        return frendIds;
    }

    public void setFrendIds(String frendIds) {
        this.frendIds = frendIds;
    }

    public BigDecimal getCreditAmount() {
        return creditAmount;
    }

    public void setCreditAmount(BigDecimal creditAmount) {
        this.creditAmount = creditAmount;
    }

    public String getPinYinName() {
        return pinYinName;
    }

    public void setPinYinName(String pinYinName) {
        this.pinYinName = pinYinName;
    }

    public Member() {
    }
}
