package com.fastsun.market;

public class MarketApi {
    /**
     * customerApi
     */
    public interface CustomerApi {
        /** 前缀 */
        public static final String PREFIX = "/app/customer";
        /**
         * get ?mktId&phone
         */

        public static final String findbyMobi = "/findbyMobi";
        /**
         * 登陆 post: body:{phone,password,mktId} return {customer,token}
         */
        public static final String login = "/login";
        /**
         * 忘记密码 post: body:customer
         */
        public static final String forgotPassword = "/forgot-password";

        /**
         * get ?mktId&customerId
         * 
         */
        public static final String customerDetail = "/detail";
        /**
         * 验证customer密码是否正确 post body:customer
         */
        public static final String authPassword = "/auth-password";
        /**
         * 修改手机 get ?newPone&authcode&mktId&customerId
         */
        public static final String modifyPhone = "/modify-phone";
        /**
         * post body:Customer, ?mktId
         */
        public static final String signup = "/signup";
        /**
         * 刷新用户设备id get: ?registrationId&customerId&mktId
         */
        public static final String updateRegistrationId = "/update-registrationId";

    }

    public interface MessageApi {
        public static final String PREFIX = "/app/customer/message";

        /**
         * get 该接口可以暂时不要
         */
        public static final String settingList = "/setting-list";
        /**
         * 设置自己的消息 post body:{newMsgSetting}
         */
        public static final String msgManage = "/manage";
        /**
         * get ?customerId&messageTypes
         */
        public static final String msgQuery = "/query";
        /**
         * get ?messageId&&customerId
         */
        public static final String msgChecked = "/checked";

    }

    // split
    public interface TeamApi {
        public static final String PREFIX = "/app/team";
        /**
         * 根据customerId列出team成员 get ?memberId
         */
        public static final String teamList = "/list";
        /**
         * POST body:InviteLog
         */
        public static final String inviteCustomer = "/invite-customer";
        /**
         * 接受加入团队邀请 GET ?inviteLogId&mktId&customerId
         */
        public static final String acceptInvite = "/accept-invite";
        /**
         * 拒绝加入团队邀请 GET ?mktId&inviteLogId&customerId
         */
        public static final String refuseInvite = "/refuse-invite";
        /**
         *
         * get ?mktId&customerId
         * 
         */
        public static final String invitelogList = "/invitelog-list";

        /**
         * 根据手机号查找用户 get 列出发出去的邀请,时间倒叙排序
         **/
        public static final String searchCustomerByPhone = "/search-customer-by-phone";

        /**
         * get ?mktId&customerId
         */
        public static final String findFreeCustomer = "/find-free-customer";
        /**
         * exitTeam ?customerId&&mktId
         */
        public static final String exitTeam = "/exit";
        /**
         * get ?customer&commentName&fromMemberId
         */
        public static String commmentCustomer = "/comment-customer";
        /**
         * get ?mktId&customerId 收到的邀请
         */
        public static String recvInvite = "/recv-invite";
        /**
         * 废弃邀请记录 get ?mktId&customerId&inviteLogId
         * 
         */
        public static String disabledInvite = "/disabled-invite";

    }

    // spilt
    public interface CommonApi {
        public static final String PREFIX = "/app/common";
        public static final String marketList = "/market-list";
        /**
         * get ?phone&authcode&verifyType&mktId
         */
        public static final String checkAuthcode = "/check-authcode";
        /**
         * get ?phone&verifyType&mktId
         */
        public static final String sendAuthcode = "/send-authcode";
    }

    // split
    public interface AnalysisApi {
        public static final String PREFIX = "/app/analysis";
        /**
         * get ?mktId&memberId
         */
        public static final String todayInfo = "/todayInfo";

    }

    // split

    public interface ProductOrderApi {
        public static final String PREFIX = "/app/order";

        /**
         * post body:order
         */
        public static final String orderCreate = "/create";
        /**
         * post body:TempOrder
         */
        public static final String orderUpload = "/upload";
        /**
         * get mktId&&tempOrderId
         */
        public static final String orderDowload = "/download";
        /**
         * mktId&memeberId
         */
        public static final String orderDowloadList = "/download/list";
        /**
         * 在线支付订单 get ?orderId&memberId&mktId
         */
        public static final String onlinePayOrder = "/online-pay-order";
        /**
         * get 推送订单给指定好友 ?orderId&memberId&fromMemberId
         */
        public static final String sendOrderToMember = "/send-order-to-member";
        /**
         * 订单作废 get ?orderId&memberId&mktId
         */
        public static final String orderDisabled = "/disabled";
        /**
         * 订单详情
         * 
         * ?orderId&mktId return {order}
         */
        public static final String orderDetail = "/detail";
        /**
         * get ?mktId&memberId
         */
        public static final String productList = "/list";
        /**
         * 列出所有市场分类指定parentId的分类 get ?mktId&parentId
         */
        public static final String productCatList = "/productCat/list";
        /**
         * 赊销申请 get ?orderId&fromMemberId&toMebmerId
         */
        public static final String debtRequest = "/debt-request";
        /**
         * 赊账同意 get ?orderId&memberId&mktId
         * 
         */
        public static final String debtAgree = "/debt-agree";
        /**
         * 拒绝赊账 ?orderId&memberId&mktId
         */
        public static final String debtRefuse = "/debt-refuse";
        /**
         * get 拉取申请赊账 ?memberId&mktId
         */
        public static final String memberDebtMoney = "/member-debt-money";
        /**
         * 创建产品 post body:Product
         */
        public static final String productCreate = "/product/create";
        /**
         * 更新产品 post body:Product
         */
        public static final String productUpdate = "/product/update";
        /**
         * 删除产品 get ?mktId&productId
         */
        public static final String productDel = "/product/del";
        /**
         * 交易区列表 get ?mktId
         */
        public static final String txnList = "/txn/list";
        /**
         * get ?mktId&memberId&status
         */
        public static final String productListByStatus = "/product/list-by-status";
        /**
         * get ?mktId&memberId&keyword
         */
        public static final String productListByKeyword = "/product/list-by-keyword";

    }

    // split
    public interface MemberAccountApi {
        public static final String PREFIX = "/app/member";
        /**
         * 提交会员实名认证信息 post body:MemberRealnameAuth
         */
        public static final String memberRealnameAuthCreate = "/memberRealnameAuth/create";

        /**
         * get ?customerId&mktId return {customer,status:}
         */
        public static final String memberDetail = "/memberDetail";
        /**
         * get ?memberId&mktId return {account}
         */
        public static final String accountDetail = "/accountDetail";
        /**
         * 拉取其他商户 get ?memberId&mktId return {members}
         * 
         */
        public static final String memberFriends = "/friends";
        /**
         * 转账 post body:AccoPayRec
         */
        public static final String transferAccount = "/transferAccount";
        /**
         * 获取收钱信息 1. 链接转为二维码形式等待对方扫
         * 
         * 2. 扫后返回对应的api返回收钱参数,如accountName,金额
         * 
         * get ?mktId&accountId&amt return {account,amt}
         */
        public static final String recvMoneyInfo = "/recive-money-info";
        /**
         * 此时用户扫了收钱二维码,将recvMoneyInfo返回的参数作为请求参数参数
         * 
         * post body:AccPayRecv
         * 
         * 与transferAccount重复,不适用
         */
        // public static final String payMoneyInfo = "/app/order/pay-money";
        /**
         * 拉取市场所有其他商户
         * 
         * get ?memberId&mktId
         * 
         */
        // public static final String mktOtherMember = "/app/member/mktOtherMember";

    }

}