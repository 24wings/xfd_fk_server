package com.fastsun.market.utils;



import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import aQute.lib.spring.JPAComponent;
import com.fastsun.framework.entity.rbac.Market;
import com.fastsun.framework.jpa.MarketJPA;
import com.fastsun.market.MarketApi;
import com.fastsun.market.entity.transOrder.Order;
import com.fastsun.market.entity.transOrder.OrderDetail;
import com.fastsun.market.entity.common.PrintDetail;
import com.fastsun.market.entity.enums.PriceUnit;
import com.fastsun.market.entity.enums.PriceWayEnum;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.jpa.CustomerJPA;
import com.fastsun.market.jpa.MemberJPA;
import com.fastsun.market.jpa.OrderJPA;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

@Service
public class FreeMarkerTest {
    private static final String TEMPLATE_PATH = "src/main/resources/templates";//模板路径【指向你自己的模板文件存放路径】
    @Autowired
    MarketJPA marketJPA;
    @Autowired
    MemberJPA memberJPA;
    @Autowired
    OrderJPA orderJPA;
    @Autowired
    CustomerJPA customerJPA;

    public String pay( String order) throws TemplateException {

        Order transInfo= orderJPA.findByOrderNo(order);
        Configuration configuration = new Configuration();
        try {
            configuration.setDirectoryForTemplateLoading(new File(TEMPLATE_PATH));
            Template template = configuration.getTemplate("rtupay.ftl");
            DecimalFormat df = new DecimalFormat("0.##");


            Map<String, Object> rtuinfo = new HashMap<String, Object>();
//            批发市场:${marketname!}
            Market market=  marketJPA.findById(transInfo.getMktId()).get();
            rtuinfo.put("marketname", market.getMktName());
//            商户名称:${merchname!}
            Member sellMember=  memberJPA.findById(transInfo.getSellerMemId()).get();
            rtuinfo.put("merchname", sellMember.getName());
//            客户:${custname!}
            if(transInfo.getBuyerMemId()!=null){
                Member buyMember=  memberJPA.findById(transInfo.getBuyerMemId()).get();
                rtuinfo.put("custname", buyMember.getName());
            }


//            商户编号:${merchcode!}
            rtuinfo.put("merchcode", sellMember.getNo());

//            操作员编号: ${operln!}
          Customer customer= customerJPA.findById(transInfo.getSellerCustId()).get();
            rtuinfo.put("operln",customer.getName());
//            订单编号: ${orderid!}
            rtuinfo.put("orderid", transInfo.getOrderNo());
//            交易类型:${trantype!}
//            rtuinfo.put("trantype", "RTU消费");
//            WX_C2B, // 微信主扫
            switch (transInfo.getPayType()){
                case WX_C2B:
                    rtuinfo.put("paytype", "WX_C2B");
                    break;
                case ALI_C2B:
                    rtuinfo.put("paytype", "ALI_C2B");
                    break;
                case ALI_B2C:
                    rtuinfo.put("paytype", "ALI_B2C");
                    break;
                case POS_PAY:
                    rtuinfo.put("paytype", "POS_PAY");
                    break;
                case FS_C2B:
                    rtuinfo.put("paytype", "FS_C2B");
                    break;
                case FS_B2C:
                    rtuinfo.put("paytype", "FS_B2C");
                    break;
                case FS_IC:
                    rtuinfo.put("paytype", "FS_IC");
                    break;
                case FS_CREDIT:
                    rtuinfo.put("paytype", "FS_CREDIT");
                    break;
                case SLIP:
                    rtuinfo.put("paytype", "SLIP");
                    break;

            }



//            交易时间:${trantime!}
            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
            String  Time1 = formatter.format(transInfo.getCreateTime());
            rtuinfo.put("trantime", Time1);
//            rtuinfo.put("trantime", "20170929");

            rtuinfo.put("merchtel",sellMember.getPhoneNo());

////            POS商户号:${pos_merchnum!"pos_merchnum"}
//            rtuinfo.put("pos_merchnum", transInfo.posMerchnum);
////            POS终端号:${pos_terminalnum!"pos_terminalnum"}
//            rtuinfo.put("pos_terminalnum", transInfo.posTerminalnum);
////            POS交易批次号:${pos_batchnum!"pos_batchnum"}
//            rtuinfo.put("pos_batchnum", transInfo.posBatchnum);
////            POS交易凭证号:${pos_voucherno!"pos_voucherno"}
//            rtuinfo.put("pos_voucherno", transInfo.posVoucherno);
////            POS交易日期:${pos_date!"pos_date"}
//            rtuinfo.put("pos_date", transInfo.posDate);
////            POS刷卡卡号:${pos_cardno!"pos_cardno"}
//            rtuinfo.put("pos_cardno", transInfo.posCardno);

//            rtuinfo.put("amount", df.format(transInfo.getApAmt()));
//            rtuinfo.put("recamount", df.format(transInfo.getPayAmt()));
            rtuinfo.put("amount", transInfo.getApAmt().toString());
            rtuinfo.put("recamount", transInfo.getPayAmt().toString());

                 List<OrderDetail> list_d = new ArrayList<>();
                    List<PrintDetail> list = new ArrayList<>();
            if (transInfo.getOrderDetails() != null) {
                list_d.addAll(transInfo.getOrderDetails());

                df.setRoundingMode(RoundingMode.HALF_UP);
                for (int i = 0; i < list_d.size(); i++) {
                    PrintDetail p = new PrintDetail();
//
//                    p.setGoodsamount(df.format(list_d.get(i).getAmount()));
//                    p.setgoodsprice(df.format(list_d.get(i).getPrice()));

                    p.setGoodsamount(list_d.get(i).getAmount().toString());
                    p.setgoodsprice(list_d.get(i).getPrice().toString());
                    p.setGoodsname(list_d.get(i).getProductName());
                    if (list_d.get(i).getPriceWay().equals(PriceWayEnum.WEIGHT)) {
                        if(list_d.get(i).getPriceUnit().equals(PriceUnit.JIN)){
                            p.setWeight(list_d.get(i).getWeight().toString() + "斤");
                        }else if(list_d.get(i).getPriceWay().equals(PriceUnit.KG)){
                            p.setWeight(list_d.get(i).getWeight().toString() + "公斤");
                        }

                    } else {
                        p.setWeight(list_d.get(i).getQty().toString() + "件");
                    }
                    list.add(p);
                }
            }

            rtuinfo.put("rtuprintmlist", list);
            StringWriter writer = new StringWriter();
            template.process(rtuinfo, writer);
            writer.close();
            System.out.println(writer.toString());
            return writer.toString();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

    }
//    public String paySmartpos(Reader reader, TransInfo transInfo) throws TemplateException {
//        try {
//            DecimalFormat df = new DecimalFormat("0.##");
//            Template temp = new Template(null, reader, null);
//            Map<String, Object> rtuinfo = new HashMap<String, Object>();
////            批发市场:${marketname!}
//            rtuinfo.put("marketname", MyApplication.MARKETNAME);
////            商户名称:${merchname!}
//            rtuinfo.put("merchname", MyApplication.MERCHNAME);
////            客户:${custname!}
//        rtuinfo.put("custname", transInfo.CustName);
////            商户编号:${merchcode!}
//            rtuinfo.put("merchcode", MyApplication.LoginResponse.merchcode);
////            终端编号:${rtucode!}
//            rtuinfo.put("rtucode", MyApplication.LoginResponse.rtucode);
////            操作员编号: ${operln!}
//            rtuinfo.put("operln", MyApplication.LoginResponse.opername);
////            订单编号: ${orderid!}
//            rtuinfo.put("orderid", transInfo.orderId);
////            交易类型:${trantype!}
//            rtuinfo.put("trantype", "智能Pos消费");
//            if (transInfo.payType == 4) {
//                rtuinfo.put("paytype", "04");
//
//            } else if (transInfo.payType == 2) {
//                rtuinfo.put("paytype", "02");
//            } else if (transInfo.payType == 3) {
//                rtuinfo.put("paytype", "03");
//            } else if (transInfo.payType == 5) {
//                rtuinfo.put("paytype", "05");
//            }
//            else if (transInfo.payType == 8) {
//                rtuinfo.put("paytype", "08");
//            }
//
////            交易时间:${trantime!}
//            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
//            String  Time1 = formatter.format(transInfo.tranTime);
//            rtuinfo.put("trantime", Time1);
////            rtuinfo.put("trantime", "20170929");
//            rtuinfo.put("merchtel", MyApplication.LoginResponse.opertel);
//
////            POS商户号:${pos_merchnum!"pos_merchnum"}
//            rtuinfo.put("pos_merchnum", transInfo.posMerchnum);
////            POS终端号:${pos_terminalnum!"pos_terminalnum"}
//            rtuinfo.put("pos_terminalnum", transInfo.posTerminalnum);
////            POS交易批次号:${pos_batchnum!"pos_batchnum"}
//            rtuinfo.put("pos_batchnum", transInfo.posBatchnum);
////            POS交易凭证号:${pos_voucherno!"pos_voucherno"}
//            rtuinfo.put("pos_voucherno", transInfo.posVoucherno);
////            POS交易日期:${pos_date!"pos_date"}
//            rtuinfo.put("pos_date", transInfo.posDate);
////            POS刷卡卡号:${pos_cardno!"pos_cardno"}
//            rtuinfo.put("pos_cardno", transInfo.posCardno);
//
//            rtuinfo.put("amount", df.format(transInfo.amount / 100));
//            rtuinfo.put("recamount", df.format(transInfo.recamount / 100));
//
//            List<TransDetail> list_d = new ArrayList<TransDetail>();
//            List<RtuPrintM> list = new ArrayList<RtuPrintM>();
//            if (transInfo.transDetails != null) {
//                list_d.addAll(transInfo.transDetails);
//
//                df.setRoundingMode(RoundingMode.HALF_UP);
//                for (int i = 0; i < list_d.size(); i++) {
//                    RtuPrintM m = new RtuPrintM();
//                    m.setGoodsamount(df.format(list_d.get(i).getAmount() / 100));
//                    m.setgoodsprice(df.format(list_d.get(i).goodsPrice / 100));
//                    m.setGoodsname(list_d.get(i).goodsName);
//                    if (list_d.get(i).pricingMode == 1) {
//                        if(MyApplication.WEIGHT_UTIL.equals("斤")){
//                            m.setWeight(list_d.get(i).weight + "斤");
//                        }else {
//                            m.setWeight(list_d.get(i).weight + "公斤");
//                        }
//
//                    } else {
//                        m.setWeight(list_d.get(i).goodsCount + "件");
//                    }
//                    list.add(m);
//                }
//            }
//
//            rtuinfo.put("rtuprintmlist", list);
//            StringWriter writer = new StringWriter();
//            temp.process(rtuinfo, writer);
//            writer.close();
//            System.out.println(writer.toString());
//            return writer.toString();
//        } catch (IOException e) {
//            e.printStackTrace();
//            return null;
//        }
//
//    }
//    public String outMarket(Reader reader, OutMarketInfo outMarket) throws TemplateException {
//        try {
//            Template temp = new Template(null, reader, null);
//            Map<String, Object> rtuinfo = new HashMap<String, Object>();
////            批发市场:${marketname!}
//            rtuinfo.put("marketname", MyApplication.MARKETNAME);
////            商户名称:${merchname!}
//            rtuinfo.put("merchname", MyApplication.MERCHNAME);
////            客户:${custname!}
////            商户编号:${merchcode!}
//            rtuinfo.put("merchcode", MyApplication.LoginResponse.merchcode);
////            终端编号:${rtucode!}
//            rtuinfo.put("rtucode", MyApplication.LoginResponse.rtucode);
////            操作员编号: ${operln!}
//            rtuinfo.put("operln", MyApplication.LoginResponse.opername);
////            订单编号: ${orderid!}
//            rtuinfo.put("orderid", outMarket.outno);
////            交易类型:${trantype!}
//
//            rtuinfo.put("time", outMarket.createdate);
//            if(MyApplication.WEIGHT_UTIL.equals("斤")){
//                rtuinfo.put("weight", outMarket.outweight+"斤");
//            }else {
//                rtuinfo.put("weight", outMarket.outweight+"公斤");
//            }
//
//            StringWriter writer = new StringWriter();
//            temp.process(rtuinfo, writer);
//            writer.close();
//            System.out.println(writer.toString());
//            return writer.toString();
//        } catch (IOException e) {
//            e.printStackTrace();
//            return null;
//        }
//
//    }
//    public String PayForPork(Reader reader, TransInfo transInfo) throws TemplateException {
//        try {
//            DecimalFormat df = new DecimalFormat("0.##");
//            Template temp = new Template(null, reader, null);
//            Map<String, Object> rtuinfo = new HashMap<String, Object>();
////            批发市场:${marketname!}
//            rtuinfo.put("marketname", MyApplication.MARKETNAME);
////            商户名称:${merchname!}
//            rtuinfo.put("merchname", MyApplication.MERCHNAME);
////            客户:${custname!}
//            rtuinfo.put("custname", transInfo.CustName);
////            商户编号:${merchcode!}
//            rtuinfo.put("merchcode", MyApplication.LoginResponse.merchcode);
////            终端编号:${rtucode!}
//            rtuinfo.put("rtucode", MyApplication.LoginResponse.rtucode);
////            操作员编号: ${operln!}
//            rtuinfo.put("operln", MyApplication.LoginResponse.opername);
////            订单编号: ${orderid!}
//            rtuinfo.put("orderid", transInfo.orderId);
////            交易类型:${trantype!}
//            rtuinfo.put("trantype", "RTU消费");
//            if (transInfo.payType == 4) {
//                rtuinfo.put("paytype", "04");
//
//            } else if (transInfo.payType == 2) {
//                rtuinfo.put("paytype", "02");
//            } else if (transInfo.payType == 3) {
//                rtuinfo.put("paytype", "03");
//            } else if (transInfo.payType == 5) {
//                rtuinfo.put("paytype", "05");
//            }
//            else if (transInfo.payType == 8) {
//                rtuinfo.put("paytype", "08");
//            }
//
//
////            交易时间:${trantime!}
//            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
//            String  Time1 = formatter.format(transInfo.tranTime);
//            rtuinfo.put("trantime", Time1);
////            rtuinfo.put("trantime", "20170929");
//            rtuinfo.put("merchtel", MyApplication.LoginResponse.opertel);
//
////            POS商户号:${pos_merchnum!"pos_merchnum"}
//            rtuinfo.put("pos_merchnum", transInfo.posMerchnum);
////            POS终端号:${pos_terminalnum!"pos_terminalnum"}
//            rtuinfo.put("pos_terminalnum", transInfo.posTerminalnum);
////            POS交易批次号:${pos_batchnum!"pos_batchnum"}
//            rtuinfo.put("pos_batchnum", transInfo.posBatchnum);
////            POS交易凭证号:${pos_voucherno!"pos_voucherno"}
//            rtuinfo.put("pos_voucherno", transInfo.posVoucherno);
////            POS交易日期:${pos_date!"pos_date"}
//            rtuinfo.put("pos_date", transInfo.posDate);
////            POS刷卡卡号:${pos_cardno!"pos_cardno"}
//            rtuinfo.put("pos_cardno", transInfo.posCardno);
//
//            rtuinfo.put("amount", df.format(transInfo.amount / 100));
//            rtuinfo.put("recamount", df.format(transInfo.recamount / 100));
//
//            List<TransDetail> list_d = new ArrayList<TransDetail>();
//            List<RtuPrintM> list = new ArrayList<RtuPrintM>();
//            if (transInfo.transDetails != null) {
//                list_d.addAll(transInfo.transDetails);
//
//                df.setRoundingMode(RoundingMode.HALF_UP);
//                for (int i = 0; i < list_d.size(); i++) {
//                    RtuPrintM m = new RtuPrintM();
//                    m.setGoodsamount(df.format(list_d.get(i).getAmount() / 100));
//                    m.setgoodsprice(df.format(list_d.get(i).goodsPrice / 100));
//                    m.setGoodsname(list_d.get(i).sequm);
//                    m.setWeight(list_d.get(i).weight + "公斤");
//                    list.add(m);
//                }
//            }
//
//            rtuinfo.put("rtuprintmlist", list);
//            StringWriter writer = new StringWriter();
//            temp.process(rtuinfo, writer);
//            writer.close();
//            System.out.println(writer.toString());
//            return writer.toString();
//        } catch (IOException e) {
//            e.printStackTrace();
//            return null;
//        }
//
//    }

}

