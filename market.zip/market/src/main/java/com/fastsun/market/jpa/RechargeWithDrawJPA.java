package com.fastsun.market.jpa;

import com.fastsun.market.entity.member.RechargeWithDraw;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface RechargeWithDrawJPA extends BaseRepository<RechargeWithDraw,Integer>,JpaSpecificationExecutor<RechargeWithDraw> {
}
