package com.fastsun.market.jpa;

import com.fastsun.market.entity.common.OrderNo;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface OrderNoJPA extends BaseRepository<OrderNo,Integer>,JpaSpecificationExecutor<OrderNo> {
    OrderNo findByCurrentKey(String currentKey);
}
