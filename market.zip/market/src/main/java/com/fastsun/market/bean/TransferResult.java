package com.fastsun.market.bean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fastsun.market.entity.account.AccRecvPay;

/**
 * 转账结果
 * 
 */
public class TransferResult {
    public Boolean isSuccess;
    public List<AccRecvPay> accRecvPays = new ArrayList<AccRecvPay>();
    public Date createTime = new Date();
    public BigDecimal amt;
    /**
     * 当失败时返回错误原因
     */
    public String errorMsg;
}