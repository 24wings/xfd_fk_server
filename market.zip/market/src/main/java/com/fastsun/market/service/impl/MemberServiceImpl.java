package com.fastsun.market.service.impl;

import com.alibaba.fastjson.JSON;
import com.fastsun.framework.bean.*;
import com.fastsun.framework.entity.rbac.Market;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.framework.jpa.MarketJPA;
import com.fastsun.framework.jpa.UserJPA;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.service.impl.OrderNoServiceImpl;
import com.fastsun.framework.utils.ChangeToPinYin;
import com.fastsun.framework.utils.JsonDateValueProcessorUtil;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.framework.utils.CustomeStringUtils;
import com.fastsun.market.bean.TransferResult;
import com.fastsun.market.entity.account.AccRecvPay;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.entity.account.AccountDebt;
import com.fastsun.market.entity.common.AppMsgNotify;
import com.fastsun.market.entity.enums.*;
import com.fastsun.market.entity.member.*;
import com.fastsun.market.entity.transOrder.Order;
import com.fastsun.market.jpa.*;
import com.fastsun.market.service.impl.common.MsgServiceImpl;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class MemberServiceImpl{
    @Value("${accountNoCreateKey}")
    String accountNoCreateKey;
    @Value("${memberNoCreateKey}")
    String memberNoCreateKey;
      @Autowired
      private RequestUtil requestUtil;
      @Autowired
    UserJPA userJPA;
      @Autowired
    MarketJPA marketJPA;
      @Autowired
      private MemberJPA memberJPA;
      @Autowired
      private AccountJPA accountJPA;
@Autowired
    private MemberAccountJPA memberAccountJPA;

    @Autowired
    private CustCardJPA custCardJPA;
    @Autowired
    private CustomerJPA customerJPA;

@Autowired
private OrderNoServiceImpl orderNoServiceImpl;

      @Autowired
      private CustomerServiceImpl customerServiceImpl;

      @Autowired
      private PasswordEncoder encoder;

      @Autowired
    private CommonEntityService commonEntityService;

    @Autowired
    ContactInviteJPA contactInviteJPA;

    @Autowired
    AccRecvPayJPA accRecvPayJPA;

    @Autowired
    AppMsgNotifyJPA appMsgNotifyJPA;

    @Autowired
    OrderJPA orderJPA;

    @Autowired
    OrderServiceImpl orderService;

    @Autowired
    private MsgServiceImpl msgService;

    @Autowired
    private JPushServiceImpl jPushServiceImpl;

      /*
       * 柜台新建个人member时，直接通过身份证原件实名认证
       *  先查询是否在App端已注册，未注册则开通app
       *  同时，为此member开通账户(建立member和memberaccount之间的关联)
       */
      @Transactional
      public Member saveMember(Member member,HttpServletRequest request){
          requestUtil.setCreatorAndCreatorId(member,requestUtil.getLoginUser(request));
          member.setCreateTime(new Date(System.currentTimeMillis()));
          if(member.getCreateWay() == null){
              member.setCreateWay(CreateWay.WEB);
          }
          member.setNo("M"+String.format("%06d",this.orderNoServiceImpl.getOrderNo(this.memberNoCreateKey)));
          member.setMemberType(MemberType.PERSONAL);
          member.setPayPassword(encoder.encode(member.getPayPassword()));
          member.setPwdEncrypted(true);
          member.setStatus(CommonStatusEnum.ENABLE);
          //实名部分
          if(CreateWay.WEB.equals(member.getCreateWay())){
              member.setCertificated(true);
              member.setCertWay(CertWayEnum.WEB_PASS_NOAUTH);
              member.setCertTime(new Date(System.currentTimeMillis()));
              member.setCertLog(CertWayEnum.getLogString(CertWayEnum.WEB_PASS_NOAUTH,member));
          }else if(CreateWay.APP.equals(member.getCreateWay())){

          }
          Member memberDB = this.memberJPA.save(member);
          //新建Account,MemberAccount
          Account account = this.accountJPA.save(createAccount(null,null,member));
          MemberAccount memberAccount = new MemberAccount();
          memberAccount.setRelationId(memberDB.getId());
          memberAccount.setAccountNo(account.getNo());
          memberAccount.setAccountType(AccountType.MEMBER_CASH);
          this.memberAccountJPA.save(memberAccount);

          Customer customerDB = this.customerServiceImpl.findByMobi(member.getMktId(),member.getMobi());
          Customer customer = null;
          if(customerDB == null){
              customer = this.customerServiceImpl.saveCustomer(memberDB);
              List<Customer> customers = memberDB.getCustomers();
              if(customers == null){
                  customers = new ArrayList<>();
              }else {
                  memberDB.getCustomers().clear();
              }
              customers.add(customer);
              memberDB.setCustomerId(customer.getId());
              memberDB.setCustomers(customers);
              this.commonEntityService.update(memberDB);
          }else{
              if(customerDB.getMemberId() == null){
                  customerDB.setMemberId(member.getId());
                  customerDB.setMember(memberDB);
                  this.customerServiceImpl.update(customerDB);
              }
          }
          return memberDB;
      }

      public Account createAccount(Market market,User user,Member member){
          Account account = new Account();
          if(user != null){
              account.setMktId(user.getMktId());
              account.setName(user.getName());
              account.setAccountType(AccountType.USER_CASH);
          }else if(member != null){
              account.setMktId(member.getMktId());
              account.setName(member.getName());
              account.setAccountType(AccountType.MEMBER_CASH);
          }else if(market != null){
              account.setMktId(market.getMktId());
              account.setName(market.getMktName());
              account.setAccountType(AccountType.MARKET_FEE);
          }
          account.setNo("A"+String.format("%06d",this.orderNoServiceImpl.getOrderNo(this.accountNoCreateKey)));
          account.setCreateTime(new Date());
          account.setStatus(AccountStatus.ENABLE);
          account.setAvailAmt(new BigDecimal(0));
          account.setBalAmt(new BigDecimal(0));
          account.setFrozenAmt(new BigDecimal(0));
          return account;
      }

      public Paging<Member> findAll(QueryParameter queryParameter) {

          return this.commonEntityService.findPagedEntity(queryParameter,Member.class);

      }

      public Paging<Member> search(QueryParameter queryParameter){
          queryParameter.setQueryConditions(queryParameter.getQueryConditions().stream().filter(queryCondition -> queryCondition.getValue() != null).collect(Collectors.toList()));
          return this.commonEntityService.findPagedEntity(queryParameter,Member.class);
      }

      public Member findMemberByCardNo(String cardNo)throws Exception{
          CustCard card = this.custCardJPA.findByNo(cardNo);
          if (!CommonStatusEnum.ENABLE.equals(card.getStatus())) {
              throw new Exception("卡状态异常!");
          }
          Customer customer = this.customerJPA.findByCardId(card.getId());
          if (!CommonStatusEnum.ENABLE.equals(customer.getStatus())) {
              throw new Exception("卡关联用户状态异常!");
          }
          return this.memberJPA.findById(customer.getMemberId()).get();
      }

      public MemberAccTuple<Member,Account> findByAccountDept(AccountDebt accountDebt){
          Account account = this.accountJPA.findById(accountDebt.getDebtorAccId()).get();
          Customer customer = this.orderService.getMemberOfCustomer(accountDebt.getOrderNo(),1);
          return new MemberAccTuple(customer.getMember(),account);
      }

      public MemberAccTuple<Member,Account> findByCardNo(String cardNo)throws Exception{
          Member member = findMemberByCardNo(cardNo);
          MemberAccount memberAccount = this.memberAccountJPA.findByRelationIdAndAccountType(member.getId(),AccountType.MEMBER_CASH);
          Account account = null;
          if(memberAccount == null){
              account = createMemberAccount(member);
          }else {
              account = this.accountJPA.findByAccountTypeAndNo(memberAccount.getAccountType(),memberAccount.getAccountNo());
          }
          return new MemberAccTuple(member,account);
      }

      public MemberAccTuple<Member,Account> findByMemNo(String memberNo,Integer memberId) throws Exception {
          Member member = null;
          if(memberId != null){
              member = (Member) this.commonEntityService.findById(Member.class,memberId);
          }else if(memberNo != null){
              member = this.memberJPA.findByNo(memberNo);
          }
          if(member == null) throw new Exception("卖家信息不存在！");
          MemberAccount memberAccount = this.memberAccountJPA.findByRelationIdAndAccountType(member.getId(),AccountType.MEMBER_CASH);
          Account account = null;
          if(memberAccount == null){
              account = createMemberAccount(member);
          }else {
              account = this.accountJPA.findByAccountTypeAndNo(memberAccount.getAccountType(),memberAccount.getAccountNo());
          }
          return new MemberAccTuple(member,account);
      }

      public UserAccTuple<User,Account> findByUserId(Integer userId){
          User user = this.userJPA.findById(userId).get();
          MemberAccount memberAccount = this.memberAccountJPA.findByRelationIdAndAccountType(userId,AccountType.USER_CASH);
          Account account = null;
          if(memberAccount == null){//如果未在关联表中找到员工的现金账户
              account = createAccount(null,user,null);
              account = this.accountJPA.save(account);
              memberAccount = new MemberAccount();
              memberAccount.setRelationId(userId);
              memberAccount.setAccountNo(account.getNo());
              memberAccount.setAccountType(AccountType.USER_CASH);
              this.memberAccountJPA.save(memberAccount);
          }else{
              account = this.accountJPA.findByAccountTypeAndNo(AccountType.USER_CASH,memberAccount.getAccountNo());
          }
          return new UserAccTuple<>(user,account);
      }

    public MarketAccTuple<Market,Account> findByMarketId(Integer mktId){
        Market market = this.marketJPA.findById(mktId).get();
        MemberAccount memberAccount = this.memberAccountJPA.findByRelationIdAndAccountType(mktId,AccountType.MARKET_FEE);
        Account account = null;
        if(memberAccount == null){//如果未在关联表中找到员工的现金账户
            account = createAccount(market,null,null);
            account = this.accountJPA.save(account);
            memberAccount = new MemberAccount();
            memberAccount.setRelationId(mktId);
            memberAccount.setAccountNo(account.getNo());
            memberAccount.setAccountType(AccountType.MARKET_FEE);
            this.memberAccountJPA.save(memberAccount);
        }else{
            account = this.accountJPA.findByAccountTypeAndNo(AccountType.MARKET_FEE,memberAccount.getAccountNo());
        }
        return  new MarketAccTuple<>(market,account);
    }

    public Member modifyPayPassword(String newPassword, Integer memberId){
          Member member = (Member) this.commonEntityService.findById(Member.class,memberId);
          member.setPayPassword(encoder.encode(newPassword));
          member.setPwdEncrypted(true);
          return (Member) this.commonEntityService.update(member);
    }

    public Boolean confirePayPassword(Integer memberId ,String payPassword) throws Exception{
          Boolean flag = false;
          Member  member = this.memberJPA.findById(memberId).get();
          Integer count = member.getErrorCount();
          if(count == null) {
              count = 0;
          }
          if(count >= 10) {
              throw new Exception("错误次数超过10次，必须解锁!");
          }
          if(encoder.matches(payPassword,member.getPayPassword())){
              flag = true;
              return flag;
          }else {
              count++;
              member.setErrorCount(count);
              this.memberJPA.save(member);
              return flag;
          }

    }
    public Account createMemberAccount(Member member){
        Account account = createAccount(null,null,member);
        account = this.accountJPA.save(account);
        MemberAccount memberAccount = new MemberAccount();
        memberAccount.setRelationId(member.getId());
        memberAccount.setAccountNo(account.getNo());
        memberAccount.setAccountType(AccountType.MEMBER_CASH);
        this.memberAccountJPA.save(memberAccount);
        return account;
    }

	public boolean cleanPayPassword(Integer memberId)
    {
        if(this.memberJPA.findById(memberId).isPresent())
        {
            Member member = this.memberJPA.findById(memberId).get();
            member.setErrorCount(0);
            this.memberJPA.save(member);
            return true;
        }
        return false;

    }

    public List<Member> searchMember(String keyWord) {
        List<Member> memberList = new ArrayList<Member>();
        List<Customer> customer = this.customerJPA.findByNameContaining(keyWord);
        if(customer.size() == 0)
        {
            customer = this.customerJPA.findByMobiContaining(keyWord);
        }
        List<Integer> memberIdList = new ArrayList<Integer>();
        for(Customer item : customer)
        {
            Integer memberId = item.getMemberId();
//            if(memberId != null)
//            {
//                if(this.memberJPA.findById(memberId).isPresent()){
//                    Member member = this.memberJPA.findById(memberId).get();
//                    memberList.add(member);
//                }
//            }
            memberIdList.add(memberId);
        }
        List<Integer> tempMemberIdList= new ArrayList<Integer>();
        for(Integer i:memberIdList){
            if(!tempMemberIdList.contains(i)){
                tempMemberIdList.add(i);
            }
        }
        Integer[] menberIds = new Integer[tempMemberIdList.size()];
        for (int i = 0; i < tempMemberIdList.size() ; i++) {
            menberIds[i] = tempMemberIdList.get(i);
        }
        memberList= this.memberJPA.findByIdIn(menberIds);
        return memberList;
    }

    public ContactInvite friendInvi(Integer memberId, Integer friendId, String content) throws Exception
    {
        if(this.memberJPA.findById(memberId).isPresent() &&
                this.memberJPA.findById(friendId).isPresent())
        {
            Member member = this.memberJPA.findById(memberId).get();
            Member friendMember = this.memberJPA.findById(friendId).get();
            ContactInvite friendContactInvite = this.contactInviteJPA.findByMemberIdAndFriendinvitemIdAndStatus(memberId,friendId,MemberInviteStatusEnum.Agree);
            if(member != null && friendMember != null && friendContactInvite == null)
            {
                ContactInvite contactInvite = new ContactInvite();
                contactInvite.setMemberId(memberId);
                contactInvite.setFriendinvitemId(friendId);
                contactInvite.setContent(content);
                contactInvite.setMktId(member.getMktId());
                contactInvite.setMemberName(member.getName());
                contactInvite.setFriendinvitemName(friendMember.getName());
                this.contactInviteJPA.saveAndFlush(contactInvite);

                if(!msgService.checkDisabledMsgTypes(friendMember.getCustomerId(),MsgType.MEM_INVITE)) {
                    String msgContent = "尊敬的用户,"+member.getName()+"邀请你加为好友，点击查看！";
                    AppMsgNotify appMsgNotify = this.createAppMsgNotify(friendMember, contactInvite, null, "收到邀请，加为好友！",
                            MsgType.MEM_INVITE,msgContent);
                    Map<String, String> extral = new HashMap<>();
                    Customer customer = this.customerJPA.findById(friendMember.getCustomerId()).get();
                    extral.put("contactInviteId", String.valueOf(contactInvite.getId()));
                    extral.put("appMsgNotifyId",appMsgNotify.getId().toString());
                    this.jPushServiceImpl.sendRegistrationIdNotify(msgContent, customer.getRegistrationId(), extral);

                }
                return contactInvite;
            }
            return null;
        }
        return null;

    }

    public boolean inviprocess(ContactInvite contactInvite) throws Exception
    {
        int memberId = contactInvite.getMemberId();
        int friendId = contactInvite.getFriendinvitemId();
        Member member = this.memberJPA.findById(memberId).get();
        Member friendMember = this.memberJPA.findById(friendId).get();
        if(member != null && friendMember != null)
        {
            if(member.getFrendIds()!= null && !member.getFrendIds().equals(""))
            {
                String[] friendIds = member.getFrendIds().split(",");
                List<String> friendIdsList = Arrays.asList(friendIds);
                for(int i = 0; friendIds.length > i; i++)
                {
                    if (friendIds[i].length() == 0)
                    {
                        continue;
                    }
                    if(!friendIds[i].equals(Integer.toString(friendId)))
                    {
                        contactInvite.setConfirmTime(new Date());
                        contactInviteJPA.save(contactInvite);
                        boolean flag = savMember(contactInvite,friendIdsList,member,friendMember,friendId);
                        return flag;
                    }
                }
            }
            List<String> friendIds = new ArrayList<String>();
            contactInvite.setConfirmTime(new Date());
            contactInviteJPA.save(contactInvite);
            boolean f = savMember(contactInvite,friendIds,member,friendMember,friendId);
            return f;
        }
        return false;

    }
    public List<ContactInvite> memberInviList(Integer memberId, String type)
    {
        List<ContactInvite> contactInvite = new ArrayList<ContactInvite>();
        if(type.equals("send")){
            contactInvite = this.contactInviteJPA.findByMemberId(memberId);
            return contactInvite;
        }
        contactInvite = this.contactInviteJPA.findByFriendinvitemId(memberId);
        return contactInvite;
    }

    public List<Member> friends(Integer memberId)
    {
        List<Member> members = null;
        Optional<List<Member>> memberList = null;
        Member currentMember = this.memberJPA.findById(memberId).get();
        if(currentMember.getFrendIds() != "" && currentMember.getFrendIds() != null) {
            String[] friendIds = currentMember.getFrendIds().split(",");
            Integer[] newFriendIds = new Integer[friendIds.length];
            for (int i = 0; i <friendIds.length ; i++) {
                newFriendIds[i]=Integer.valueOf(friendIds[i]);
            }
            memberList = Optional.of(this.memberJPA.findByIdIn(newFriendIds));
        }
        members = memberList.get().stream().peek(member -> member.setPinYinName(ChangeToPinYin.getPinYin(member.getName())))
                .sorted(Comparator.comparing(Member::getPinYinName)).collect(Collectors.toList());
        members.forEach(member -> {
            try {
                member.setCreditAmount(this.orderService.qryBuyerCredit(member.getId(),member.getMktId()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        return members;
    }

    public boolean savMember(ContactInvite contactInvite, List<String> friendIdsList,
             Member member,Member friendMember, Integer friendId ) throws Exception
    {
        if(contactInvite.getStatus().equals(MemberInviteStatusEnum.Agree)) {
            List<String> listIds = new ArrayList<String>(friendIdsList);
            listIds.add(Integer.toString(friendId));
            String friendsId = CustomeStringUtils.listToString(listIds);
            member.setFrendIds(friendsId);
            if(friendMember.getFrendIds()!= null && !friendMember.getFrendIds().equals("")
                    && !friendMember.getFrendIds().isEmpty())
            {
                String[] friendIds = friendMember.getFrendIds().split(",");
                List<String> friendIdLists = Arrays.asList(friendIds);
                String memberId =Integer.toString(member.getId());
                List<String> list = new ArrayList<String>(friendIdLists);
                list.add(memberId);
                String fmfId = CustomeStringUtils.listToString(list);
                friendMember.setFrendIds(fmfId);
            }
            else
            {
                friendMember.setFrendIds(String.valueOf(member.getId()));
            }
            this.memberJPA.save(member);
            this.memberJPA.save(friendMember);
            if(!msgService.checkDisabledMsgTypes(friendMember.getCustomerId(),MsgType.MEM_INVITE)) {
                String content = "" + contactInvite.getFriendinvitemId() + "已同意您的好友邀请!";
                AppMsgNotify appMsgNotify = this.createAppMsgNotify(member, contactInvite,
                        null, null, MsgType.MEM_INVITE, content);
                Customer customer = this.customerJPA.findById(member.getCustomerId()).get();
                String registrationId = customer.getRegistrationId();
                Map<String, String> extral = new HashMap<String, String>();
                extral.put("appMsgNotifyId", appMsgNotify.getId().toString());
                this.jPushServiceImpl.sendRegistrationIdNotify(content,registrationId,extral);
            }
        } else {
            if(!msgService.checkDisabledMsgTypes(friendMember.getCustomerId(),MsgType.MEM_INVITE)) {
                String content = "" + contactInvite.getFriendinvitemId() + "拒绝了您的好友邀请!";
                AppMsgNotify appMsgNotify = this.createAppMsgNotify(member, contactInvite,
                        null, null, MsgType.MEM_INVITE, content);
                Customer customer = this.customerJPA.findById(member.getCustomerId()).get();
                String registrationId = customer.getRegistrationId();
                Map<String, String> extral = new HashMap<String, String>();
                extral.put("appMsgNotifyId", appMsgNotify.getId().toString());
                this.jPushServiceImpl.sendRegistrationIdNotify(content,registrationId,extral);
            }
            return false;
        }

        return true;
    }

//    public List<Object> recvpayListBymemberId(Integer memberId)
//    {
//        List<MemberAccount> memberAccount = this.memberAccountJPA.findByRelationId(memberId);
//        List<Object> objectList = new ArrayList<>();
//        for (MemberAccount items:memberAccount)
//        {
//            Account account = this.accountJPA.findByNo(items.getAccountNo());
//            List<AccRecvPay> accRecvPayList = this.accRecvPayJPA.findByAccountId(account.getId());
//            JsonConfig jsonConfig = new JsonConfig();
//            jsonConfig.registerJsonValueProcessor(Date.class , new JsonDateValueProcessorUtil());
//            for (AccRecvPay item:accRecvPayList)
//            {
//                String phone = null;
//                Integer accountId = item.getToAccountId();
//                Account toaccount = this.accountJPA.findById(accountId).get();
//                String accountNo = toaccount.getNo();
//                List<MemberAccount> memberToAccount = this.memberAccountJPA.findByAccountNo(toaccount.getNo());
//                for (MemberAccount memberaccount:memberToAccount)
//                {
//                    Integer relationId = memberaccount.getRelationId();
//                    List<Customer> customer = this.customerJPA.findByMemberId(relationId);
//                    for (Customer cust:customer)
//                    {
//                        phone = cust.getMobi();
//                    }
//                    JSONObject json = JSONObject.fromObject(item,jsonConfig);
//                    json.put("phone",phone);
//                    json.put("no",accountNo);
//                    objectList.add(json);
//                }
//            }
//            return objectList;
//
//        }
//        return null;
//    }
    public Paging getRecvPayList(Integer memberId,QueryParameter queryParameter) throws Exception {
          MemberAccTuple<Member,Account> memberAccTuple = this.findByMemNo(null,memberId);
          List<QueryCondition> queryConditions = null;
          if(queryParameter.getQueryConditions() == null){
              queryConditions = new ArrayList<>();
          }else {
              queryConditions = queryParameter.getQueryConditions();
          }
         queryConditions.add(new QueryCondition("accountId","=",memberAccTuple.second.getId(),"and"));
         queryParameter.setQueryConditions(queryConditions);
         return this.commonEntityService.findPagedEntity(queryParameter,AccRecvPay.class);
    }

    public AppMsgNotify createAppMsgNotify(Member member,ContactInvite contactInvite,
                           MemberInvite memberInvite,String title,MsgType msgType,String content)
    {
        AppMsgNotify appMsgNotify = new AppMsgNotify();
        appMsgNotify.setCreateTime(new Date());
        appMsgNotify.setTitle(title);
        appMsgNotify.setMsgType(msgType);
        if(member != null && contactInvite != null)
        {
            appMsgNotify.setCreatorId(member.getCreatorId());
            appMsgNotify.setMktId(member.getMktId());
            appMsgNotify.setCustId(member.getCustomerId());
            appMsgNotify.setMemberId(member.getId());
            appMsgNotify.setContent(content);

        }
        else
        {
            appMsgNotify.setCustId(memberInvite.getRecvCustId());
            appMsgNotify.setMktId(memberInvite.getMktId());
            appMsgNotify.setContent(content);
        }

        if((contactInvite == null?memberInvite.getStatus():contactInvite.getStatus()).equals(MemberInviteStatusEnum.Active))
        {
            appMsgNotify.setIsRead(false);

        }
        else
        {
            appMsgNotify.setIsRead(true);

        }
        if((contactInvite == null?memberInvite.getStatus():contactInvite.getStatus()).equals(MemberInviteStatusEnum.Agree))
        {
            if(title == null) {
                appMsgNotify.setTitle("对方已经同意了您的邀请！");
            }
        }
        else
        {
            if(title == null) {
                appMsgNotify.setTitle("对方已经拒绝了您的邀请！");
            }
        }
//        JsonConfig jsonConfig = new JsonConfig();
//        jsonConfig.registerJsonValueProcessor(Date.class , new JsonDateValueProcessorUtil());
//        JSONObject json = JSONObject.fromObject(contactInvite == null?memberInvite:contactInvite,jsonConfig);
//        String addition= json.toString();
        appMsgNotify.setAddition(JSON.toJSONString(contactInvite == null?memberInvite:contactInvite));
        this.appMsgNotifyJPA.save(appMsgNotify);
        return appMsgNotify;

    }


    public Member changeMemberStatus(Integer memberId,CommonStatusEnum status){
        Member member = (Member) this.commonEntityService.findById(Member.class,memberId);
        member.setStatus(status);
        return  (Member) this.commonEntityService.update(member);
    }
}
