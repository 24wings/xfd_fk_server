package com.fastsun.market.controller.web;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.market.bean.XFvoicerespBean;
import com.fastsun.market.entity.transOrder.OrderDetail;
import com.fastsun.market.jpa.ProdCatalogJPA;
import com.fastsun.market.jpa.ProductJPA;
import com.fastsun.market.service.impl.VoiceRecognitionServiceImpl;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@Api(description = "语音听写", tags = { "market.web.Voice" })
@RestController
@RequestMapping("/api/voice")
public class VoiceController extends BaseController {
    private ResponseBean responseBean = null;
    @Autowired
    ProductJPA productJPA;
    @Autowired
    ProdCatalogJPA prodCatalogJPA;
    @Autowired
    VoiceRecognitionServiceImpl voiceRecognitionService;
    private static final String AUDIO_PATH = "d:/test_1.pcm";
    //---
    @ApiOperation(value = "语音听写", notes = "语音听写", httpMethod = "GET")
    @GetMapping(value = "/transVoice")
    public ResponseBean transVoice(@RequestParam Integer memberId,
                              @RequestParam(value = "mktId",defaultValue = "1") Integer mktId,
                              @RequestParam(value = "aueType",defaultValue = "raw") String aueType,
                              @RequestParam String voicebase64) {

        XFvoicerespBean bean = this.voiceRecognitionService.dovoice(voicebase64);
        String result = bean.getData();
        String code = bean.getCode();

        System.out.println(result);
        //result = "西红柿2,十五点七元，二十斤";
        if(StringUtils.isEmpty(result)||!result.contains("元")){
            responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.VOICE_FALSE.getStatus(),
                    StatusMsgEnum.VOICE_FALSE.getMsg());
            return responseBean;
        }
        OrderDetail orderDetail = this.voiceRecognitionService.matchingOrderDetail(result,memberId,mktId);
        if("0".equals(code)){
            responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.VOICE_SUCCESS.getStatus(),
                    StatusMsgEnum.VOICE_SUCCESS.getMsg());
        }else{
            responseBean = ResponseUtil.createRespBean(false, StatusMsgEnum.VOICE_FALSE.getStatus(),
                    StatusMsgEnum.VOICE_FALSE.getMsg());
        }
       // responseBean.getData().put("pname", p.getName());
        //responseBean.getData().put("price", price);
        //responseBean.getData().put("weight", wight);
//        OrderDetail orderDetail = buildOrderDetail(p,price,wight);
        responseBean.getData().put("orderDetail", orderDetail);
        return responseBean;
    }
    @GetMapping("/demo")
    public ResponseBean demo(){
        XFvoicerespBean result = null;
        try {
            result = this.voiceRecognitionService.demo();
        } catch (IOException e) {
            e.printStackTrace();
        }
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("result",result);
        return responseBean;
    }
}
