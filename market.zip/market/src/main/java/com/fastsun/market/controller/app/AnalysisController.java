package com.fastsun.market.controller.app;

import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.utils.StatusMsgEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.fastsun.market.service.impl.common.MsgServiceImpl;

import com.fastsun.market.bean.*;
import com.fastsun.market.jpa.*;
import com.fastsun.framework.jpa.*;
import com.fastsun.market.entity.common.*;
import com.fastsun.framework.entity.rbac.*;
import com.fastsun.market.entity.member.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import javax.validation.Valid;
import java.util.*;
import com.fastsun.market.service.impl.*;
import com.fastsun.market.MarketApi;

@Api(description = "分析", tags = { "marker.app.Analysis" })
@RestController("appAnalysisController")
@RequestMapping(MarketApi.AnalysisApi.PREFIX)
public class AnalysisController extends BaseController {

}
