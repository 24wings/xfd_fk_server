package com.fastsun.market.service.impl;

import org.springframework.stereotype.Service;

@Service
public class SubjectServiceImpl{


}
