package com.fastsun.market.controller.app;

import com.fastsun.framework.bean.MemberAccTuple;
import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.utils.StatusMsgEnum;
import com.fastsun.market.entity.account.AccRecvPay;
import com.fastsun.market.entity.enums.CommonStatusEnum;
import com.fastsun.market.entity.enums.MemberInviteStatusEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.fastsun.market.service.impl.common.MsgServiceImpl;

import com.fastsun.market.bean.*;
import com.fastsun.market.jpa.*;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.entity.enums.AccountStatus;
import com.fastsun.market.entity.enums.AccountType;
import com.fastsun.market.entity.member.*;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Api;

import java.math.BigDecimal;
import java.util.*;
import com.fastsun.market.service.impl.*;
import com.fastsun.market.MarketApi.MemberAccountApi;

import javax.servlet.http.HttpServletRequest;

@Api(description = "会员", tags = { "market.app.Member" })
@RestController("appMemberController")
@RequestMapping(MemberAccountApi.PREFIX)
public class MemberController extends BaseController {
    private ResponseBean responseBean;
    @Autowired
    private MsgServiceImpl msgService;
    @Autowired
    private CustomerJPA customerJPA;
    @Autowired
    private MemberJPA memberJPA;

    @Autowired
    private AccountJPA accountJPA;
    @Autowired
    private MemberAccountJPA memberAccountJPA;
    @Autowired
    private MemberAccountServiceImpl memberAccountServiceImpl;
    @Autowired
    private MemberServiceImpl memberService;

    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private AccRecvPayJPA accRecvPayJPA;

    @ApiOperation(value = "会员详情", notes = "", httpMethod = "GET")
    @RequestMapping(value = MemberAccountApi.memberDetail, method = RequestMethod.GET)
    public ResponseBean memberDetail(@RequestParam Integer memberId, @RequestParam Integer mktId) {
        Member member = null;
        if(memberJPA.findById(memberId).isPresent()) {
            member = memberJPA.findById(memberId).get();
        }
        if(member == null) {
            return ResponseUtil.createRespBean(false,400,"会员不存在！");
        }
        ResponseBean res = ResponseUtil.createRespBean(true, 200, "会员详情");
        res.getData().put("member", member);
        return res;
    }

    /**
     * 
     * 当前测试阶段直接通过认证,并开通会员,并开通会员账户
     * 
     * 
     * 
     */
    @ApiOperation(value = "会员详情", notes = "", httpMethod = "POST")
    @RequestMapping(value = MemberAccountApi.memberRealnameAuthCreate, method = RequestMethod.POST)
    public ResponseBean memberRealnameAuthCreate(HttpServletRequest request, @RequestBody Member newMember) {
//        Member exsitMember = memberJPA.findByCustomerId(newMember.getCustomerId());
//        Integer customerid = newMember.getCustomerId();
//        Customer customer = (Customer) commonEntityService.findById(Customer.class, customerid);
//        if (exsitMember == null && customer != null) {
//            newMember.setNo(new Date().toString());
//            Member member = memberJPA.saveAndFlush(newMember);
//            Account newAccount = new Account();
//            newAccount.setAccountType(AccountType.MEMBER_CASH);
//            newAccount.setNo(new Date().toString());
//            newAccount.setAvailAmt(new BigDecimal(0));
//            newAccount.setBalAmt(new BigDecimal(0));
//            newAccount.setFrozenAmt(new BigDecimal(0));
//            newAccount.setStatus(AccountStatusEnum.ENABLE);
//            newAccount = accountJPA.saveAndFlush(newAccount);
//            MemberAccount memberAccount = new MemberAccount();
//            memberAccount.setAccountType(AccountType.MEMBER_CASH);
//            memberAccount.setAccountNo(newAccount.getNo());
//            memberAccount.setRelationId(member.getId());
//            memberAccountJPA.saveAndFlush(memberAccount);
//            customer.setMemberId(member.getId());
//            customerJPA.saveAndFlush(customer);
//            ResponseBean success = ResponseUtil.createRespBean(true, 200, "实名认证成功");
//            success.getData().put("member", member);
//            success.getData().put(190e35f7e06e4367265"account", newAccount);
//            success.getData().put("memberAccount", memberAccount);
//            return success;
//        } else {
//            return ResponseUtil.createRespBean(false, 400, "用户已经开通或等待实名认证开通");
//        }
        Member member = memberService.saveMember(newMember,request);
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("member",member);
        return responseBean;
    }

    @ApiOperation(value = "账户详情", notes = "", httpMethod = "GET")
    @RequestMapping(value = MemberAccountApi.accountDetail, method = RequestMethod.GET)
    public ResponseBean accountDetail(@RequestParam Integer memberId, @RequestParam Integer mktId) {
        MemberAccount memberCashAccount = this.memberAccountJPA.findByRelationIdAndAccountType(memberId,
                AccountType.MEMBER_CASH);
        if (memberCashAccount != null) {
            String cashAccountNo = memberCashAccount.getAccountNo();
            Account account = accountJPA.findByAccountTypeAndNo(AccountType.MEMBER_CASH, cashAccountNo);
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "账户详情");
            success.getData().put("account", account);
            return success;
        } else {
            return ResponseUtil.createRespBean(false, 400, "账户未开通");
        }

    }

    @ApiOperation(value = "列举市场其他会员", notes = "", httpMethod = "GET")
    @RequestMapping(value = MemberAccountApi.memberFriends, method = RequestMethod.GET)
    public ResponseBean memberFriends(@RequestParam Integer memberId, @RequestParam Integer mktId) {
        List<Member> members = this.memberJPA.findByMktId(mktId);
        Object[] memberArr = members.stream().filter(member -> member.getId() != memberId).toArray();
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "成功");
        success.getData().put("members", memberArr);
        return success;
    }

    @ApiOperation(value = "会员转账", notes = "", httpMethod = "GET")
    @RequestMapping(value = MemberAccountApi.transferAccount, method = RequestMethod.GET)
    public ResponseBean transferAccount(@RequestParam Integer memberId, @RequestParam Integer tomemberId ,@RequestParam BigDecimal transferAmount) {
        /**
         * 1. 检查双方账户是否存在 2. 检查账户是否金额可用且状态不属于冻结,禁用
         */
        if(memberId == null && tomemberId == null
                && transferAmount == null)
        {
            return ResponseUtil.createRespBean(false, 400, "请输入转账方和金额！");
        }
        try{
            MemberAccTuple<Member,Account> memberAccTuple = this.memberService.findByMemNo(null,memberId);
            MemberAccTuple<Member,Account> tomemberAccTuple = this.memberService.findByMemNo(null,tomemberId);
            Account account = memberAccTuple.second;
            Account toaccount = tomemberAccTuple.second;
            Member member = memberAccTuple.first;
            Member tomember = tomemberAccTuple.first;
            if(account != null && toaccount != null)
            {
                TransferResult result = this.memberAccountServiceImpl.transferAmt(account,toaccount,transferAmount,member,tomember);
                if(result != null) {
                    ResponseBean res = ResponseUtil.createRespBean(true, 200, "转账成功!");
                    res.getData().put("result", result);
                    return res;
                }
                else
                {
                    return ResponseUtil.createRespBean(false, 400, "账户禁用或金额不足！");

                }
            }
            else
            {
                return ResponseUtil.createRespBean(false, 400, "转账方或收款方不存在!");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;

    }


    @ApiOperation(value = "获取收钱信息含账户和金额", notes = "", httpMethod = "GET")
    @RequestMapping(value = MemberAccountApi.recvMoneyInfo, method = RequestMethod.GET)
    public ResponseBean recvMoneyInfo(@RequestParam Integer mktId, @RequestParam BigDecimal amt,
            @RequestParam Integer accountId) {
        Account account = accountJPA.findById(accountId).get();
        if (account != null) {
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "");
            success.getData().put("account", account);
            success.getData().put("amt", amt);
            return success;
        } else {
            return ResponseUtil.createRespBean(false, 400, "信息错误");
        }
    }
    @GetMapping("/modifyPayPassword")
    public ResponseBean modifyPayPassword(@RequestParam Integer memberId,@RequestParam String newPayPasswoord){
        Member member = this.memberService.modifyPayPassword(newPayPasswoord,memberId);
        responseBean = ResponseUtil.createRespBean(true,200,StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        responseBean.getData().put("member",member);
        return responseBean;
    }

    @GetMapping("/confirePayPassword")
    public ResponseBean confirePayPassword(@RequestParam Integer memberId,@RequestParam String payPassword) throws Exception{
        Boolean flag = this.memberService.confirePayPassword(memberId,payPassword);
        if(flag)
        {
            responseBean = ResponseUtil.createRespBean(true,200,"");
        }
        else
        {
            responseBean = ResponseUtil.createRespBean(false,200,"支付密码错误！");

        }
        responseBean.getData().put("flag",flag);
        return responseBean;
    }

    @ApiOperation(value="支付密码解锁",notes = "",httpMethod = "GET")
    @RequestMapping(value="/cleanPayPassword",method = RequestMethod.GET)
    public ResponseBean cleanPayPassword(@RequestParam Integer memberId){
        if(memberId == null)
        {
            return ResponseUtil.createRespBean(false,400,"该会员不存在！");
        }
        Boolean flag = this.memberService.cleanPayPassword(memberId);
        ResponseBean res = ResponseUtil.createRespBean(true, 200,"解锁成功！");
        res.getData().put("flag",flag);
        return res;
    }

    @ApiOperation(value="根据手机号或关键字搜索boss",notes = "",httpMethod = "GET")
    @RequestMapping(value="/searchMember",method = RequestMethod.GET)
    public ResponseBean searchMember(@RequestParam String keyWord)
    {
        if(keyWord == null)
        {
            return ResponseUtil.createRespBean(false,400,"请输入关键字！");
        }
        List<Member> memberBySearch = this.memberService.searchMember(keyWord);
        ResponseBean res = ResponseUtil.createRespBean(true, 200,"查询成功！");
        res.getData().put("member",memberBySearch);
        return res;
    }

    @ApiOperation(value="邀请好友",notes = "",httpMethod = "GET")
    @RequestMapping(value="/friendInvi",method = RequestMethod.GET)
    public ResponseBean memberfriendInvi(@RequestParam Integer memberId,@RequestParam Integer friendId,@RequestParam String content) throws Exception
    {
        if(memberId == null && friendId == null)
        {
            return ResponseUtil.createRespBean(false,400,"邀请会员为空！请重新输入！");

        }
        ResponseBean res = null;
        ContactInvite contactInvite = this.memberService.friendInvi(memberId,friendId,content);
        if(contactInvite == null)
        {
            return ResponseUtil.createRespBean(false,400,"该会员已是您的好友或不存在此会员！");
        }
        res = ResponseUtil.createRespBean(true,200,"已发送邀请");
        res.getData().put("contactInvite",contactInvite);
        return res;

    }
    @ApiOperation(value="根据发送邀请同意或拒绝",notes = "",httpMethod = "POST")
    @RequestMapping(value="/Inviprocess",method = RequestMethod.POST)
    public ResponseBean memberInviprocess(@RequestBody ContactInvite contactInvite)  {
        if(contactInvite == null) {
            return ResponseUtil.createRespBean(false,400,"输入空值！请重新输入！");
        }
        try{
            boolean flag = this.memberService.inviprocess(contactInvite);
            if(flag) {
                return ResponseUtil.createRespBean(true,200,"同意该邀请！");
            }

        }catch(Exception e){
            responseBean = ResponseUtil.createRespBean(false,201,"");
            e.printStackTrace();
            return responseBean;
        }
        return ResponseUtil.createRespBean(false,200,"拒绝该好友！");
        
    }

    @ApiOperation(value="发送列表和接收列表",notes = "",httpMethod = "GET")
    @RequestMapping(value="/InviList",method = RequestMethod.GET)
    public ResponseBean memberInviList(@RequestParam Integer memberId,@RequestParam String type) {
        if(memberId == null && type == null) {
            return ResponseUtil.createRespBean(false,400,"输入空值！请重新输入！");
        }
        List<ContactInvite> contactInvite = this.memberService.memberInviList(memberId,type);
        ResponseBean res = ResponseUtil.createRespBean(true,200,"成功！");
        res.getData().put("contactInvite",contactInvite);
        return res;
    }

    @ApiOperation(value="好友列表",notes = "",httpMethod = "GET")
    @RequestMapping(value="/friendLists",method = RequestMethod.GET)
    public ResponseBean friendLists(@RequestParam Integer memberId) {
        if(memberId == null) {
            return ResponseUtil.createRespBean(false,400,"输入空值！请重新输入！");
        }
        List<Member> member = this.memberService.friends(memberId);
        ResponseBean res = ResponseUtil.createRespBean(true,200,"成功！");
        res.getData().put("member",member);
        return res;
    }

//    @ApiOperation(value = "", notes = "",httpMethod = "GET")
//    @RequestMapping(value = "/recvpayListBymemberId",method = RequestMethod.GET)
//    public ResponseBean recvpayListBymemberId(@RequestParam Integer memberId)
//    {
//        if(memberId == null)
//        {
//            return ResponseUtil.createRespBean(false,400,"输入空值！请重新输入！");
//        }
//        List<Object> accRecvPayList = this.memberService.recvpayListBymemberId(memberId);
//        ResponseBean res = ResponseUtil.createRespBean(true,200,"成功！");
//        res.getData().put("accRecvPayList",accRecvPayList);
//        return res;
//    }
    @PostMapping(value = "/memberRecvPay")
    public ResponseBean getRecvPay(@RequestParam Integer memberId, @RequestBody QueryParameter queryParameter){
        Paging paging = null;
        try {
            paging = this.memberService.getRecvPayList(memberId,queryParameter);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(false,201,"");
            e.printStackTrace();
            return responseBean;
        }
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("paging",paging);
        return responseBean;
    }
}
