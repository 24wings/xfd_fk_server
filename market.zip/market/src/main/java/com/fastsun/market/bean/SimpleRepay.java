package com.fastsun.market.bean;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class SimpleRepay {
    @NotNull(message = "赊销记录Id不能为Null!")
    public Integer deptId;
    @NotNull(message = "还款金额不能为Null!")
    public BigDecimal repayAmt;

    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    public BigDecimal getRepayAmt() {
        return repayAmt;
    }

    public void setRepayAmt(BigDecimal repayAmt) {
        this.repayAmt = repayAmt;
    }
}
