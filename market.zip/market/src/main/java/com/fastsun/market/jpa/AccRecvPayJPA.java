package com.fastsun.market.jpa;

import com.fastsun.framework.jpa.base.BaseRepository;
import com.fastsun.market.entity.account.AccRecvPay;

import java.util.List;

public interface AccRecvPayJPA extends BaseRepository<AccRecvPay,Integer> {

    List<AccRecvPay> findByAccountId(Integer accountId);
}
