package com.fastsun.market.bean;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class QueryDataAction {

    private static final Logger LOGGER = LogManager.getLogger(QueryDataAction.class);

    public String errorCode;

    public QueryDataAction() {
    }

    public QueryDataAction(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    };
/* ww
    public <T> List<T> queryByPropertys(QueryCondition queryCondition) {
        String querySymbols = null;
        StringBuffer sqlBuffer = new StringBuffer();
        sqlBuffer.append("select model \n");
        sqlBuffer.append("from " + queryCondition.ModelName + " as model \n");
        boolean first = true;
        for (int pi = 0; pi < queryCondition.Parameters.size(); pi++) {
            if (queryCondition.Parameters.get(pi).getParameterName() != null) {
                if (first) {
                    sqlBuffer.append("where ");
                    first = false;
                } else {
                    sqlBuffer.append("and ");
                }
                if (queryCondition.Parameters.get(pi).getParameterType() == QueryParameter.QueryOperateType.Equal) {
                    sqlBuffer.append("model."
                            + queryCondition.Parameters.get(pi)
                            .getParameterName()
                            + " = "
                            + querySymbols
                            + queryCondition.Parameters.get(pi)
                            .getParameterName() + " \n");
                } else if (queryCondition.Parameters.get(pi).getParameterType() == QueryParameter.QueryOperateType.CharIn) {
                    sqlBuffer.append("InStr(model."
                            + queryCondition.Parameters.get(pi)
                            .getParameterName()
                            + " , "
                            + querySymbols
                            + queryCondition.Parameters.get(pi)
                            .getParameterName() + " ) > 0 \n");
                }
            }
        }
        List<T> list = new ArrayList<T>();
        try {
            EntityManager emEntityManager = EntityManagerUtil
                    .getEntityManager();
            Query queryObject = emEntityManager.createQuery(sqlBuffer
                    .toString());
            for (int li = 0; li < queryCondition.Parameters.size(); li++) {
                queryObject.setParameter(queryCondition.Parameters.get(li)
                        .getParameterName(), queryCondition.Parameters.get(li)
                        .getParameterValue());
            }
            list = queryObject.getResultList();
            emEntityManager.close();

        } catch (RuntimeException re) {
            errorCode += "CM000006";
            throw re;
        }
        return list;
    }*/

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

}
