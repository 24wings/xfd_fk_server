package com.fastsun.market.utils;



import java.nio.charset.Charset;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created by foxweimin on 2016-06-22.
 */
public class PrinterUtil {
    private static byte STX = 0x02;
    private static byte ETX = 0x03;
    private static byte TYPE = 0x01;
    private static int TIME_OUT = 30000;
    public volatile static byte[] recvbuffer = new byte[2048];
    public volatile static int recv_indx =0;




    private static byte toByte(char c) {
        byte b = (byte) "0123456789ABCDEF".indexOf(c);
        return b;
    }



    public static byte[] hex2Byte(String hex) {
        int len = (hex.length() / 2);
        byte[] result = new byte[len];
        char[] achar = hex.toCharArray();
        for (int i = 0; i < len; i++) {
            int pos = i * 2;
            result[i] = (byte) (toByte(achar[pos]) << 4 | toByte(achar[pos + 1]));
        }
        return result;
    }





    public static byte[] getSendBuffer(String s) {
        byte[] buffer = new byte[10000];
        int pos = 0;
        int d1 = 0, s1 = 0, l = 0, len = 0;
        String r = "HEX(\\w+)";
        String regex = "HEX\\([\\w\\d]+\\)";
        Matcher m = Pattern.compile(regex).matcher(s);
        while (m.find()) {
            if (m.start() >= s1) {
                String str = s.substring(s1, m.start());
                byte[] bytes1 = str.getBytes(Charset.forName("GBK"));
                l = bytes1.length;
                System.arraycopy(bytes1, 0, buffer, d1, l);
                len = len + l;
            }
            s1 = m.end();
            String g = m.group().replace(" ", "");
            g = g.substring(4, g.length() - 1);
            byte[] bytes2 = PrinterUtil.hex2Byte(g);
            d1 = d1 + l;
            l = bytes2.length;
            System.arraycopy(bytes2, 0, buffer, d1, l);
            len = len + l;
            d1 = d1 + l;
        }
        String str = s.substring(s1, s.length());
        byte[] bytes1 = str.getBytes(Charset.forName("GBK"));
        l = bytes1.length;
        System.arraycopy(bytes1, 0, buffer, d1, l);
        len = len + l;
        byte[] b = new byte[len];
        System.arraycopy(buffer, 0, b, 0, len);
        return b;
    }



}
