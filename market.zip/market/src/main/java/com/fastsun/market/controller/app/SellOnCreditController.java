package com.fastsun.market.controller.app;

import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.utils.StatusMsgEnum;
import com.fastsun.market.bean.AccountRepayRq;
import com.fastsun.market.bean.BatchRepayRq;
import com.fastsun.market.bean.OrderPayRq;
import com.fastsun.market.bean.SimpleRepay;
import com.fastsun.market.entity.account.AccountDebt;
import com.fastsun.market.entity.enums.RepayStatus;
import com.fastsun.market.entity.transOrder.Order;
import com.fastsun.market.entity.account.AccountRepay;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.jpa.AccountRepayJPA;
import com.fastsun.market.jpa.OrderJPA;
import com.fastsun.market.service.impl.MemberServiceImpl;
import com.fastsun.market.service.impl.OrderServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.List;

@Api(description = "赊销",tags = {"market.app.SellOnCredit"})
@RestController
@RequestMapping("/app/sellOnCredit")
public class SellOnCreditController extends BaseController {
    @Autowired
    private OrderServiceImpl orderServiceImpl;
    @Autowired
    private CommonEntityService commonEntityService;
    @Autowired
    private AccountRepayJPA accountRepayJPA;
    private ResponseBean responseBean;
    @Autowired
    private MemberServiceImpl memberService;
    @Autowired
    private OrderJPA orderJPA;

    @ApiOperation(value = "赊销订单支付",notes = "赊销订单支付",httpMethod = "POST")
    @PostMapping("/orderPay")
    public ResponseBean sellOnCreditOrderPay(@RequestBody OrderPayRq orderPayRq) throws Exception{
        Order order = this.orderJPA.findByOrderNo(orderPayRq.getOrderNo());
        boolean flag = this.memberService.confirePayPassword(order.getBuyerMemId(),orderPayRq.getPayPassword());
        if(flag) {
            try {
                order = this.orderServiceImpl.sellOnCreditOrderPay(orderPayRq);
            } catch (Exception e) {
                e.printStackTrace();
            }
            responseBean = ResponseUtil.createRespBean(true, 200, "");
            responseBean.getData().put("accountDebt", order);
            return responseBean;
        }
        return ResponseUtil.createRespBean(false,400,"支付密码错误！");
    }
//    @ApiOperation(value = "确认赊销支付",notes = "卖家确认赊销支付",httpMethod = "GET")
//    @GetMapping("/confirmRepay")
//    public ResponseBean confirmRepay(@RequestParam Integer id,@RequestParam Boolean flag){
//        AccountRepay accountRepay = this.accountRepayJPA.findById(id).get();
//        accountRepay.setConfirmed(flag);
//        AccountRepay accountRepayDB = (AccountRepay) this.commonEntityService.update(accountRepay);
//        responseBean = ResponseUtil.createRespBean(true,200,"");
//        responseBean.getData().put("accountRepay",accountRepayDB);
//        return responseBean;
//    }
    @ApiOperation(value = "线上还款",notes = "",httpMethod = "POST")
    @PostMapping("/onlineRepay")
    public ResponseBean onlineRepay(@RequestBody AccountRepayRq accountRepayRq){
        AccountRepay accountRepay = null;
        try {
            accountRepay = this.orderServiceImpl.onlineRepay(accountRepayRq);
        } catch (Exception e) {
            e.printStackTrace();
        }
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("accountRepay",accountRepay);
        return responseBean;
    }
    @ApiOperation(value = "批量线上还款",notes = "",httpMethod = "POST")
    @PostMapping("/batchRepay")
    public ResponseBean batchRepay(@RequestBody BatchRepayRq batchRepayRq){
        try {
            this.orderServiceImpl.batchRepay(batchRepayRq);
        } catch (Exception e) {
            e.printStackTrace();
        }
        responseBean = ResponseUtil.createRespBean(true,200,"还款成功！");
        return responseBean;
    }
    @ApiOperation(value = "线下还款欠款方申请",notes = "",httpMethod = "POST")
    @PostMapping("/offlineRepayApply")
    public ResponseBean offlineRepayApply(@RequestBody AccountRepayRq accountRepayRq){
        AccountRepay accountRepay = this.orderServiceImpl.offlineRepayApply(accountRepayRq);
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("accountRepay",accountRepay);
        return  responseBean;
    }
    @ApiOperation(value = "欠款方批量线下还款申请",notes = "",httpMethod = "POST")
    @PostMapping("/batchOfflineRepayApply")
    public ResponseBean batchOfflineRepayApply(HttpServletRequest request, @RequestBody BatchRepayRq batchRepayRq){
        try {
            this.orderServiceImpl.batchOfflineRepayApply(request,batchRepayRq);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(true,200,"申请失败！");
            e.printStackTrace();
            return  responseBean;
        }
        responseBean = ResponseUtil.createRespBean(true,200,"申请成功！");
        return  responseBean;
    }

    @ApiOperation(value = "线下还款收款方确认",notes = "",httpMethod = "GET")
    @GetMapping("/offlineRepayConfire")
    public ResponseBean offlineRepayConfire(HttpServletRequest request,@RequestParam String payPassword,@RequestParam Integer id){
        AccountRepay accountRepay = null;
        try {
            accountRepay = this.orderServiceImpl.offlineRepayConfirm(request,payPassword,id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("accountRepay",accountRepay);
        return  responseBean;
    }

    @ApiOperation(value = "线下还款收款方拒绝",notes = "",httpMethod = "GET")
    @GetMapping("/offlineRepayRefused")
    public ResponseBean offlineRepayRefused(HttpServletRequest request,@RequestParam Integer id, @RequestParam RepayStatus repayStatus) throws Exception{
        this.orderServiceImpl.offlineRepayRefused(request,id,repayStatus);
        responseBean = ResponseUtil.createRespBean(true,200,"操作成功！");
        return  responseBean;
    }
    @ApiOperation(value = "线下还款拒绝",notes = "拒绝后删除还款记录",httpMethod = "GET")
    @GetMapping("/repayRefuse")
    public ResponseBean repayRefuse(@RequestParam Integer repayId){
        this.accountRepayJPA.deleteById(repayId);
        responseBean = ResponseUtil.createRespBean(true,200,"");
        return responseBean;
    }

    @ApiOperation(value = "查询买家信用",notes = "查询买家信用",httpMethod = "GET")
    @GetMapping("/qryBuyerCredit")
    public  ResponseBean qryBuyerCredit(@RequestParam String orderNo){
        BigDecimal amount = null;
        try {
            amount = this.orderServiceImpl.qryBuyerCredit(orderNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Member member = this.orderServiceImpl.getMemberByOrderNo(orderNo,-1);
        responseBean = ResponseUtil.createRespBean(true,200,StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("amount",amount);
        if(member == null){
            responseBean.getData().put("memberName",null);
            return responseBean;
        }
        responseBean.getData().put("memberName",member.getName());
        return responseBean;
    }
    @GetMapping("/qryBuyerCreditById")
    public ResponseBean qryBuyerCredit(@RequestParam Integer memberId,@RequestParam Integer mktId){
        BigDecimal bigDecimal = null;
        try {
            bigDecimal = this.orderServiceImpl.qryBuyerCredit(memberId,mktId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("amount",bigDecimal);
        return  responseBean;
    }
    @GetMapping("/qryBuyerCreditByQCode")
    public ResponseBean qryBuyerCreditByQCode(@RequestParam String base64Str){
        String[] result = null;
        try {
            result = this.orderServiceImpl.qryBuyerCreditByQcode(base64Str);
        } catch (Exception e) {
            e.printStackTrace();
        }
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("memberName",result[0]);
        responseBean.getData().put("amount",result[1]);
        return  responseBean;
    }

    @ApiOperation(value = "查询赊销记录列表",notes = "查询赊销记录列表",httpMethod = "POST")
    @PostMapping("/accountDebtList")
    public ResponseBean getAccountDebtList(@RequestBody QueryParameter queryParameter,@RequestParam Integer io){
        Paging paging = this.orderServiceImpl.getAccountDebtList(queryParameter,io);
        responseBean = ResponseUtil.createRespBean(true,200,StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("paging",paging);
        return responseBean;
    }

    @ApiOperation(value = "查询赊销记录的待确认欠款总额",notes = "查询赊销记录的待确认欠款总额",httpMethod = "GET")
    @GetMapping("/accountDebtListDetail")
    public ResponseBean getAccountDebtList(@RequestParam Integer deptorAccId ,@RequestParam Integer depteeAccId){
        List<AccountDebt> accountDebts= this.orderServiceImpl.getAccountDebts(deptorAccId,depteeAccId);
        responseBean = ResponseUtil.createRespBean(true,200,StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("accountDebts",accountDebts);
        return responseBean;
    }

    @ApiOperation(value = "查询还款记录列表",notes = "查询还款记录列表",httpMethod = "POST")
    @PostMapping("/accountRepayList")
    public ResponseBean getAccountRepayList(@RequestBody QueryParameter queryParameter,@RequestParam Integer io,@RequestParam(defaultValue = "") RepayStatus repayStatus){
        List<AccountRepay> paging = this.orderServiceImpl.getAccountRepayList(queryParameter,io,repayStatus);
        responseBean = ResponseUtil.createRespBean(true,200,StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("paging",paging);
        return responseBean;
    }

}
