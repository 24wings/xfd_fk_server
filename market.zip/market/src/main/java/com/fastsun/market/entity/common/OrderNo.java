package com.fastsun.market.entity.common;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "orderNo",uniqueConstraints = {@UniqueConstraint(columnNames = "currentKey")})
public class OrderNo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String currentKey;
    private Integer currentValue;
    public OrderNo(){}

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCurrentKey() {
        return currentKey;
    }

    public void setCurrentKey(String currentKey) {
        this.currentKey = currentKey;
    }

    public Integer getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(Integer currentValue) {
        this.currentValue = currentValue;
    }
}
