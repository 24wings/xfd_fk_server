package com.fastsun.market.controller.web;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.utils.StatusMsgEnum;
import com.fastsun.framework.bean.Paging;
import com.fastsun.market.entity.common.TransFeeRule;
import com.fastsun.market.service.impl.TransFeeRuleServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import io.swagger.annotations.Api;

@Api(description = "交易规则", tags = { "market.web.TransFeeRule" })
@RestController
@RequestMapping("/api/transFeeRule")
public class TransFeeRuleController extends BaseController {

    private ResponseBean responseBean;
    @Autowired
    CommonEntityService transFeeRuleCommonEntityService;
    @Autowired
    TransFeeRuleServiceImpl transFeeRuleService;

    @PostMapping(value = "/list")
    public ResponseBean getTransFeeRuleList(@RequestBody QueryParameter queryParameter) {
        Paging<TransFeeRule> paging = this.transFeeRuleCommonEntityService.findPagedEntity(queryParameter,
                TransFeeRule.class);
        responseBean = ResponseUtil.createRespBean(true, 200, "查询成功！");
        responseBean.getData().put("paging", paging);
        return responseBean;
    }

    @PostMapping(value = "/create")
    public ResponseBean createTransFeeRule(HttpServletRequest request, @RequestBody TransFeeRule transFeeRule) {
        this.transFeeRuleService.saveTransFeeRule(request, transFeeRule);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(), "添加成功！");
        return responseBean;
    }

    @GetMapping(value = "/ableAndDisable")
    public ResponseBean modifyStatus(@RequestParam Integer id,@RequestParam Boolean status){
        TransFeeRule transFeeRule = (TransFeeRule) this.transFeeRuleCommonEntityService.findById(TransFeeRule.class,id);
        transFeeRule.setEnabled(status);
        this.transFeeRuleCommonEntityService.update(transFeeRule);
        responseBean =  ResponseUtil.createRespBean(true,StatusMsgEnum.ADD_SUCCESS.getStatus(),"修改成功！");
        return  responseBean;
    }
}
