package com.fastsun.market.entity.member;

import javax.persistence.*;

import com.fastsun.market.entity.enums.MemberInviteStatusEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

@Entity
@Table(name = "b_member_invite")
public class MemberInvite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ApiModelProperty("内容")
    private String content; // 会员编号
    /**
     * 发送方的customerId
     */
    @ApiModelProperty("会员Id")
    private Integer memberId;

    @ApiModelProperty("发送方Id")
    private Integer sendCustId;

    @ApiModelProperty("发送方姓名")
    private String sendCusName;

    @ApiModelProperty("接收手机号")
    private String recvMobi;

    @ApiModelProperty("接收方姓名")
    private String recvCusName;

    @Enumerated(EnumType.ORDINAL)
    @ApiModelProperty("邀请状态")
    private MemberInviteStatusEnum status = MemberInviteStatusEnum.Active;

    /**
     * @return the recvCusName
     */
    public String getRecvCusName() {
        return recvCusName;
    }

    /**
     * @param recvCusName the recvCusName to set
     */
    public void setRecvCusName(String recvCusName) {
        this.recvCusName = recvCusName;
    }

    /**
     * @return the recvMobi
     */
    public String getRecvMobi() {
        return recvMobi;
    }

    /**
     * @param recvMobi the recvMobi to set
     */
    public void setRecvMobi(String recvMobi) {
        this.recvMobi = recvMobi;
    }

    /**
     * @return the sendCusName
     */
    public String getSendCusName() {
        return sendCusName;
    }

    /**
     * @return the status
     */
    public MemberInviteStatusEnum getStatus() {
        return status;
    }

    /**
     * @param sendCusName the sendCusName to set
     */
    public void setSendCusName(String sendCusName) {
        this.sendCusName = sendCusName;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(MemberInviteStatusEnum status) {
        this.status = status;
    }

    /**
     * 接收方customerId
     */
    @ApiModelProperty("接受方Id")
    private Integer recvCustId; // 身份证号

    @ApiModelProperty("是否同意")
    private Boolean confirmed;// 是否同意

    @ApiModelProperty("所属市场Id")
    private Integer mktId;// 所属市场id

    @ApiModelProperty("创建时间")
    private Date createTime = new Date();// 创建时间

    @ApiModelProperty("确认时间")
    private Date confirmTime;// 确认时间

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    /**
     * @param recvCustId the recvCustId to set
     */
    public void setRecvCustId(Integer recvCustId) {
        this.recvCustId = recvCustId;
    }

    /**
     * @return the sendCustId
     */
    public Integer getSendCustId() {
        return sendCustId;
    }

    /**
     * @param sendCustId the sendCustId to set
     */
    public void setSendCustId(Integer sendCustId) {
        this.sendCustId = sendCustId;
    }

    /**
     * @return the recvCustId
     */
    public Integer getRecvCustId() {
        return recvCustId;
    }

    public Boolean getConfirmed() {
        return confirmed;
    }

    public void setConfirmed(Boolean confirmed) {
        this.confirmed = confirmed;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getConfirmTime() {
        return confirmTime;
    }

    public void setConfirmTime(Date confirmTime) {
        this.confirmTime = confirmTime;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }
}
