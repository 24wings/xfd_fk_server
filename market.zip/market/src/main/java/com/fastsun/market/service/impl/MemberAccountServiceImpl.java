package com.fastsun.market.service.impl;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.service.impl.OrderNoServiceImpl;
import com.fastsun.framework.utils.JsonDateValueProcessorUtil;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.market.bean.TransferResult;
import com.fastsun.market.entity.common.AppMsgNotify;
import com.fastsun.market.entity.enums.AccountStatus;
import com.fastsun.market.entity.enums.MsgType;
import com.fastsun.market.entity.enums.SubjectCodeEnum;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.entity.member.MemberAccount;
import com.fastsun.market.entity.account.AccRecvPay;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.entity.enums.AccountType;
import com.fastsun.market.jpa.*;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Service
public class MemberAccountServiceImpl{

    @Autowired
    MemberJPA memberJPA;

    @Autowired
    MemberAccountJPA memberAccountJPA;

    @Autowired
    CustomerJPA customerJPA;

    @Autowired
    AccountJPA accountJPA;

    @Autowired
    AccRecvPayJPA accRecvPayJPA;

    @Autowired
    OrderServiceImpl orderService;

    @Autowired
    AppMsgNotifyJPA appMsgNotifyJPA;

    @Autowired
    OrderNoServiceImpl orderNoService;

    /**
     * A转账给B 所以
     *
     ** A的支出记录(AccPayRecv)为 * IO=-1
     *
     *
     ** B的支出记录(AccPayRecv)为 io=1
     */
    public TransferResult transferAmt(Account account, Account toaccount, BigDecimal transferAmount,
    Member member,Member tomember) throws Exception {
        TransferResult result = new TransferResult();
        if(account.getStatus().equals(AccountStatus.ENABLE) &&
                toaccount.getStatus().equals(AccountStatus.ENABLE) &&
                account.getAvailAmt().compareTo(transferAmount) > 0)
        {

            if (account.getAccountType().equals(toaccount.getAccountType()))
            {

//                account.setAvailAmt(account.getAvailAmt().subtract(transferAmount));
//                account.setBalAmt(account.getBalAmt().subtract(transferAmount));
//                toaccount.setAvailAmt(toaccount.getAvailAmt().add(transferAmount));
//                toaccount.setBalAmt(toaccount.getBalAmt().add(transferAmount));
//                accountJPA.saveAndFlush(account);
//                accountJPA.saveAndFlush(toaccount);
                String orderCountNo = null;
                if(orderCountNo == null)
                {
                    orderCountNo  = "H0001"+String.format("%05d",this.orderNoService.getOrderNo("orderCountNoCreateKey"));
                }
                AccRecvPay accRecvPay = this.orderService.createAccRecvPayAndSave(account,member,toaccount,-1,orderCountNo,transferAmount,null,SubjectCodeEnum.SERVICE_TRANFER.getId(),SubjectCodeEnum.SERVICE_TRANFER.getName());
                AccRecvPay accRecvPaytoaccount = this.orderService.createAccRecvPayAndSave(toaccount,tomember,account,1,orderCountNo,transferAmount,null,SubjectCodeEnum.SERVICE_TRANFER.getId(),SubjectCodeEnum.SERVICE_TRANFER.getName());
                accRecvPayJPA.save(accRecvPay);
                accRecvPayJPA.save(accRecvPaytoaccount);
                result.accRecvPays.add(accRecvPay);
                result.isSuccess = true;
                result.amt = transferAmount;
//                AppMsgNotify appMsgNotifyaccount = new AppMsgNotify();
//                appMsgNotifyaccount.setIsRead(false);
//                List<Customer> customer = this.customerJPA.findByMemberId(member.getId());
//                String no = account.getNo();
//                String phone = null;
//                for (Customer items:customer)
//                {
//                    Integer custId =items.getId();
//                    appMsgNotifyaccount.setCustId(custId);
//                    phone = items.getMobi();
//                }
//                appMsgNotifyaccount.setMsgType(MsgType.ACC_AMT);
//                appMsgNotifyaccount.setMemberId(member.getId());
//                appMsgNotifyaccount.setCreator(member.getCreator());
//                appMsgNotifyaccount.setCreatorId(member.getCreatorId());
//                appMsgNotifyaccount.setMktId(member.getMktId());
//                appMsgNotifyaccount.setCreateTime(new Date());
//                JsonConfig jsonConfig = new JsonConfig();
//                jsonConfig.registerJsonValueProcessor(Date.class , new JsonDateValueProcessorUtil());
//                JSONObject json = JSONObject.fromObject(accRecvPay,jsonConfig);
//                json.put("no",no);
//                json.put("phone",phone);
//                String addition= json.toString();
//                appMsgNotifyaccount.setAddition(addition);
//                appMsgNotifyaccount.setTitle("账户变动");
//                appMsgNotifyaccount.setContent("尊敬的用户，您的账户在订单号为"+accRecvPay.getOrderNo()+"的订单中支出"+transferAmount+"元，" +
//                        "当前可用余额"+account.getAvailAmt()+"元");
//                AppMsgNotify appMsgNotifytoaccount = new AppMsgNotify();
//                appMsgNotifytoaccount.setIsRead(false);
//                List<Customer> tocustomer = this.customerJPA.findByMemberId(tomember.getId());
//                String tophone = null;
//                for (Customer items:tocustomer)
//                {
//                    Integer tocustId = items.getId();
//                    appMsgNotifytoaccount.setCustId(tocustId);
//                    tophone = items.getMobi();
//                }
//                appMsgNotifytoaccount.setMsgType(MsgType.ACC_AMT);
//                appMsgNotifytoaccount.setMemberId(tomember.getId());
//                appMsgNotifytoaccount.setCreator(tomember.getCreator());
//                appMsgNotifytoaccount.setCreatorId(tomember.getCreatorId());
//                appMsgNotifytoaccount.setMktId(tomember.getMktId());
//                appMsgNotifytoaccount.setCreateTime(new Date());
//                String tono = account.getNo();
//                JSONObject tojson = JSONObject.fromObject(accRecvPaytoaccount,jsonConfig);
//                tojson.put("no",tono);
//                tojson.put("phone",tophone);
//                String toaddition= tojson.toString();
//                appMsgNotifytoaccount.setAddition(toaddition);
//                appMsgNotifytoaccount.setTitle("账号变动");
//                appMsgNotifytoaccount.setContent("尊敬的用户，您的账户在订单号为"+accRecvPaytoaccount.getOrderNo()+"的订单中收入"+transferAmount+"元"+
//                        "当前可用余额"+toaccount.getAvailAmt()+"元");
//                appMsgNotifyJPA.save(appMsgNotifyaccount);
//                appMsgNotifyJPA.save(appMsgNotifytoaccount);
            }
            else
            {
                result.isSuccess = false;
                result.amt = transferAmount;
                result.errorMsg = "账户不一致";
            }
            return result;
        }
        return result;

    }

    public Account getMemberAccount(Integer memberId, AccountType accountType) {
        MemberAccount memberCashAccount = this.memberAccountJPA.findByRelationIdAndAccountType(memberId,AccountType.MEMBER_CASH);
        if (memberCashAccount != null) {
            String cashAccountNo = memberCashAccount.getAccountNo();
            Account account = accountJPA.findByNo(cashAccountNo);
            return account;
        } else {
            return null;
        }
    }

}