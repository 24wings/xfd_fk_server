package com.fastsun.market.entity.enums;
public enum MsgType {

    //账户变动，操作员变动信息，邀请团队信息，
    // 现金还款通知,现金还款确认，待付款,全部,好友邀请
    ACC_AMT(0,"账户余额变动"), ACTOR_CHANGE(1,"操作员变动信息"),
    CUST_INVITE(2,"邀请团队信息"), REPAY_APPLY(3,"还款申请"),
    REPAY_CONFIRM(4,"还款确认"), TOBE_PAY(5,"待支付"),ALL(6,"所有"),MEM_INVITE(7,"好友邀请"),
    ONLINE_ORDERPAY(8,"线上交易");
    Integer key;
    String value;
    MsgType(Integer key,String value){
        this.key = key;
        this.value = value;
    }
    public Integer getKey() {
        return key;
    }
    public String getValue() {
        return value;
    }
}
