package com.fastsun.market.jpa;

import java.util.List;

import com.fastsun.framework.jpa.base.BaseRepository;
import com.fastsun.market.entity.account.AccountDebt;

public interface AccountDebtJPA extends BaseRepository<AccountDebt, Integer> {
    List<AccountDebt> findByDebtorAccId(Integer debttorId);
    List<AccountDebt> findByDebtorAccIdAndMktId(Integer debtorAccId,Integer mktId);
    List<AccountDebt> findByDebtorAccIdAndDebteeAccId(Integer debtorAccId,Integer debteeAccId);
}
