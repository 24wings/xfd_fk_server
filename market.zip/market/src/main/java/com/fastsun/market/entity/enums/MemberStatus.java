package com.fastsun.market.entity.enums;

public enum MemberStatus {
    ENABLE(0,"可用"),DISABLE(1,"停用"),FROZEN(2,"冻结"),CANCEL(3,"注销");

    private Integer key;
    private String value;

    MemberStatus(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getkey() {
        return key;
    }

    public String getValue() {
        return value;
    }
}
