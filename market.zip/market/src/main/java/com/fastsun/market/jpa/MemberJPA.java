package com.fastsun.market.jpa;

import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.Member;

import java.util.List;

import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface MemberJPA extends BaseRepository<Member, Integer>, JpaSpecificationExecutor<Member> {
    // Member findByMktIdAndMobi(Integer mktId, String mobi);
    Member findByCustomerId(Integer customerId);

    public List<Member> findByMktId(Integer mktId);


    Member findByNo(String no);

    List<Member> findByIdIn(Integer[] memberIds);



}
