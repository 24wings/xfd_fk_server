package com.fastsun.market.jpa;

import com.fastsun.market.entity.common.OssFile;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface OssFileJPA extends BaseRepository<OssFile,Integer> ,JpaSpecificationExecutor<OssFile> {

    List<OssFile> findByFileName(String fileName);
}
