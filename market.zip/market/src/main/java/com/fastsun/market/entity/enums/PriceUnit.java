package com.fastsun.market.entity.enums;

public enum PriceUnit {
    KG, JIN;

}
