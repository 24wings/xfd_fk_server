package com.fastsun.market.bean;

import com.fastsun.market.entity.common.ProdCatalog;
import com.fastsun.market.entity.common.Product;
import com.fastsun.market.entity.common.TransArea;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import java.util.List;


public class ProcatalogInfo {
    private Integer id;
    private String catName;
    private Integer parentId;
    private Boolean isShow;
    private String catCode;
    private Integer txnId;
    private TransArea txn;

    private Integer mktId;
    private Integer linkId;
    public  Product products;
//    public ProdCatalog prodCatalog;
    public TransArea getTxn() {
        return txn;
    }

    /**
     * @param txn the txn to set
     */
    public void setTxn(TransArea txn) {
        this.txn = txn;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    /**
     * @return the isShow
     */
    public Boolean getIsShow() {
        return isShow;
    }

    /**
     * @param parentId the parentId to set
     */
    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    /**
     * @return the parentId
     */
    public Integer getParentId() {
        return parentId;
    }

    public Boolean getShow() {
        return isShow;
    }

    public void setIsShow(Boolean isShow) {
        this.isShow = isShow;
    }

    public String getCatCode() {
        return catCode;
    }

    public void setCatCode(String catCode) {
        this.catCode = catCode;
    }

    public Integer getTxnId() {
        return txnId;
    }

    public void setTxnId(Integer txnId) {
        this.txnId = txnId;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Integer getLinkId() {
        return linkId;
    }

    public void setLinkId(Integer linkId) {
        this.linkId = linkId;
    }

    public void setShow(Boolean show) {
        isShow = show;
    }

}
