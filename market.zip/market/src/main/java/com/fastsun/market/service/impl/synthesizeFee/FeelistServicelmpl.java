package com.fastsun.market.service.impl.synthesizeFee;

import com.fastsun.market.entity.synthesizeFee.FeeList;
import com.fastsun.market.jpa.FeeListJPA;
import com.fastsun.framework.jpa.base.SimplePageBuilder;
import com.fastsun.framework.jpa.base.SimpleSpecificationBuilder;
import com.fastsun.framework.service.impl.BaseServiceImpl;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import javax.security.auth.Subject;

@Service
public class FeelistServicelmpl extends BaseServiceImpl<FeeList, Integer, FeeListJPA> {
    // 新增

    public FeeList saveFeelist(FeeList feelist) {
        return this.saveOne(feelist);
    }
    // 修改

    public FeeList updateFeelist(FeeList feelist) {
        return this.updateOne(feelist.getId(), feelist);
    }

    // 删除
    public void deleteFeelist(Integer feeListId) {
        this.deleteById(feeListId);
    }

    // 列表

    public Page<FeeList> findAll(Integer page, Integer pageSize, Integer mktId) {
        SimpleSpecificationBuilder ssb = null;

        if (ssb == null) {
            ssb = new SimpleSpecificationBuilder("mktId", "=", mktId);
            return this.baseRepository.findAll(ssb.generateSpecification(),
                    SimplePageBuilder.generate(page, pageSize, null));
        }
        ssb = ssb.add("mktId", "=", mktId);
        return this.baseRepository.findAll(ssb.generateSpecification(),
                SimplePageBuilder.generate(page, pageSize, null));
    }
    // 查询

    // public List<MemberARFee> queryAndfindAll(Integer mktId,Integer
    // subketId,Integer payFeeMemberId,Integer page, Integer pageSize){
    // SimpleSpecificationBuilder ssb = null;
    // if(ssb==null){
    // ssb=new SimpleSpecificationBuilder("mktId","=",mktId);
    // ssb=ssb.add("subketId","=",subketId);
    // ssb=ssb.add("payFeeMemberId","=",payFeeMemberId);
    // return (List<MemberARFee>)
    // this.baseRepository.findAll(ssb.generateSpecification(),SimplePageBuilder.generate(page,pageSize,null));
    //
    // }
    // ssb=new SimpleSpecificationBuilder("mktId","=",mktId);
    // ssb=ssb.add("subketId","=",subketId);
    // ssb=ssb.add("payFeeMemberId","=",payFeeMemberId);
    // return (List<MemberARFee>)
    // this.baseRepository.findAll(ssb.generateSpecification(),SimplePageBuilder.generate(page,pageSize,null));
    //
    // }

    public Long count(String name, Integer id) {
        SimpleSpecificationBuilder<Subject> ssb = new SimpleSpecificationBuilder("title", "=", name);
        ssb.addOr("id", "=", id);
        return this.baseRepository.count(ssb.generateSpecification());
    }

}
