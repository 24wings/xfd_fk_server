package com.fastsun.market.entity.synthesizeFee;

import javax.persistence.*;

import javax.persistence.ForeignKey;

import com.fasterxml.jackson.annotation.JsonBackReference;

import java.io.Serializable;

@Entity
@Table(name = "payfeeList")
public class PayFeeDetail implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer masterPayFeeId;
    private Integer memberARFeeId;


//    @JsonBackReference
//    @ManyToOne(fetch = FetchType.EAGER, optional = false)
//    @JoinColumn(name = "masterId", updatable = false, insertable = false)
//    private PayFee payFee;
//    @OneToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH }, fetch = FetchType.EAGER)
//    @JoinColumn(name = "memberARFeeId", updatable = false, insertable = false, foreignKey = @ForeignKey(name = "memberARFeeId", value = ConstraintMode.NO_CONSTRAINT))
//    private FeeList feeList;

    public PayFeeDetail() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMasterPayFeeId() {
        return masterPayFeeId;
    }

    public void setMasterPayFeeId(Integer masterPayFeeId) {
        this.masterPayFeeId = masterPayFeeId;
    }

    public Integer getMemberARFeeId() {
        return memberARFeeId;
    }

    public void setMemberARFeeId(Integer memberARFeeId) {
        this.memberARFeeId = memberARFeeId;
    }

//    public PayFee getPayFee() {
//        return payFee;
//    }
//
//    public void setPayFee(PayFee payFee) {
//        this.payFee = payFee;
//    }
//
//    public FeeList getFeeList() {
//        return feeList;
//    }
//
//    public void setFeeList(FeeList feeList) {
//        this.feeList = feeList;
//    }
}
