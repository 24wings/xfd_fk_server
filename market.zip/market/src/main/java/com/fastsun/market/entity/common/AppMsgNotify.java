package com.fastsun.market.entity.common;

import com.fastsun.market.entity.enums.CreateWay;
import com.fastsun.market.entity.enums.MsgType;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "b_msg_notify")
public class AppMsgNotify implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer mktId;// 所属市场id,为空时是平台级消息
    private Integer custId;// 发给app用户,为空时不限制Customer
    private Integer memberId;// 发给会员,为空时不限制会员
    @Column(nullable = false)
    @Enumerated(EnumType.ORDINAL)
    private MsgType msgType;// 消息类型
    @Column(nullable = false)
    private String title;// 消息摘要
    @Column(nullable = false)
    private String content;// 消息内容
    @Column(length = 4000)
    private String addition;// 附加内容
    private Date createTime;// 创建时间
    private Integer creatorId;// 创建人Id
    private String creator;// 创建人姓名
    private Boolean isRead = false;

    /**
     * @return the isRead
     */
    public Boolean getIsRead() {
        return isRead;
    }

    /**
     * @param isRead the isRead to set
     */
    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public AppMsgNotify() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Integer getCustId() {
        return custId;
    }

    public void setCustId(Integer custId) {
        this.custId = custId;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public MsgType getMsgType() {
        return msgType;
    }

    public void setMsgType(MsgType msgType) {
        this.msgType = msgType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAddition() {
        return addition;
    }

    public void setAddition(String addition) {
        this.addition = addition;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
}