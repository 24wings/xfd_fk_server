package com.fastsun.market.entity.member;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fastsun.market.entity.enums.AccountStatus;
import com.fastsun.market.entity.enums.CommonStatusEnum;
import com.fastsun.market.entity.enums.CustCardStatus;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" })
@Table(name = "b_cust_card", uniqueConstraints = { @UniqueConstraint(columnNames = "no")})
@Entity
public class CustCard implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String no;
    @Enumerated(EnumType.ORDINAL)
    private CommonStatusEnum status;
    private Integer mktId;//所属市场id
    private Date createTime;//创建时间
    private Integer creatorId;//创建人id
    private String creator;//创建人

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public CommonStatusEnum getStatus() {
        return status;
    }

    public void setStatus(CommonStatusEnum status) {
        this.status = status;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public CustCard() {
    }
}
