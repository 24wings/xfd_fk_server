package com.fastsun.market.controller.app;

import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.CustomeStringUtils;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.member.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.fastsun.market.jpa.*;
import com.fastsun.market.entity.common.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.*;
import com.fastsun.market.MarketApi.MessageApi;;

@Api(description = "消息管理", tags = { "market.app.Message" })
@RestController("appMessageController")
@RequestMapping(MessageApi.PREFIX)
public class MessageController extends BaseController {
    @Autowired
    AppMsgNotifyJPA appMsgNotifyJPA;
    @Autowired
    SMSLogJPA smsLogJPA;
    @Autowired
    CustomerJPA customerJPA;
    @Autowired
    CommonEntityService commonEntityService;
    private ResponseBean responseBean;

    @ApiOperation(value = "", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/msgTypeQuery", method = RequestMethod.GET)
    public ResponseBean msgTypeQuery(@RequestParam Integer customerId , @RequestParam Integer mktId){
        Customer customer = customerJPA.findByMktIdAndAndId(mktId,customerId);
        String disabledMsgTypes = customer.getDisabledMsgTypes();
        responseBean = ResponseUtil.createRespBean(true,200,"");
        if(disabledMsgTypes != "" && disabledMsgTypes != null){
            responseBean.getData().put("MsgTypes",disabledMsgTypes);
        }
        return responseBean;
    }

    @ApiOperation(value = "消息管理", notes = "", httpMethod = "GET")
    @RequestMapping(value = MessageApi.msgManage, method = RequestMethod.GET)
    public ResponseBean msgManage(@RequestParam Integer customerId, @RequestParam Integer mktId, @RequestParam List<String> messageSetting) {
        Customer customer = customerJPA.findByMktIdAndAndId(mktId,customerId);
        if (customer != null) {
            String msgTypes = CustomeStringUtils.listToString(messageSetting);
            if(msgTypes != "" && msgTypes != null)
            {
                customer.setDisabledMsgTypes(msgTypes);
                customerJPA.saveAndFlush(customer);
            }
            return ResponseUtil.createRespBean(true, 200, "保存成功");
        } else {

            return ResponseUtil.createRespBean(false, 400, "不存在的用户");

        }
    }

    @ApiOperation(value = "查询消息", notes = "", httpMethod = "POST")
    @RequestMapping(value = MessageApi.msgQuery, method = RequestMethod.POST)
    public ResponseBean msgQuery(@RequestBody QueryParameter queryParameter) {
        Paging paging = this.commonEntityService.findPagedEntity(queryParameter,AppMsgNotify.class);
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
        success.getData().put("msgs", paging);
        return success;
    }

    @ApiOperation(value = "消息详情", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/detail", method = RequestMethod.GET)
    public ResponseBean msgDetail(@RequestParam Integer msgId){
        AppMsgNotify appMsgNotify = this.appMsgNotifyJPA.findById(msgId).get();
        responseBean = ResponseUtil.createRespBean(true,200,"");
        responseBean.getData().put("appMsgNotify",appMsgNotify);
        return responseBean;
    }

    @ApiOperation(value = "消息已读确认", notes = "", httpMethod = "GET")
    @RequestMapping(value = MessageApi.msgChecked, method = RequestMethod.GET)
    public ResponseBean msgChecked(@RequestParam Integer messageId, @RequestParam Integer customerId) {
        Customer customer = customerJPA.findById(customerId).get();
        AppMsgNotify message = appMsgNotifyJPA.findById(messageId).get();
        if (customer != null && message != null) {
            if (message.getCustId().equals(customerId)) {
                message.setIsRead(true);
                appMsgNotifyJPA.saveAndFlush(message);

                ResponseBean success = ResponseUtil.createRespBean(true, 200, "已读成功");
                return success;
            } else {
                return ResponseUtil.createRespBean(false, 400, "已读失败");
            }
        } else {
            return ResponseUtil.createRespBean(false, 400, "找不到消息或人");
        }

    }

}
