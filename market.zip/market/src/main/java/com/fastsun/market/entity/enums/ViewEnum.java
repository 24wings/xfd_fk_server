package com.fastsun.market.entity.enums;

public enum ViewEnum {
    MemberInvite, Order
}
