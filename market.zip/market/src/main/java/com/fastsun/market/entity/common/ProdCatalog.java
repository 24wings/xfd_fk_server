package com.fastsun.market.entity.common;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.*;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "b_product_cat", uniqueConstraints = { @UniqueConstraint(columnNames = { "catName", "catCode" }) })
public class ProdCatalog implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false, length = 20)
    private String catName;
    private Integer parentId;
    private Boolean isShow;
    @Column(nullable = false, length = 15)
    private String catCode;
    private Integer txnId;
    @Transient
    private String pingYinName;
    @Transient
    private String nameFirst;
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "txnId", insertable = false, updatable = false)
    private TransArea txn;
    private Integer mktId = 0;
    private Integer linkId;

    @OneToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER,mappedBy = "prodCatalog",orphanRemoval = true)
    private List<Product> products;


    public String getPingYinName() {
        return pingYinName;
    }

    public void setPingYinName(String pingYinName) {
        this.pingYinName = pingYinName;
    }

    public String getNameFirst() {
        return nameFirst;
    }

    public void setNameFirst(String nameFirst) {
        this.nameFirst = nameFirst;
    }

    /**
     * @return the txn
     */
    public TransArea getTxn() {
        return txn;
    }

    /**
     * @param txn the txn to set
     */
    public void setTxn(TransArea txn) {
        this.txn = txn;
    }

    public ProdCatalog() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    /**
     * @return the isShow
     */
    public Boolean getIsShow() {
        return isShow;
    }

    /**
     * @param parentId the parentId to set
     */
    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    /**
     * @return the parentId
     */
    public Integer getParentId() {
        return parentId;
    }

    public Boolean getShow() {
        return isShow;
    }

    public void setIsShow(Boolean isShow) {
        this.isShow = isShow;
    }

    public String getCatCode() {
        return catCode;
    }

    public void setCatCode(String catCode) {
        this.catCode = catCode;
    }

    public Integer getTxnId() {
        return txnId;
    }

    public void setTxnId(Integer txnId) {
        this.txnId = txnId;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Integer getLinkId() {
        return linkId;
    }

    public void setLinkId(Integer linkId) {
        this.linkId = linkId;
    }

    public void setShow(Boolean show) {
        isShow = show;
    }

    public List<Product> getProducts() {
        return products;
    }
    @JsonProperty
    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public void addProduct(Product product){
        if(!products.contains(product)){
           product.setProdCatalog(this);
           this.products.add(product);
        }
    }
}
