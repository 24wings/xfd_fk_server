package com.fastsun.market.jpa;

import com.fastsun.market.entity.synthesizeFee.FeeList;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface FeeListJPA extends BaseRepository<FeeList, Integer>, JpaSpecificationExecutor<FeeList> {
    List<FeeList> findByIdIn(Integer[] feeListIds);

}
