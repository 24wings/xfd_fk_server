package com.fastsun.market.entity.enums;

public enum OrderType {
    TRANS,RENTS
}
