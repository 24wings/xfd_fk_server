package com.fastsun.market.service.impl;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.market.entity.common.AppMsgNotify;
import com.fastsun.market.entity.enums.MemberInviteStatusEnum;
import com.fastsun.market.entity.enums.MsgType;
import com.fastsun.market.entity.enums.ViewEnum;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.entity.member.MemberInvite;
import com.fastsun.market.jpa.CustomerJPA;
import com.fastsun.market.jpa.MemberInviteJPA;
import com.fastsun.market.jpa.MemberJPA;
import com.fastsun.market.service.impl.common.MsgServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class TeamServiceImpl
{
    @Autowired
    private CustomerJPA customerJPA;

    @Autowired
    private MemberInviteJPA memberInviteJPA;

    @Autowired
    private JPushServiceImpl jpushServiceImpl;

    @Autowired
    private MemberJPA memberJPA;

    @Autowired
    private MemberServiceImpl memberServiceImpl;

    @Autowired
    private MsgServiceImpl msgService;


    public boolean inviteCustomer(MemberInvite memberInvite)throws Exception
    {
        if(this.customerJPA.findById(memberInvite.getSendCustId()).isPresent()
                && customerJPA.findById(memberInvite.getRecvCustId()).isPresent())
        {
            Customer recvCustomer = this.customerJPA.findById(memberInvite.getRecvCustId()).get();
            Customer sendCustomer = this.customerJPA.findById(memberInvite.getSendCustId()).get();
            Integer memberId = recvCustomer.getMemberId();
            Integer sendMemberId = sendCustomer.getMemberId();
            if(memberId == null)
            {
                memberInvite.setRecvCusName(recvCustomer.getName());
                memberInvite.setSendCusName(sendCustomer.getName());
                memberInvite.setStatus(MemberInviteStatusEnum.Active);
                memberInvite.setMemberId(sendMemberId);
                memberInvite.setConfirmed(false);
                memberInvite = this.memberInviteJPA.saveAndFlush(memberInvite);
                String content = "尊敬的用户，"+sendCustomer.getName() + "邀请你加入团队,";
                if(!msgService.checkDisabledMsgTypes(memberInvite.getRecvCustId(),MsgType.CUST_INVITE)) {
                    AppMsgNotify appMsgNotify = this.memberServiceImpl.createAppMsgNotify(null, null, memberInvite, "收到邀请，加入团队！",
                            MsgType.CUST_INVITE,content);
                    String registrationId = recvCustomer.getRegistrationId();
                    Map<String, String> extral = new HashMap<String, String>();
                    extral.put("view", ViewEnum.MemberInvite.toString());
                    extral.put("memberInviteId", memberInvite.getId().toString());
                    extral.put("appMsgNotifyId",appMsgNotify.getId().toString());
                    this.jpushServiceImpl.sendRegistrationIdNotify(content, registrationId, extral);
                }
                return true;
            }
            else
            {
                return false;

            }
        }
        else
        {
            return false;
        }

    }

    public boolean acceptInvite(Integer inviteLogId,Integer customerId) throws Exception
    {
        MemberInvite memberInvite = this.memberInviteJPA.findById(inviteLogId).get();
        Customer recvCustomer = this.customerJPA.findById(customerId).get();
        if (recvCustomer != null && memberInvite != null && memberInvite.getRecvCustId() == customerId)
        {
            if (recvCustomer.getMember() == null)
            {
                Customer sendCustomer = this.customerJPA.findById(memberInvite.getSendCustId()).get();
                recvCustomer.setMemberId(sendCustomer.getMemberId());
                memberInvite.setStatus(MemberInviteStatusEnum.Agree);
                memberInvite.setConfirmTime(new Date());
                memberInvite.setConfirmed(true);
                this.customerJPA.saveAndFlush(recvCustomer);
                this.memberInviteJPA.saveAndFlush(memberInvite);
                String content ="尊敬的用户，"+memberInvite.getRecvCusName()+"已加入团队,点击查看！";
                if(!msgService.checkDisabledMsgTypes(memberInvite.getRecvCustId(),MsgType.ACTOR_CHANGE)) {
                    AppMsgNotify appMsgNotify = this.memberServiceImpl.createAppMsgNotify(null, null, memberInvite, "操作员变动！",
                            MsgType.ACTOR_CHANGE,content);
                    String registrationId = sendCustomer.getRegistrationId();
                    Map<String, String> extral = new HashMap<String, String>();
                    extral.put("view", ViewEnum.MemberInvite.toString());
                    extral.put("memberInviteId", memberInvite.getId().toString());
                    extral.put("appMsgNotifyId",appMsgNotify.getId().toString());
                    this.jpushServiceImpl.sendRegistrationIdNotify(content, registrationId, extral);
                }
               return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    public boolean refuseInvite(Integer customerId, Integer mktId, Integer inviteLogId) throws Exception
    {
        MemberInvite invite = this.memberInviteJPA.findById(inviteLogId).get();
        if (invite != null)
        {
            invite.setConfirmed(false);
            invite.setStatus(MemberInviteStatusEnum.Refuse);
            this.memberInviteJPA.saveAndFlush(invite);
            Customer sendCustomer = this.customerJPA.findById(invite.getSendCustId()).get();
            String content ="尊敬的用户，"+invite.getRecvCusName()+"拒绝加入团队！";
            if(!msgService.checkDisabledMsgTypes(invite.getRecvCustId(),MsgType.ACTOR_CHANGE)) {
                AppMsgNotify appMsgNotify = this.memberServiceImpl.createAppMsgNotify(null, null, invite, "操作员变动！",
                        MsgType.ACTOR_CHANGE,content);
                String registrationId = sendCustomer.getRegistrationId();
                Map<String, String> extral = new HashMap<String, String>();
                extral.put("view", ViewEnum.MemberInvite.toString());
                extral.put("memberInviteId", invite.getId().toString());
                extral.put("appMsgNotifyId",appMsgNotify.getId().toString());
                this.jpushServiceImpl.sendRegistrationIdNotify(content, registrationId, extral);
            }
            return true;
        }
        else
        {
            return false;
        }
    }
}
