package com.fastsun.market.controller.app;

import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.utils.StatusMsgEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.fastsun.market.jpa.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import javax.servlet.http.HttpServletRequest;
import com.fastsun.market.service.impl.*;
import com.fastsun.market.MarketApi.CustomerApi;;

@RestController("appCustomerController")
@Api(description = "app 用户api", tags = { "market.app.Customer" })

@RequestMapping(CustomerApi.PREFIX)
public class CustomerController extends BaseController {
    @Autowired
    private CustomerJPA customerJPA;

    @Autowired
    private BCryptPasswordEncoder encoder;
    @Autowired
    private CustomerServiceImpl customerService;

    @ApiOperation(value = "更新设备id", notes = "", httpMethod = "GET")
    @RequestMapping(value = CustomerApi.updateRegistrationId, method = RequestMethod.GET)
    public ResponseBean updateRegistrationId(@RequestParam String registrationId, @RequestParam Integer customerId) {
        Customer customer = customerJPA.findById(customerId).get();
        if (customer != null) {
            customer.setRegistrationId(registrationId);
            customerJPA.saveAndFlush(customer);
            return ResponseUtil.createRespBean(true, 200, "用户更新成功");
        } else {
            return ResponseUtil.createRespBean(false, 400, "用户不存在");
        }

    }

    @ApiOperation(value = "忘记密码", notes = "", httpMethod = "GET")
    @RequestMapping(value = CustomerApi.findbyMobi, method = RequestMethod.GET)
    public ResponseBean findbyMobi(@RequestParam String phone, @RequestParam Integer mktId) {
        Customer customer = customerJPA.findByMktIdAndMobi(mktId, phone);
        ResponseBean res = ResponseUtil.createRespBean(true, 200, "成功");
        res.getData().put("customer", customer);
        return res;
    }

    @ApiOperation(value = "忘记密码", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public Paging test(@RequestParam String phone, @RequestParam Integer mktId) {
        Customer customer = customerJPA.findByMktIdAndMobi(mktId, phone);
        ResponseBean res = ResponseUtil.createRespBean(true, 200, "成功");
        res.getData().put("customer", customer);
        return null;
    }



    @ApiOperation(value = "app用户注册", notes = "", httpMethod = "POST")
    @RequestMapping(value = CustomerApi.signup, method = RequestMethod.POST)
    public ResponseBean singup(@RequestBody Customer newCustomer, @RequestParam String authcode) throws Exception {
        // return ResponseUtil.createRespBean(true, 200, newCustomer.getMobi() +
        // newCustomer.getMktId());
        Customer exsitCustomer = customerJPA.findByMktIdAndMobi(newCustomer.getMktId(), newCustomer.getMobi());

        if (exsitCustomer == null) {
            BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
            newCustomer.setPassword(encoder.encode(newCustomer.getPassword()));
            customerJPA.saveAndFlush(newCustomer);
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "");
            success.getData().put("customer", newCustomer);
            return success;
        } else {
            ResponseBean fail = ResponseUtil.createRespBean(false, StatusMsgEnum.PHONE_CUSTOMER_EXISIT.getStatus(),
                    StatusMsgEnum.PHONE_CUSTOMER_EXISIT.getMsg());
            fail.getData().put("customer", null);
            return fail;
        }
    }

    @ApiOperation(value = "app用户登陆", notes = "", httpMethod = "POST")
    @RequestMapping(value = CustomerApi.login, method = RequestMethod.POST)
    public com.fastsun.framework.bean.ResponseBean signin(@RequestBody Customer loginCustomer) {
        String password = loginCustomer.getPassword();

        loginCustomer = customerJPA.findByMktIdAndMobi(loginCustomer.getMktId(), loginCustomer.getMobi());
        if (loginCustomer != null) {

            if (password.equals(loginCustomer.getPassword())) {
                ResponseBean res = ResponseUtil.createRespBean(true, 200, "msg");
                res.getData().put("customer", loginCustomer);
                return res;
            } else {
                ResponseBean res = ResponseUtil.createRespBean(false, 403, "用户名或密码错误");
                return res;
            }
        } else {
            ResponseBean res = ResponseUtil.createRespBean(false, 403, "用户不存在");
            return res;
        }
    }

    private ResponseBean responseBean;

    @ApiOperation(value = "修改手机", notes = "", httpMethod = "GET")
    @GetMapping(value = CustomerApi.modifyPhone)
    public ResponseBean modifyPhone(@RequestParam String oldPhone, @RequestParam String newPhone,
            @RequestParam Integer customerId, @RequestParam String authCode, @RequestParam Integer mktId) {
        Customer exsitCustomer = this.customerJPA.findByMktIdAndMobi(mktId, newPhone);
        if (exsitCustomer == null) {
            Customer customer = customerJPA.findById(customerId).get();
            if (customer != null) {
                customer.setMobi(newPhone);
                this.customerJPA.saveAndFlush(customer);
                return ResponseUtil.createRespBean(true, 200, "成功");
            } else {
                return ResponseUtil.createRespBean(false, 400, "找不到修改手机的用户");
            }
        } else {
            return ResponseUtil.createRespBean(false, 400, "改手机号已经被占用");

        }

    }

    @PostMapping(value = "/relationCard")
    public ResponseBean relationCard(HttpServletRequest request, @RequestBody Customer customer) {
        Customer customerDB = null;
        try {
            customerDB = this.customerService.relationCard(request, customer);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(false, 201, e.getMessage());
            e.printStackTrace();
            return responseBean;
        }
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(), "关联成功！");
        responseBean.getData().put("customerDB", customerDB);
        return responseBean;
    }

    @ApiOperation(value = "用户详情", notes = "", httpMethod = "POST")
    @GetMapping(value = CustomerApi.customerDetail)
    public ResponseBean customerDetail(@RequestParam String mktId, @RequestParam Integer customerId) {
        Customer customer = this.customerJPA.findById(customerId).get();
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "成功返回信息");
        success.getData().put("customer", customer);
        return success;
    }

    @ApiOperation(value = "修改手机时确认密码", notes = "", httpMethod = "POST")
    @PostMapping(value = CustomerApi.authPassword)
    public ResponseBean authPassword(@RequestBody Customer authCustomer) {
        Customer customer = this.customerJPA.findById(authCustomer.getId()).get();
        if (customer != null) {
            if (encoder.matches(authCustomer.getPassword(),customer.getPassword())) {
                return ResponseUtil.createRespBean(true, 200, "正确");
            } else {
                return ResponseUtil.createRespBean(false, 400, "密码错误");
            }
        } else {
            return ResponseUtil.createRespBean(false, 400, "不存在的用户");
        }

    }
    @ApiOperation(value = "修改登陆密码",notes = "",httpMethod = "GET")
    @GetMapping(value = "/modifyPassword")
    public ResponseBean modifyPassword(String oldPassword, String newPassword, Integer customerId){
        Customer customer = null;
        try {
            customer = this.customerService.modifyPassword(oldPassword,newPassword,customerId);
        } catch (Exception e) {
            responseBean = ResponseUtil.createRespBean(false,201,e.getMessage());
            e.printStackTrace();
            return responseBean;
        }
        responseBean = ResponseUtil.createRespBean(true,200,"修改成功！");
        responseBean.getData().put("customer",customer);
        return  responseBean;
    }
    @GetMapping("/relieveCard")
    public ResponseBean relieveCard(String cardNo){
        Boolean flag = this.customerService.relieveCard(cardNo);
        responseBean = ResponseUtil.createRespBean(true,200,"解绑成功！");
        responseBean.getData().put("flag",flag);
        return responseBean;
    }
}
