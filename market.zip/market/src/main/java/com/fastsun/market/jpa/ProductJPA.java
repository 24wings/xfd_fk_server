package com.fastsun.market.jpa;

import com.fastsun.market.entity.common.Product;
import com.fastsun.market.entity.enums.ProductStatus;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface ProductJPA extends BaseRepository<Product, Integer>, JpaSpecificationExecutor<Product> {

    List<Product> findByMemberIdAndMktId(Integer memberId, Integer mktId);

    List<Product> findByMemberIdAndMktIdAndStatus(Integer memberId, Integer mktId, ProductStatus status);

    List<Product> findByMemberIdAndMktIdAndNameIsLike(Integer memberId, Integer mktId, String name);

}
