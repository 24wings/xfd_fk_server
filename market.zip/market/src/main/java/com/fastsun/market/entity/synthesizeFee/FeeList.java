package com.fastsun.market.entity.synthesizeFee;

import com.fastsun.market.entity.common.RecvPaySubject;
import com.fastsun.market.entity.member.Member;

import javax.persistence.*;
import javax.persistence.ForeignKey;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "b_member_ar")
public class FeeList implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String billNo;
    private String title;// 应收费用内容
    private Integer memberId;
    private Integer subjectId;
    private Date startDate;
    private Date endDate;
    private String status;
    private BigDecimal arAmount;
    private Integer mktId;// 所属市场id
    private Integer txnId;// 所属区域
    private Date createTime;// 创建时间
    private Integer creatorId;// 创建人Id
    private String creator;// 创建人

    @OneToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH }, fetch = FetchType.EAGER)
    @JoinColumn(name = "memberId", updatable = false, insertable = false, foreignKey = @ForeignKey(name = "memberId", value = ConstraintMode.NO_CONSTRAINT))
    private Member member;

    @OneToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.REFRESH }, fetch = FetchType.EAGER, targetEntity = RecvPaySubject.class)
    @JoinColumn(name = "subjectId", updatable = false, insertable = false, foreignKey = @ForeignKey(name = "subjectId", value = ConstraintMode.NO_CONSTRAINT))
    private RecvPaySubject recvPaySubject;

    public FeeList() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the arAmount
     */
    public BigDecimal getArAmount() {
        return arAmount;
    }

    /**
     * @param arAmount the arAmount to set
     */
    public void setArAmount(BigDecimal arAmount) {
        this.arAmount = arAmount;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Integer getTxnId() {
        return txnId;
    }

    public void setTxnId(Integer txnId) {
        this.txnId = txnId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public RecvPaySubject getRecvPaySubject() {
        return recvPaySubject;
    }

    public void setRecvPaySubject(RecvPaySubject recvPaySubject) {
        this.recvPaySubject = recvPaySubject;
    }
}
