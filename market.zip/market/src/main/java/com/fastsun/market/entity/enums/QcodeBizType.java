package com.fastsun.market.entity.enums;

public enum QcodeBizType {
    MEMBER(0,"成员信息"),TRANS_PAY(1,"交易支付"),TRANS_ACC(2,"转账收款"),QUERY_CREDIT(3,"查询欠款");

    private Integer key;
    private String value;

    QcodeBizType(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getkey() {
        return key;
    }
    public String getValue() {
        return value;
    }
}
