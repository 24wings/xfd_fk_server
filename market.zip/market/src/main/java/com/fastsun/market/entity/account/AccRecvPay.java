package com.fastsun.market.entity.account;

import com.fastsun.market.entity.enums.OrderType;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Table(name = "b_acc_recv_pay", uniqueConstraints = { @UniqueConstraint(columnNames = { "recvPayNo" }) })
@Entity
public class AccRecvPay implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @ApiModelProperty("收支流水号")
    private String recvPayNo; // 收支流水号
    private Integer accountId; // 账户Id
    private String accountName; // 账户Id
    private Integer toAccountId; // 对方账户Id
    private String toAccountName; // 对方账户名称

    private Integer io;// 收支方向
    private Integer subjectId; // 收支科目
    private String subjectName; // 收支科目
    private BigDecimal amount; // 收支金额
    private BigDecimal balAmt; // 账户余额(可用金额+未结算金额)
    private BigDecimal availAmt; // 可用金额
    private BigDecimal frozenAmt; // 冻结金额
    @Enumerated(EnumType.ORDINAL)
    private OrderType orderType; // 订单类型
    private String orderNo; // 订单编号
    private String remark; // 备注
    private Date createTime; // 创建时间
    private Integer mktId;// 所属市场id

    /**
     * @return the accountName
     */
    public String getAccountName() {
        return accountName;
    }

    /**
     * @return the toAccountName
     */
    public String getToAccountName() {
        return toAccountName;
    }

    /**
     * @param accountName the accountName to set
     */
    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    /**
     * @param toAccountName the toAccountName to set
     */
    public void setToAccountName(String toAccountName) {
        this.toAccountName = toAccountName;
    }

    public AccRecvPay() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRecvPayNo() {
        return recvPayNo;
    }

    public void setRecvPayNo(String recvPayNo) {
        this.recvPayNo = recvPayNo;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Integer getToAccountId() {
        return toAccountId;
    }

    public void setToAccountId(Integer toAccountId) {
        this.toAccountId = toAccountId;
    }

    public Integer getIo() {
        return io;
    }

    public void setIo(Integer io) {
        this.io = io;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public void setOrderType(OrderType orderType) {
        this.orderType = orderType;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public BigDecimal getBalAmt() {
        return balAmt;
    }

    public void setBalAmt(BigDecimal balAmt) {
        this.balAmt = balAmt;
    }

    public BigDecimal getAvailAmt() {
        return availAmt;
    }

    public void setAvailAmt(BigDecimal availAmt) {
        this.availAmt = availAmt;
    }

    public BigDecimal getFrozenAmt() {
        return frozenAmt;
    }

    public void setFrozenAmt(BigDecimal frozenAmt) {
        this.frozenAmt = frozenAmt;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }
}