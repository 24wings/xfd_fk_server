package com.fastsun.market.service.impl;

import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.market.entity.common.AppMsgNotify;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@Service
public class AppMsgNotifyServiceImpl {
    @Autowired
    RequestUtil requestUtil;

    public AppMsgNotify createAppMsgNotity(HttpServletRequest request,AppMsgNotify appMsgNotify){
        if(appMsgNotify == null){
            appMsgNotify = new AppMsgNotify();
        }
        appMsgNotify.setCreateTime(new Date());
        requestUtil.setCreatorAndCreatorId(appMsgNotify,requestUtil.getLoginUser(request));

        return appMsgNotify;
    }
}
