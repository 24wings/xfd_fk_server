package com.fastsun.market.entity.common;


import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "b_recv_pay_subject", uniqueConstraints = {@UniqueConstraint(columnNames={"subjectName", "subjectCode"})})
public class RecvPaySubject implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer subjectId;
    @Column(nullable = false,length = 40)
    private String subjectName;
    private Integer parentId;
    @Column(nullable = false,length = 11)
    private String subjectCode;
    private Integer subjectLinkId;
    private Integer mktId=0;

    public RecvPaySubject() { }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public Integer getSubjectLinkId() {
        return subjectLinkId;
    }

    public void setSubjectLinkId(Integer subjectLinkId) {
        this.subjectLinkId = subjectLinkId;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }
}
