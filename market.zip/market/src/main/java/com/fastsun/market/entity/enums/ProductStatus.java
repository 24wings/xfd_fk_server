package com.fastsun.market.entity.enums;

public enum ProductStatus {
    Active, Disabled, Del;

}
