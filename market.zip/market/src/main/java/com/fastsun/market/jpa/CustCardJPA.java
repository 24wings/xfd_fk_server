package com.fastsun.market.jpa;

import com.fastsun.market.entity.member.CustCard;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface CustCardJPA extends BaseRepository<CustCard,Integer>,JpaSpecificationExecutor<CustCard> {
    CustCard findByNo(String cardNo);
    //List<Card> findByCustomerId(Integer customerId);
}
