package com.fastsun.market.service.impl;

import cn.jpush.api.push.PushResult;

import java.util.Map;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.utils.ResponseUtil;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

//import cn.jmessage.api.JMessageClient;
import cn.jpush.api.*;
import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;

//import java.util.List;
@Service
public class JPushServiceImpl {
        @Value("${jpush.masterSecret}")
        private String masterSecret;
        @Value("${jpush.appKey}")
        private String appKey;
//        JPushClient client = new JPushClient("4224dcca3494ab5279be4705", "35f14808673591baceed2d61");

        public PushResult sendRegistrationIdNotify(String content, String registrationId, Map<String, String> extral)
                        throws Exception {
                JPushClient client = new JPushClient(masterSecret, appKey);
                IosNotification iosNotification = IosNotification.newBuilder().setAlert(content).setBadge(5)
                                .setSound("happy").addExtras(extral).build();
                AndroidNotification androidNotification = AndroidNotification.newBuilder().setAlert(content)
                                .addExtras(extral).build();
                PushPayload payload = PushPayload.newBuilder().setPlatform(Platform.all())
                                .setNotification(Notification.newBuilder().addPlatformNotification(iosNotification)
                                                .addPlatformNotification(androidNotification).build())
                                .setAudience(Audience.registrationId(registrationId))
                                .setMessage(Message.content(content)).build();
                // Message
                return client.sendPush(payload);

        }

        public static PushPayload buildPushObject_all_all_alert() {
                return PushPayload.alertAll("alert");
        }

}