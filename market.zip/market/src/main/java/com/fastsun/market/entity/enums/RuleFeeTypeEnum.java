package com.fastsun.market.entity.enums;

public enum RuleFeeTypeEnum {
    BIZ_AMT, BIZ_WEIGHT;
}