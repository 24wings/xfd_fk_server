package com.fastsun.market.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fastsun.framework.bean.MemberAccTuple;
import com.fastsun.framework.bean.UserAccTuple;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.service.impl.OrderNoServiceImpl;
import com.fastsun.framework.utils.CreatePrintJsonUtils;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.market.entity.account.Account;
import com.fastsun.market.entity.enums.AccountStatus;
import com.fastsun.market.entity.enums.CommonStatusEnum;
import com.fastsun.market.entity.enums.PayType;
import com.fastsun.market.entity.enums.SubjectCodeEnum;
import com.fastsun.market.entity.member.RechargeWithDraw;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.jpa.AccRecvPayJPA;
import com.fastsun.market.jpa.MemberJPA;
import com.fastsun.market.jpa.RechargeWithDrawJPA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class RechargeWithDrawServiceImpl {

    @Autowired
    private CustomerServiceImpl customerServiceImpl;
    @Autowired
    private MemberServiceImpl memberServiceImpl;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    RequestUtil requestUtil;
    @Autowired
    OrderServiceImpl orderService;
    @Autowired
    OrderNoServiceImpl orderNoService;
    @Autowired
    AccRecvPayJPA accRecvPayJPA;
    @Autowired
    RechargeWithDrawJPA rechargeWithDrawJPA;
    @Autowired
    private MemberJPA memberJPA;
    /*
     * 充值时，先通过卡号找到会员和会员的现金账户，查找员工和员工的现金账户
     *  判断状态，写员工和会员的现金账户的收支
     *  改会员现金账户和员工现金账户余额
     */
    @Transactional(rollbackFor = {RuntimeException.class,Exception.class},propagation = Propagation.NOT_SUPPORTED)
    public RechargeWithDraw saveRechargeInfo(HttpServletRequest request,RechargeWithDraw rechargeWithDraw) throws Exception {
        MemberAccTuple<Member,Account> memberAccTuple = this.customerServiceImpl.findByCardNo(rechargeWithDraw.getCardNo());
        if(!CommonStatusEnum.ENABLE.equals(memberAccTuple.first.getStatus())){
            throw new Exception("会员状态异常！");
        }
        //获取充值提现的订单号
        rechargeWithDraw.setBillNo("R0001"+String.format("%05d",this.orderNoService.getOrderNo("rechargeBillNo")));
        rechargeWithDraw.setMemberId(memberAccTuple.first.getId());
        rechargeWithDraw.setMemberName(memberAccTuple.first.getName());
        rechargeWithDraw.setIdCardNo(memberAccTuple.first.getIdCardNo());
        rechargeWithDraw.setCreateTime(new Date());
        this.requestUtil.setCreatorAndCreatorId(rechargeWithDraw,this.requestUtil.getLoginUser(request));
        if(rechargeWithDraw.getPayType().equals(PayType.CASH)){
            UserAccTuple<User,Account> userAccTuple = this.memberServiceImpl.findByUserId(rechargeWithDraw.getCreatorId());
            this.orderService.createAccRecvPayAndSave(userAccTuple.second,null,null,1,rechargeWithDraw.getBillNo(),rechargeWithDraw.getAmount(),null,null,null);
            this.orderService.createAccRecvPayAndSave(memberAccTuple.second,memberAccTuple.first,null,1,rechargeWithDraw.getBillNo(),rechargeWithDraw.getAmount(),null,SubjectCodeEnum.SERVICE_RECHARGE.getId(),SubjectCodeEnum.SERVICE_RECHARGE.getName());
        }else{
            this.orderService.createAccRecvPayAndSave(memberAccTuple.second,memberAccTuple.first,null,1,rechargeWithDraw.getBillNo(),rechargeWithDraw.getAmount(),null,SubjectCodeEnum.SERVICE_RECHARGE.getId(),SubjectCodeEnum.SERVICE_RECHARGE.getName());
        }
        return this.rechargeWithDrawJPA.save(rechargeWithDraw);
    }
    @Transactional(rollbackFor = {RuntimeException.class,Exception.class},propagation = Propagation.NOT_SUPPORTED)
    public RechargeWithDraw saveWithDraw(HttpServletRequest request,RechargeWithDraw rechargeWithDraw) throws Exception {
        String cardNo = rechargeWithDraw.getCardNo();
        MemberAccTuple<Member,Account> memberAccTuple = this.customerServiceImpl.findByCardNo(cardNo);
        Member member = memberAccTuple.first;
        for(Customer customer : member.getCustomers()){
            if(customer.getId() == member.getCustomerId()){
                if(!cardNo.equals(customer.getCard().getNo())){
                    throw new Exception("非主卡不能提现！");
                }
            }
        }
        if(!CommonStatusEnum.ENABLE.equals(member.getStatus())){
            throw new Exception("会员状态异常！");
        }
        Integer count = member.getErrorCount();
        if(count == null) {
            count = 0;
        }
        if(count >= 10) {
            throw new Exception("错误次数超过10次，必须解锁!");
        }
        Boolean flag = passwordEncoder.matches(rechargeWithDraw.getPayPassword(),member.getPayPassword());
        if(!flag) {
            count++;
            member.setErrorCount(count);
            this.memberJPA.save(member);
            throw new Exception("支付密码错误！");
        }
        rechargeWithDraw.setBillNo("R0001"+String.format("%05d",this.orderNoService.getOrderNo("withDrawBillNo")));
        rechargeWithDraw.setMemberId(member.getId());
        rechargeWithDraw.setMemberName(member.getName());
        rechargeWithDraw.setIdCardNo(member.getIdCardNo());
        rechargeWithDraw.setCreateTime(new Date());
        this.requestUtil.setCreatorAndCreatorId(rechargeWithDraw,this.requestUtil.getLoginUser(request));
        UserAccTuple<User,Account> userAccTuple = this.memberServiceImpl.findByUserId(rechargeWithDraw.getCreatorId());
        this.orderService.createAccRecvPayAndSave(userAccTuple.second,null,null,-1,rechargeWithDraw.getBillNo(),rechargeWithDraw.getAmount(),null,SubjectCodeEnum.SERVICE_WITHDRAW.getId(),SubjectCodeEnum.SERVICE_WITHDRAW.getName());
        this.orderService.createAccRecvPayAndSave(memberAccTuple.second,memberAccTuple.first,null,-1,rechargeWithDraw.getBillNo(),rechargeWithDraw.getAmount(),null,SubjectCodeEnum.SERVICE_WITHDRAW.getId(),SubjectCodeEnum.SERVICE_WITHDRAW.getName());
        rechargeWithDraw = this.rechargeWithDrawJPA.save(rechargeWithDraw);
        return rechargeWithDraw;
    }

    public String createRechargePrintStr(RechargeWithDraw rechargeWithDraw){
        if(rechargeWithDraw.getBusinessType().equals(RechargeWithDraw.BusinessType.RECHARGE)){
            String[] masterFields = {"操作员","充值方式"};
            String[] detailFields = {"凭单号","卡号","姓名","证件号码","充值金额","余额"};
            String[] dataIndex = {"billNo","cardNo","memberName","idCardNo","amount","afterBalAmt"};
            List<RechargeWithDraw> rechargeWithDraws = new ArrayList<>();
            rechargeWithDraws.add(rechargeWithDraw);
            List<JSONObject> masterData = new ArrayList<JSONObject>();
            JSONObject obj1 = new JSONObject();
            obj1.put("Field0",rechargeWithDraw.getCreator());
            obj1.put("Field1",rechargeWithDraw.getPayType());
            masterData.add(obj1);
            List<JSONObject> detailData = CreatePrintJsonUtils.createDetailData(JSON.toJSONString(rechargeWithDraws),masterFields.length,detailFields,dataIndex);
            return CreatePrintJsonUtils.createPrintStr(masterFields,detailFields,masterData,detailData);
        }else if(rechargeWithDraw.getBusinessType().equals(RechargeWithDraw.BusinessType.WITHDRAW)){

        }
        return null;
    }

    public RechargeWithDraw getDetail(Integer id){
        return  this.rechargeWithDrawJPA.findById(id).get();
    }
}
