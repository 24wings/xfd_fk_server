package com.fastsun.market.entity.enums;

import io.swagger.annotations.ApiModel;

@ApiModel("common_status")
public enum CommonStatusEnum {
    ENABLE(0,"可用"), DISABLE(1,"停用"), FROZEN(2,"冻结"), CANCEL(3,"注销");
    private Integer key;
    private String value;

    CommonStatusEnum(Integer key,String value) {
        this.key = key;
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
