package com.fastsun.market.service.impl.common;

import com.fastsun.framework.entity.rbac.Market;
import com.fastsun.market.entity.common.AppMsgNotify;
import com.fastsun.market.entity.common.SMSLog;
import com.fastsun.market.entity.enums.MsgType;
import com.fastsun.market.entity.enums.ViewEnum;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.MemberInvite;
import com.fastsun.framework.jpa.MarketJPA;
import com.fastsun.market.jpa.AppMsgNotifyJPA;
import com.fastsun.market.jpa.CustomerJPA;
import com.fastsun.market.jpa.SMSLogJPA;
import com.fastsun.market.service.impl.JPushServiceImpl;
import com.fastsun.framework.service.impl.BaseServiceImpl;
import com.fastsun.framework.service.impl.OrderNoServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.aliyuncs.dysmsapi.model.v20170525.QuerySendDetailsResponse;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.dysmsapi.model.v20170525.QuerySendDetailsResponse.SmsSendDetailDTO;

@Service
public class MsgServiceImpl extends BaseServiceImpl<AppMsgNotify, Integer, AppMsgNotifyJPA> {

    @Autowired
    private SmsServiceImpl smsService;
    @Autowired
    private MarketJPA marketJPA;

    @Autowired
    private SMSLogJPA msgJPA;
    @Autowired
    private JPushServiceImpl jpushServiceImpl;
    @Autowired
    private AppMsgNotifyJPA appMsgNotifyJPA;
    @Autowired
    private CustomerJPA customerJPA;

    // @Autowired
    // private OrderNoServiceImpl orderNoServiceImpl;
    public SMSLog getMarketPhoneLastAuthcode(String phone, Integer mktId) {
        return null;// this.msgJPA.findFirstByPhoneAndMktIdAndTypeOrderBySendTimeDesc(phone, mktId,
                    // "authcode");

    }

    /**
     * 邀请customer 推送消息
     */
    public void inviteCustomerAppNotify(MemberInvite memberInvite, String content, String registrationId)
            throws Exception {
        if(!checkDisabledMsgTypes(memberInvite.getRecvCustId(),MsgType.CUST_INVITE)) {
            AppMsgNotify msg = new AppMsgNotify();
            msg.setCustId(memberInvite.getRecvCustId());
            // msg.setIsRead(isRead);
            msg.setIsRead(false);
            msg.setMsgType(MsgType.CUST_INVITE);
            msg.setTitle("收到邀请,加入团队");
            appMsgNotifyJPA.saveAndFlush(msg);
            Map<String, String> extral = new HashMap<String, String>();
            extral.put("view", ViewEnum.MemberInvite.toString());
            extral.put("memberInviteId", memberInvite.getId().toString());
            this.jpushServiceImpl.sendRegistrationIdNotify(content, registrationId, extral);
        }
    }

    public SendSmsResponse sendAppAuthcode(String phone, Integer mktId, String verifyType) throws Exception {
        SendSmsResponse response = null;
        String randomCode = this.getRandomCode(6);
        String status = this.checktMarketBalanceStatus(mktId);
        if (status.equals("success") || status.equals("warning")) {
            response = this.smsService.senAppSignupAuthcode(phone,
                    "{\"time\":\" " + randomCode + "\", \"address\":\"123\"}");
            this.costMarketBalance(mktId);
        }
        if (status.equals("warning") || status.equals("fail")) {
            this.addMarketWarningMsg("短信费用不足", "短信费用不足", mktId);
        }
        if (response != null) {
            String code = response.getCode();
            String bizId = response.getBizId();
            if (code.toLowerCase().equals("ok")) {
                this.addMsgContent(phone, bizId, randomCode, "authcode", mktId, verifyType);
            }
        } else {
            return response;
        }
        return response;

    }

    /**
     * 自动计费,报警
     * 
     * 返回 * success 成功 * warning 成功但警报 * fail 失败,警报
     */
    private String checktMarketBalanceStatus(Integer mktId) {

        Market market = marketJPA.findById(mktId).get();
        if (market.balance.compareTo(new BigDecimal(100)) > 0) {
            return "success";
        } else if (market.balance.compareTo(new BigDecimal(100)) <= 0
                && market.balance.compareTo(new BigDecimal(0)) > 0) {
            return "warning";
        } else {
            return "fail";
        }

    }

    private boolean addMsgContent(String phone, String bizId, String addtion, String type, Integer mktId,
            String verifyType) throws Exception {
        QuerySendDetailsResponse querySendDetailResponse = this.smsService.querySendDetails(phone, bizId);
        SmsSendDetailDTO detail = querySendDetailResponse.getSmsSendDetailDTOs().get(0);
        String content = detail.getContent();
        SMSLog newMsg = new SMSLog();
        newMsg.setMobi(phone);
        newMsg.setContent(content);
        newMsg.setIsVerifySms(true);
        newMsg.setVerifyCode(addtion);
        newMsg.setVerifyType(verifyType);
        this.msgJPA.saveAndFlush(newMsg);
        return true;
    }

    private boolean addMarketWarningMsg(String title, String content, Integer mktId) {

        return true;
    }

    private boolean costMarketBalance(Integer mktId) {
        Market market = marketJPA.findById(mktId).get();
        market.balance = market.balance.subtract(new BigDecimal(0.05));
        marketJPA.saveAndFlush(market);
        return true;
    }

    private String getRandomCode(int strLength) {
        String captha = "";
        int[] numbers = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        Random random = new Random();
        for (int i = 0; i < strLength; i++) {
            int index = random.nextInt(10000);
            captha += numbers[index % 10];
        }
        return captha;
    }

    public Boolean checkDisabledMsgTypes(Integer customerId, MsgType msgType) {
        Customer customer = customerJPA.findById(customerId).get();
        return this.checkDisabledMsgTypes(customer,msgType);
    }

    public Boolean checkDisabledMsgTypes(Customer customer,MsgType msgType){
        String DisabledMsgTypes = customer.getDisabledMsgTypes();
        if(DisabledMsgTypes != "" && DisabledMsgTypes != null) {
            String[] DisabledMsgTypeList = DisabledMsgTypes.split(",");
            for (int i = 0; i <DisabledMsgTypeList.length ; i++) {
                String DisabledMsgType = DisabledMsgTypeList[i];
                if(DisabledMsgType.equals(msgType.toString())) {
                    return true;
                }
            }
        }
        return false;
    }
}