package com.fastsun.market.controller.app;


import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.utils.StatusMsgEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.fastsun.market.service.impl.common.MsgServiceImpl;
import com.fastsun.market.service.impl.common.SmsServiceImpl;
import com.fastsun.market.bean.*;
import com.fastsun.market.jpa.*;
import com.fastsun.framework.jpa.*;
import com.fastsun.market.entity.common.*;
import com.fastsun.market.entity.enums.MemberInviteStatusEnum;
import com.fastsun.framework.entity.rbac.*;
import com.fastsun.market.entity.member.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import javax.validation.Valid;
import java.util.*;
import com.fastsun.market.service.impl.*;
import com.fastsun.market.MarketApi.TeamApi;

@RestController("appTeamController")
@Api(description = "团队api", tags = { "market.app.Team" })
@RequestMapping(TeamApi.PREFIX)
public class TeamController extends BaseController {
    @Autowired
    MemberInviteJPA memberInviteJPA;
    @Autowired
    MemberJPA memberJPA;
    @Autowired
    CustomerJPA customerJPA;
    @Autowired
    MsgServiceImpl msgServiceImpl;
    @Autowired
    TeamServiceImpl teamService;

    @ApiOperation(value = "接受团队邀请`", notes = "", httpMethod = "GET")
    @RequestMapping(value = TeamApi.acceptInvite, method = RequestMethod.GET)
    public ResponseBean acceptInvite(@RequestParam Integer inviteLogId, @RequestParam Integer customerId) throws Exception {
//        MemberInvite memberInvite = memberInviteJPA.findById(inviteLogId).get();
//        Customer recvCustomer = customerJPA.findById(customerId).get();
//        if (recvCustomer != null && memberInvite != null && memberInvite.getRecvCustId() == customerId) {
//            if (recvCustomer.getMember() == null) {
//                Customer sendCustomer = customerJPA.findById(memberInvite.getSendCustId()).get();
//                recvCustomer.setMemberId(sendCustomer.getMemberId());
//                memberInvite.setStatus(MemberInviteStatusEnum.Agree);
//                memberInvite.setConfirmTime(new Date());
//                memberInvite.setConfirmed(true);
//                customerJPA.saveAndFlush(recvCustomer);
//                memberInviteJPA.saveAndFlush(memberInvite);
//                return ResponseUtil.createRespBean(true, 200, "接受成功");
//            } else {
//                return ResponseUtil.createRespBean(false, 400, "请先退出团队");
//            }
//        } else {
//            return ResponseUtil.createRespBean(false, 400, "用户或邀请不存在,或不是对你的邀请");
//        }
        boolean flag = this.teamService.acceptInvite(inviteLogId,customerId);
        if(flag)
        {
            return ResponseUtil.createRespBean(true, 200, "接受成功");
        }
        return ResponseUtil.createRespBean(false, 400, "用户或邀请不存在,或不是对你的邀请或已经加入其他团队请退出团队！");
    }

    @ApiOperation(value = "修改员工队伍备注`", notes = "", httpMethod = "GET")
    @RequestMapping(value = TeamApi.commmentCustomer, method = RequestMethod.GET)
    public ResponseBean commmentCustomer(@RequestParam Integer customerId, @RequestParam String commentName,
            @RequestParam Integer fromMemberId) {
        Customer customer = customerJPA.findById(customerId).get();
        if (customer != null) {
            customer.setTeamComment(commentName);
            customerJPA.saveAndFlush(customer);
            return ResponseUtil.createRespBean(true, 200, "修改备注成功");
        } else {
            return ResponseUtil.createRespBean(false, 400, "员工不存在");
        }
    }

    @ApiOperation(value = "废弃掉邀请记录`", notes = "", httpMethod = "GET")
    @RequestMapping(value = TeamApi.disabledInvite, method = RequestMethod.GET)
    public ResponseBean disabledInvite(@RequestParam Integer inviteLogId) {
        MemberInvite invite = memberInviteJPA.findById(inviteLogId).get();
        if (invite != null) {
            invite.setConfirmed(false);
            invite.setStatus(MemberInviteStatusEnum.Del);
            memberInviteJPA.saveAndFlush(invite);
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "成功");
            return success;
        } else {
            return ResponseUtil.createRespBean(false, 400, "邀请不存在");
        }
    }

    @ApiOperation(value = "退出团队`", notes = "", httpMethod = "GET")
    @RequestMapping(value = TeamApi.exitTeam, method = RequestMethod.GET)
    public ResponseBean exitTeam(@RequestParam Integer customerId, @RequestParam Integer mktId) {
        Customer customer = customerJPA.findById(customerId).get();
        if (customer != null) {
            customer.setMemberId(null);
            customer.setTeamComment(customer.getName());
            customerJPA.saveAndFlush(customer);
            ResponseBean success = ResponseUtil.createRespBean(true, 200, "成功了");
            return success;
        } else {
            return ResponseUtil.createRespBean(false, 400, "人员不存在");
        }
    }

    @ApiOperation(value = "找到自由的员工`", notes = "", httpMethod = "GET")
    @RequestMapping(value = TeamApi.findFreeCustomer, method = RequestMethod.GET)
    public ResponseBean findFreeCustomer(@RequestParam Integer customerId, @RequestParam Integer mktId) {
        List<Customer> customers = customerJPA.findByMktIdAndMemberIdIsNull(mktId);
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
        success.getData().put("customers", customers);
        return success;
    }

    @ApiOperation(value = "邀请员工加入团队`", notes = "", httpMethod = "POST")
    @RequestMapping(value = TeamApi.inviteCustomer, method = RequestMethod.POST)
    public ResponseBean inviteCustomer(@RequestBody MemberInvite memberInvite) throws Exception {
//        Customer sendCustomer = null;
//        if(customerJPA.findById(memberInvite.getSendCustId()).isPresent())
//        {
//            sendCustomer = customerJPA.findById(memberInvite.getSendCustId()).get();
//        }
//        Customer recvCustomer = customerJPA.findById(memberInvite.getRecvCustId()).get();
//
//        if (sendCustomer != null && recvCustomer != null) {
//            if (recvCustomer.getMember() == null) {
//                memberInvite.setRecvCusName(recvCustomer.getName());
//                memberInvite.setSendCusName(sendCustomer.getName());
//                memberInvite.setStatus(MemberInviteStatusEnum.Active);
//                memberInvite.setRecvMobi(recvCustomer.getMobi());
//                memberInvite = memberInviteJPA.saveAndFlush(memberInvite);
//
//                ResponseBean success = ResponseUtil.createRespBean(true, 200, "接受邀请");
//                this.msgServiceImpl.inviteCustomerAppNotify(memberInvite, sendCustomer.getName() + "邀请你加入团队",
//                        recvCustomer.getRegistrationId());
//                return success;
//            } else {
//                return ResponseUtil.createRespBean(false, 400, "被邀请用户在职");
//            }
//        } else {
//            return ResponseUtil.createRespBean(false, 400, "邀请用户或被邀请用户不存在");
//        }

       boolean flag = this.teamService.inviteCustomer(memberInvite);
       if(flag)
       {
           return ResponseUtil.createRespBean(true, 200, "发送邀请成功！");
       }
       return ResponseUtil.createRespBean(false, 400, "邀请用户或被邀请用户不存在或被邀请用户在职！");
    }

    @ApiOperation(value = "用户拉取邀请别人的记录", notes = "", httpMethod = "GET")
    @RequestMapping(value = TeamApi.invitelogList, method = RequestMethod.GET)
    public ResponseBean invitelogList(@RequestParam Integer memberId, @RequestParam Integer mktId) {
        List<MemberInvite> memberInvites = memberInviteJPA.findByMemberIdAndMktId(memberId,mktId);
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
        success.getData().put("memberInvites", memberInvites);
        return success;
    }

    @ApiOperation(value = "用户拉取自己的邀请列表", notes = "", httpMethod = "GET")
    @RequestMapping(value = TeamApi.recvInvite, method = RequestMethod.GET)
    public ResponseBean recvInvite(@RequestParam Integer customerId, @RequestParam Integer mktId) {
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
        List<MemberInvite> memberInvites = memberInviteJPA.findByRecvCustId(customerId);
        success.getData().put("memberInvites", memberInvites);
        return success;
    }

    @ApiOperation(value = "拒绝邀请记录", notes = "", httpMethod = "GET")
    @RequestMapping(value = TeamApi.refuseInvite, method = RequestMethod.GET)
    public ResponseBean refuseInvite(@RequestParam Integer customerId, @RequestParam Integer mktId,
            @RequestParam Integer inviteLogId) {
//        MemberInvite invite = memberInviteJPA.findById(inviteLogId).get();
//        if (invite != null) {
//            invite.setConfirmed(false);
//            invite.setStatus(MemberInviteStatusEnum.Refuse);
//            memberInviteJPA.saveAndFlush(invite);
//            ResponseBean success = ResponseUtil.createRespBean(true, 200, "成功");
//            return success;
//        } else {
//            return ResponseUtil.createRespBean(false, 400, "邀请不存在");
//        }
        try {
            boolean flag = this.teamService.refuseInvite(customerId,mktId,inviteLogId);
            if(flag)
            {
                return ResponseUtil.createRespBean(true, 200, "成功");
            }
        }catch (Exception e){
            e.printStackTrace();
            return ResponseUtil.createRespBean(false,201,"");
        }
        return ResponseUtil.createRespBean(false, 400, "邀请不存在");
    }

    @ApiOperation(value = "根据手机号搜索用户", notes = "", httpMethod = "GET")
    @RequestMapping(value = TeamApi.searchCustomerByPhone, method = RequestMethod.GET)
    public ResponseBean searchCustomerByPhone(@RequestParam String phone, @RequestParam Integer mktId) {
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "搜索成功");
        Customer customer = customerJPA.findByMktIdAndMobi(mktId, phone);
        success.getData().put("customer", customer);
        return success;
    }

    @ApiOperation(value = "拉取团队列表", notes = "", httpMethod = "GET")
    @RequestMapping(value = TeamApi.teamList, method = RequestMethod.GET)
    public ResponseBean teamList(@RequestParam Integer memberId, @RequestParam Integer mktId) {
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "搜索成功");
        List<Customer> customers = customerJPA.findByMemberId(memberId);
        success.getData().put("customers", customers);
        return success;
    }

}
