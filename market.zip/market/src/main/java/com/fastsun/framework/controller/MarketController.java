package com.fastsun.framework.controller;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.rbac.Market;
import com.fastsun.framework.entity.rbac.Menu;
import com.fastsun.framework.jpa.MarketJPA;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.service.impl.rbac.MarketServiceImpl;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.controller.base.BaseController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import com.fastsun.market.utils.StatusMsgEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

// @Api(value = "market", description = "市场管理")
@Api(description = "市场管理", tags = { "framework.Market" })
@RestController
@RequestMapping("/api/market")
public class MarketController extends BaseController {

    @Autowired
    private MarketJPA marketJPA;

    @Autowired
    private CommonEntityService marketCommonEntityService;

    @Autowired
    private MarketServiceImpl marketServiceImpl;

    @ApiOperation(value = "获取市场分页列表", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/page", method = RequestMethod.POST)
    public ResponseBean listMarket(@RequestBody QueryParameter queryParameter) {
        Paging<Market> paging = marketCommonEntityService.findPagedEntity(queryParameter, Market.class);
        ResponseBean res = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        res.getData().put("markets", paging);
        return res;
    }

    @ApiOperation(value = "获取市场详细信息", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/detail", method = RequestMethod.GET)
    public ResponseBean detailMarket(@RequestParam Integer mktId) {
        Market market = (Market) marketCommonEntityService.findById(Market.class, mktId);
        ResponseBean res = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        res.getData().put("market", market);
        return res;
    }

    @ApiOperation(value = "获取市场菜单", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/menus", method = RequestMethod.GET)
    public ResponseBean detailMarketMenus(@RequestParam Integer mktId) {
        List<Menu> menus = marketServiceImpl.getMarketMenu(mktId);
        ResponseBean res = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        res.getData().put("menus", menus);
        return res;
    }

    @ApiOperation(value = "创建市场", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ResponseBean addMarket(HttpServletRequest request, @RequestBody Market market) {
        ResponseBean res = null;
        if (market == null) {
            res = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return res;
        }
        long count = this.marketJPA.findByMktName(market.getMktName()).size();
        if (count > 0) {
            res = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_REPEAT.getStatus(),
                    StatusMsgEnum.ADD_REPEAT.getMsg());
            return res;
        }
        Market mar = marketServiceImpl.saveMarket(market, request);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        res.getData().put("market", mar);
        return res;
    }

    @ApiOperation(value = "修改市场", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseBean updateMarket(@RequestBody Market market) {
        ResponseBean res = null;
        Market newMarket = (Market) marketCommonEntityService.update(market);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        res.getData().put("market", newMarket);
        return res;
    }

    @ApiOperation(value = "删除市场", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseBean deleteMarket(@RequestParam Integer mktId) {
        ResponseBean res = null;
        if (mktId == null) {
            res = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
        }
        marketCommonEntityService.delete(Market.class, mktId);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.DELETE_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return res;
    }

    @ApiOperation(value = "禁用市场", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/disabled", method = RequestMethod.GET)
    public ResponseBean disabledMarket(@RequestParam Integer mktId) {
        ResponseBean res = null;
        Market mar = marketServiceImpl.disabledMarket(mktId);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.DISABLED_SUCCESS.getStatus(),
                StatusMsgEnum.DISABLED_SUCCESS.getMsg());
        res.getData().put("market", mar);
        return res;
    }

    @ApiOperation(value = "启用市场", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/active", method = RequestMethod.GET)
    public ResponseBean activeMarket(@RequestParam Integer mktId) {
        ResponseBean res = null;
        Market mar = marketServiceImpl.activeMarket(mktId);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.ACTIVE_SUCCESS.getStatus(),
                StatusMsgEnum.ACTIVE_SUCCESS.getMsg());
        res.getData().put("market", mar);
        return res;
    }

}
