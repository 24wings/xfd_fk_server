package com.fastsun.framework.controller;

import com.fastsun.framework.bean.RequestBean;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.rbac.Menu;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.service.impl.rbac.UserServiceImpl;
import com.fastsun.framework.utils.JwtTokenUtil;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@Api(description = "员工登录", tags = {  "framework.UserLogin" })
@RestController
@RequestMapping("/employee")
public class UserLoginController extends BaseController {

    private static final Logger LOGGER = LogManager.getLogger(UserController.class);

    @Autowired
    private UserServiceImpl userServiceImpl;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @ApiOperation(value = "员工登录", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ResponseBean login(@RequestBody RequestBean requestBean) {
        ResponseBean res = null;
        try {
            Optional<User> user = Optional.of(userServiceImpl.findEmployeeByUserName(requestBean.getUserName()));
            if(user.get().getStatus() == 0){
                 res = ResponseUtil.createRespBean(false,StatusMsgEnum.LOGIN_FALSE.getStatus(),"用户被禁用！");
                 return res;
            }
            final UsernamePasswordAuthenticationToken upToken = new UsernamePasswordAuthenticationToken(
                    requestBean.getUserName(), requestBean.getPassword());
            Authentication authentication = authenticationManager.authenticate(upToken);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            final UserDetails userDetails = userDetailsService.loadUserByUsername(requestBean.getUserName());
            final String token = jwtTokenUtil.generateToken(userDetails.getUsername(), "user");
            String role = user.get().getRoleIds();
            if (StringUtils.isEmpty(role)) {
                res = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                        StatusMsgEnum.PARAM_NULL.getMsg());
                return res;
            }
            List<Menu> menus = userServiceImpl.getEmployeeMenu(user.get());
            res = ResponseUtil.createRespBean(true, StatusMsgEnum.LOGIN_SUCCESS.getStatus(),
                    StatusMsgEnum.LOGIN_SUCCESS.getMsg());

            res.getData().put("menus", menus);
            res.getData().put("employee", user);
            res.getData().put("token", token);
            return res;
        } catch (Exception e) {
            e.printStackTrace();
            return res = ResponseUtil.createRespBean(false, StatusMsgEnum.LOGIN_FALSE.getStatus(),
                    StatusMsgEnum.LOGIN_FALSE.getMsg());
        }
    }

}
