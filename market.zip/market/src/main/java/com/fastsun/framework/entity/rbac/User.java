package com.fastsun.framework.entity.rbac;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "user",uniqueConstraints = {@UniqueConstraint(columnNames = "userName")})
public class User implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = true,length = 20)
    private String name;
    @NotBlank(message = "用户名不能为空")
    @Column(nullable = false,length = 30)
    private String userName;
    @NotBlank(message = "密码不能为空")
    @Column(nullable = false,length = 100)
    private String password;
    private  Boolean pwdEncrypted;
    private Date createTime;
    private Date updateTime;
    private Integer status;
    private Integer orgId;
    @Column(nullable = true,length = 50)
    private String creator;
    @Column(nullable = false)
    private Integer mktId;
    private Integer creatorId;
    @Column(nullable = true,length = 200)
    private String roleIds;
    @Transient
    private List<String> authorities;
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "roles_users",joinColumns = {
            @JoinColumn(name = "user_Id", referencedColumnName = "id")}, inverseJoinColumns = {
            @JoinColumn(name = "role_Id", referencedColumnName = "roleId")})
    private List<Role> roles;

    @ManyToOne(fetch = FetchType.LAZY,optional = false)
    @JoinColumn(name="orgId",updatable = false,insertable = false,foreignKey = @ForeignKey(name = "orgId", value = ConstraintMode.NO_CONSTRAINT))
    private Org org;
    public User(){}

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getRoleIds() {
        return roleIds;
    }

    public void setRoleIds(String roleIds) {
        this.roleIds = roleIds;
    }

    public List<String> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(List<String> authorities) {
        this.authorities = authorities;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    public Boolean getPwdEncrypted() {
        return pwdEncrypted;
    }

    public void setPwdEncrypted(Boolean pwdEncrypted) {
        this.pwdEncrypted = pwdEncrypted;
    }
    @JsonProperty
    public Org getOrg() {
        return org;
    }

    public void setOrg(Org org) {
        this.org = org;
    }
}
