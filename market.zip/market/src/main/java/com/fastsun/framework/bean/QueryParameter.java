package com.fastsun.framework.bean;

import java.util.List;

/**
 * 前端用户点查询按钮传递过来的参数
 */

public class QueryParameter {
    private List<QueryCondition> queryConditions;
    private List<SummaryParameter> summaryParameters;
    private PageParameter pageParameter;
    /*
     * 查询参数HashMap，可以有多个参数 处理如select * from table where
     * field1=@fieldValue的情况,参数名为@fieldValue
     * 前端若想替换参数@fieldValue的值为1，则可以在queryAttributes中put("@fieldValue","1")
     */
    private List<QueryAttribute> queryAttributes;

    public QueryParameter() {
    }

    public List<QueryCondition> getQueryConditions() {
        return queryConditions;
    }

    public void setQueryConditions(List<QueryCondition> queryConditions) {
        this.queryConditions = queryConditions;
    }

    public PageParameter getPageParameter() {
        return pageParameter;
    }

    public void setPageParameter(PageParameter pageParameter) {
        this.pageParameter = pageParameter;
    }

    /**
     * @return the queryAttributes
     */
    public List<QueryAttribute> getQueryAttributes() {
        return queryAttributes;
    }

    /**
     * @param queryAttributes the queryAttributes to set
     */
    public void setQueryAttributes(List<QueryAttribute> queryAttributes) {
        this.queryAttributes = queryAttributes;
    }

    public List<SummaryParameter> getSummaryParameters() {
        return summaryParameters;
    }

    public void setSummaryParameters(List<SummaryParameter> summaryParameters) {
        this.summaryParameters = summaryParameters;
    }
}
