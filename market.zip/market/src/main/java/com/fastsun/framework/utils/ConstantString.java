package com.fastsun.framework.utils;

public class ConstantString {

    public static final String BUYER_TRANS_FEE_SUBJECT_CODE = "";
    public static final String SELLER_TRANS_FEE_SUBJECT_CODE = "";
}
