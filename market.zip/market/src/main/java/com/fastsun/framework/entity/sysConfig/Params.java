package com.fastsun.framework.entity.sysConfig;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Entity
@Table(name = "params",uniqueConstraints = {@UniqueConstraint(columnNames = "paramKey")})
public class Params implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @NotBlank(message = "参数名不能为空")
    @Column(nullable = false,length = 20)
    private String paramName;
    @NotBlank(message = "参数键不能为空")
    @Column(nullable = false,length = 20)
    private String paramKey;
    @Column(nullable = true,length = 100)
    private String paramValue;
    private Integer type;
    @Column(nullable = false)
    private Integer mktId;
    @Column(nullable = true,length = 200)
    private String addition;
    @Column(nullable = true,length = 200)
    private String defaultValue;
    @Column(nullable = false)
    private Integer isLocal;
    @Column(nullable = true,length = 200)
    private String remark;

    public Params(){}

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getParamName() {
        return paramName;
    }

    public void setParamName(String paramName) {
        this.paramName = paramName;
    }

    public String getParamKey() {
        return paramKey;
    }

    public void setParamKey(String paramKey) {
        this.paramKey = paramKey;
    }

    public String getParamValue() {
        return paramValue;
    }

    public void setParamValue(String paramValue) {
        this.paramValue = paramValue;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAddition() {
        return addition;
    }

    public void setAddition(String addition) {
        this.addition = addition;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public Integer getIsLocal() {
        return isLocal;
    }

    public void setIsLocal(Integer isLocal) {
        this.isLocal = isLocal;
    }
}
