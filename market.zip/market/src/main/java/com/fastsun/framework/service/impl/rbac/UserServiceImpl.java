package com.fastsun.framework.service.impl.rbac;

import com.fastsun.framework.entity.rbac.Menu;
import com.fastsun.framework.entity.rbac.Role;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.framework.jpa.UserJPA;
import com.fastsun.framework.jpa.MenuJPA;
import com.fastsun.framework.jpa.RoleJPA;
import com.fastsun.framework.utils.RequestUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Service
public class UserServiceImpl{
    @Autowired
    private UserJPA userJPA;

    @Autowired
    private RoleJPA roleJPA;

    @Autowired
    private MenuJPA menuJPA;

    @Autowired
    RequestUtil resquestUtil;
    @Transactional
    public User saveEmployee(User user, HttpServletRequest request) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        user.setPassword(encoder.encode(user.getPassword()));
        user.setPwdEncrypted(true);
        user.setCreateTime(new Date());
        user.setUpdateTime(new Date());
        user.setStatus(1);
        resquestUtil.setCreatorAndCreatorId(user,resquestUtil.getLoginUser(request));
        String role = user.getRoleIds();
        String[] str = role.split(",");
        int[] ints = new int[str.length];
        for (int i = 0; i<str.length;i++){
            if(StringUtils.isNotBlank(str[i])){
                ints[i]=Integer.parseInt(str[i]);
            }
        }
        //user.setOrg(this.orgJPA.findById(user.getOrgId()).get());
        user.setRoles(this.roleJPA.findByRoleIdIn(ints));
        return this.userJPA.save(user);
    }

    @Transactional
    public void deleteEmployee(Integer epId) {
        User user = this.userJPA.findById(epId).get();
        user.setStatus(0);
        this.userJPA.saveAndFlush(user);
    }

    public void roleAdd(Role role) {
        String employeeIds = role.getUserIds();
        String[] str = employeeIds.split(",");
        int[] ints = new int[str.length];
        for (int i = 0; i<str.length;i++){
            ints[i]=Integer.parseInt(str[i]);
        }
        List<User> ems = this.userJPA.findByIdIn(ints);
        Role ro =roleJPA.findById(role.getRoleId()).get();
        ro.setUsers(ems);
        Iterator<User> iterator = ems.iterator();
        while (iterator.hasNext()){
            User oldUser = iterator.next();
            String roleIds = oldUser.getRoleIds();
            if (roleIds ==null){
                roleIds="";
            }
            String newRoleIds =roleIds+","+role.getRoleId();
            oldUser.setRoleIds(newRoleIds);
            this.userJPA.saveAndFlush(oldUser);
        }
    }

    public void roleBat(Role role) {
        String employeeIds = role.getUserIds();
        String[] str = employeeIds.split(",");
        int[] ints = new int[str.length];
        for (int i = 0; i<str.length;i++){
            ints[i]=Integer.parseInt(str[i]);
        }
        List<User> ems = this.userJPA.findByIdIn(ints);
        Iterator<User> iterator = ems.iterator();
        while (iterator.hasNext()){
            User oldUser = iterator.next();
            String roleIds = oldUser.getRoleIds();
            String newRoleIds =roleIds.replace(role.getRoleId()+"","");
            oldUser.setRoleIds(newRoleIds);
            this.userJPA.saveAndFlush(oldUser);
        }
    }

    public User findEmployeeByUserName(String userName) {
        User user = this.userJPA.findByUserName(userName);
        return user;
    }

    public List<Menu> getEmployeeMenu(User user) {
        String role = user.getRoleIds();
        String[] str = role.split(",");
        int[] ints = new int[str.length];
        for (int i = 0; i<str.length;i++){
            ints[i]=Integer.parseInt(str[i]);
        }
        List<Role> roles = roleJPA.findByRoleIdIn(ints);
        Iterator<Role> iterator = roles.iterator();
        String menuId = new String("");
        while (iterator.hasNext()){
            String menuIds = iterator.next().getMenuIds();
            menuId += menuIds;
        }
        //去重
        String[] strs = menuId.split(",");
        Set<String> set = new HashSet<>();
        for(int i=0;i<strs.length;i++){
            set.add(strs[i]);
        }
        String[] s = (String[]) set.toArray(new String[set.size()]);
        int[] it = new int[s.length];
        for (int i = 0; i<s.length;i++){
            it[i]=Integer.parseInt(s[i]);
        }
        List<Menu> menus = menuJPA.findByMenuIdIn(it);
        return menus;
    }

    public void changeStatus(Integer epId,Integer status){
        User user = this.userJPA.findById(epId).get();
        user.setStatus(status);
        this.userJPA.saveAndFlush(user);
    }

//    public void active(Integer epId){
//        User user = this.userJPA.findById(epId).get();
//        user.setStatus(1);
//        this.userJPA.saveAndFlush(user);
//    }

}
