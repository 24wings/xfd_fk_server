package com.fastsun.framework.entity.rbac;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "role",uniqueConstraints = {@UniqueConstraint(columnNames = "roleCode")})
public class Role implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer roleId;
    @NotBlank(message = "角色名称不能为空")
    @Column(nullable = false,length = 50)
    private String roleName;
    @NotBlank(message = "角色代码不能为空")
    @Column(nullable = false,length = 50)
    private String roleCode;
    @Column(nullable = true)
    private Timestamp createTime;
    @Column(nullable = true)
    private Timestamp updateTime;
    private Integer creatorId;
    @Column(nullable = true,length = 50)
    private String creator;
    @Column(nullable = true,length = 200)
    private String remark;
    @Column(nullable = true,length = 200)
    private String menuIds;
    @Column(nullable = false)
    private Integer mktId;
    private String userIds;
    @ManyToMany(fetch = FetchType.LAZY,mappedBy = "roles")
    @JsonBackReference
    private List<User> users;
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "roles_menus",joinColumns = {
            @JoinColumn(name = "role_Id", referencedColumnName = "roleId")}, inverseJoinColumns = {
            @JoinColumn(name = "memnu_Id", referencedColumnName = "menuId")})
    private List<Menu>  menus;

    public Role(){}

    public String getMenuIds() {
        return menuIds;
    }

    public void setMenuIds(String menuIds) {
        this.menuIds = menuIds;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public List<Menu> getMenus() {
        return menus;
    }

    public void setMenus(List<Menu> menus) {
        this.menus = menus;
    }

    public String getUserIds() {
        return userIds;
    }

    public void setUserIds(String userIds) {
        this.userIds = userIds;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

}
