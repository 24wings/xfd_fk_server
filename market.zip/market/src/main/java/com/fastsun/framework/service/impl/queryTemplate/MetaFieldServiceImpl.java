package com.fastsun.framework.service.impl.queryTemplate;

import com.alibaba.fastjson.JSONObject;
import com.fastsun.framework.entity.queryTemplate.MetaField;
import com.fastsun.framework.jpa.MetaFieldJPA;
import com.fastsun.framework.service.impl.BaseServiceImpl;
import org.hibernate.Session;
import org.hibernate.jdbc.ReturningWork;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
public class MetaFieldServiceImpl{

   @Autowired
    MetaFieldJPA metaFieldJPA;
    @Autowired
    EntityManager entityManager;
    private Session session ;

    public List<MetaField> findByObjectCode(String objCode) {
        return metaFieldJPA.findByObjectCode(objCode);
    }

    //TODO:这个方法已经在sqlEntityService中实现，考虑将此方法移除
//    public List<JSONObject> spec(String jpql){
//        entityManager.unwrap(org.hibernate.Session.class);
//        ResultSet resultSet = session.doReturningWork(new ReturningWork<ResultSet>() {
//            @Override
//            public ResultSet execute(Connection connection) throws SQLException {
//                PreparedStatement preparedStatement = connection.prepareStatement(jpql);
//                ResultSet resultSet = preparedStatement.executeQuery();
//                return resultSet;
//            }
//        });
//        Map<String, Class> propertyMap = new HashMap<String, Class>();
//        JSONObject object = null;
//        List<JSONObject> list = new ArrayList<>();
//        try {
//            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
//            for(int i = 1 ; i<= resultSetMetaData.getColumnCount();i++) {
//                object = new JSONObject();
//                object.put("field",resultSetMetaData.getColumnName(i));
//                object.put("type",resultSetMetaData.getColumnTypeName(i));
//                propertyMap.put(resultSetMetaData.getColumnName(i),typeTrans(resultSetMetaData.getColumnType(i)));
//                list.add(object);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return  list;
//    }
//
//    public Class typeTrans(int type){
//        Class javaType = null;
//        switch (type) {
//            case Types.BIGINT:
//                javaType = java.lang.Long.class;break;
//            case Types.DATE:
//                javaType = java.util.Date.class;break;
//            case Types.DOUBLE:
//                javaType = java.lang.Double.class;break;
//            case Types.FLOAT:
//                javaType = java.lang.Float.class;break;
//            case Types.INTEGER:
//                javaType = java.lang.Integer.class;break;
//            case Types.SMALLINT:
//                javaType = java.lang.Integer.class;break;
//            case Types.TIME:
//                javaType = java.sql.Time.class;break;
//            case Types.TIMESTAMP:
//                javaType = java.sql.Timestamp.class;break;
//            case Types.TINYINT:
//                javaType = java.lang.Boolean.class;break;
//            case Types.VARCHAR:
//                javaType = java.lang.String.class;break;
//        }
//        return javaType;
//    }

    /*
     * 执行sql,并给占位符赋值
     */
    @Transactional
    public int executeSql(String sql ,String id ,List values){
        Query query = entityManager.createNativeQuery(sql);
        for(int i=0;i<values.size();i++){
            query.setParameter(i+1,values.get(i));
        }
        return query.executeUpdate();
    }
}
