package com.fastsun.framework.service.impl.rbac;

import com.fastsun.framework.entity.rbac.*;
import com.fastsun.framework.jpa.*;
import com.fastsun.framework.utils.JwtTokenUtil;
import com.fastsun.framework.utils.RequestUtil;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;
@Service
public class MarketServiceImpl{
    @Autowired
    private MarketJPA marketJPA;

    @Autowired
    private OrgJPA orgJPA;
    @Autowired
    private MenuJPA menuJPA;
    @Autowired
    private UserJPA userJPA;
    @Autowired
    private DeveloperJPA developerJPA;
    @Autowired
    RequestUtil requestUtil;

    public List<Menu> getMarketMenu(Integer mktId) {
        Market market = this.marketJPA.findById(mktId).get();
        String[] str = market.getMenuIds().split(",");
        int[] ints = new int[str.length];
        for (int i = 0; i<str.length;i++){
            ints[i]=Integer.parseInt(str[i]);
        }
        List<Menu> menus = menuJPA.findByMenuIdIn(ints);
        return menus;
    }

    /*
     * 创建市场即创建顶级组织
     */
    public Market saveMarket(Market market, HttpServletRequest request) {
        Market marketDB = this.marketJPA.save(market);
        Org org = new Org();
        requestUtil.setCreatorAndCreatorId(org,requestUtil.getLoginUser(request));
        org.setOrgName(market.getMktName());
        org.setCreateTime(new Date());
        org.setMktId(marketDB.getMktId());
        org.setParentId(0);
        this.orgJPA.save(org);
        return marketDB;
    }


    @Transactional
    public Market disabledMarket(Integer mktId) {
        Market market = this.marketJPA.findById(mktId).get();
        market.setStatus(0);
        return this.marketJPA.saveAndFlush(market);
    }

    @Transactional
    public Market activeMarket(Integer mktId) {
        Market market = this.marketJPA.findById(mktId).get();
        market.setStatus(1);
        return  this.marketJPA.saveAndFlush(market);
    }
}
