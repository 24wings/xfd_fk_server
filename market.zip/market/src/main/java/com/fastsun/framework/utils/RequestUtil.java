package com.fastsun.framework.utils;
import com.fastsun.framework.bean.AllUerTuple;
import com.fastsun.framework.bean.QueryCondition;
import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.entity.rbac.Developer;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.framework.jpa.DeveloperJPA;
import com.fastsun.framework.jpa.UserJPA;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.entity.member.Member;
import com.fastsun.market.jpa.CustomerJPA;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
@Component
public class RequestUtil {
    @Autowired
    JwtTokenUtil jwtTokenUtil;

    UserJPA userJPA;DeveloperJPA developerJPA;CustomerJPA customerJPA;
    @Autowired
    public RequestUtil(UserJPA userJPA, DeveloperJPA developerJPA, CustomerJPA customerJPA) {
        this.userJPA = userJPA;
        this.developerJPA = developerJPA;
        this.customerJPA = customerJPA;
    }

    public static String getToken(HttpServletRequest request){
        String authHeader = request.getHeader("Authorization");
        String tokenHead = "Bearer ";
        return authHeader.substring(tokenHead.length());
    }

    public static QueryParameter getQueryParameter(Object entity,String andOr,String ...fieldNames){
        QueryParameter queryParameter = new QueryParameter();
        List<QueryCondition> queryConditions = new ArrayList<>();
        QueryCondition queryCondition = null;
        for(String fieldName : fieldNames){
            queryCondition = new QueryCondition();
            queryCondition.setField(fieldName);
            queryCondition.setCompare("=");
            queryCondition.setAndOr(andOr);
            queryCondition.setValue(ReflectUtil.getValueByKey(entity,fieldName));
            queryConditions.add(queryCondition);
        }
        queryParameter.setQueryConditions(queryConditions);
        return queryParameter;
    }

    public AllUerTuple getLoginUser(HttpServletRequest request){
        String token = getToken(request);
        String userName = jwtTokenUtil.getUsernameFromToken(token);
        Claims claims = jwtTokenUtil.getClaimsFromToken(token);
        if("user".equals(claims.getAudience())){
            User user = userJPA.findByUserName(userName);
            return new AllUerTuple(null,user,null);
        }

        if("developer".equals(claims.getAudience())){
            Developer  developer = developerJPA.findByDevUserName(userName);
            return new AllUerTuple(developer,null,null);
        }

        if("customer".equals(claims.getAudience())){
            Customer customer = this.customerJPA.findByMobi(userName);
            return new AllUerTuple(null,null,customer);
        }
        return null;
    }

    public void setCreatorAndCreatorId(Object object,AllUerTuple<Developer,User,Customer> allUerTuple){
            Field field = null;
        try {
            Field[] fields = object.getClass().getDeclaredFields();
            for (int i = 0; i < fields.length; i++){
                field = fields[i];
                field.setAccessible(true);
                if(field.getName().endsWith("creator")){
                    if(allUerTuple.first != null){
                        field.set(object,allUerTuple.first.getDevUserName());
                    }else if(allUerTuple.second != null){
                        field.set(object,allUerTuple.second.getUserName());
                    }else if(allUerTuple.three != null){
                        field.set(object,allUerTuple.three.getMobi());
                    }
                }
                if(field.getName().endsWith("creatorId")){
                    if(allUerTuple.first != null){
                        field.set(object,allUerTuple.first.getDevId());
                    }else if(allUerTuple.second != null){
                        field.set(object,allUerTuple.second.getId());
                    }else if(allUerTuple.three != null){
                        field.set(object,allUerTuple.three.getId());
                    }
                }
                field.setAccessible(false);
            }

        }catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public void setActorAndActorId(Object object,AllUerTuple<Developer,User,Customer> allUerTuple){
        Field field = null;
        try {
            Field[] fields = object.getClass().getDeclaredFields();
            for (int i = 0; i < fields.length; i++){
                field = fields[i];
                field.setAccessible(true);
                if(field.getName().endsWith("actorId")){
                    if(allUerTuple.first != null){
                        field.set(object,allUerTuple.first.getDevId());
                    }else if(allUerTuple.second != null){
                        field.set(object,allUerTuple.second.getId());
                    }else if(allUerTuple.three != null){
                        field.set(object,allUerTuple.three.getId());
                    }
                }
                if(field.getName().endsWith("actor")){
                    if(allUerTuple.first != null){
                        field.set(object,allUerTuple.first.getDevUserName());
                    }else if(allUerTuple.second != null){
                        field.set(object,allUerTuple.second.getUserName());
                    }else if(allUerTuple.three != null){
                        field.set(object,allUerTuple.three.getMobi());
                    }
                }
                field.setAccessible(false);
            }

        }catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}
