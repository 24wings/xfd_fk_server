package com.fastsun.framework.controller;

import com.fastsun.framework.bean.MetaObjectDataRq;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.queryTemplate.MetaObject;
import com.fastsun.framework.service.impl.queryTemplate.SqlEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.service.impl.queryTemplate.MetaObjectServiceImpl;
import com.fastsun.framework.bean.Paging;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import net.sf.json.JSONObject;

// @Api(value = "metaObject", description = "元数据管理", produces = MediaType.APPLICATION_JSON_VALUE)
@Api(description = "元数据对象", tags = { "framework.MetaObject" })
@RestController
@RequestMapping("/api/metaObject")
public class MetaObjectController extends BaseController {

    @Autowired
    private MetaObjectServiceImpl metaObjectServiceImpl;
    @Autowired
    private SqlEntityService sqlEntityService; // sql生成器

    @ApiOperation(value = "元数据新增", notes = "元数据", httpMethod = "POST", produces = MediaType.APPLICATION_JSON_VALUE)
    @PostMapping(value = "/create")
    public ResponseBean createMataObject(@RequestBody MetaObject metaObject) {
        ResponseBean resp = null;
        if (metaObject == null) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return resp;
        }
        long count = this.metaObjectServiceImpl.count(metaObject);
        if (count > 0) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_REPEAT.getStatus(),
                    StatusMsgEnum.ADD_REPEAT.getMsg());
            return resp;
        }
        MetaObject metaObjectOld = this.metaObjectServiceImpl.save(metaObject);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        resp.getData().put("metaObject", metaObjectOld);
        return resp;
    }

    @ApiOperation(value = "获取视图列表", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseBean getList(HttpServletRequest request, HttpServletResponse response) {
        ResponseBean res = null;
        List<MetaObject> metaObjects = metaObjectServiceImpl.findAllToList();
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        res.getData().put("metaObjects", metaObjects);
        return res;
    }

    // 删除视图对象，级联删除视图字段
    @ApiOperation(value = "删除视图列表", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseBean deleteMataObjecr(@RequestParam String objectCode) {
        ResponseBean res = null;
        this.metaObjectServiceImpl.deleteByObjectCode(objectCode);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.DELETE_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return res;
    }

    // 元数据更新,先删除所有的原有字段,再添加新的字段
    @ApiOperation(value = "更新元数据", notes = "先删除所有的原有字段,再添加新的字段", httpMethod = "POST")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseBean updateMataObject(@RequestBody MetaObject metaObject) {
        ResponseBean res = null;
        // System.out.println(JSON.toJSON(metaObject));
        MetaObject newMetaObject = metaObjectServiceImpl.updateMataObject(metaObject);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        res.getData().put("metaObject", newMetaObject);
        return res;
    }

    @ApiOperation(value = "获取指定元数据对象详情", notes = "", httpMethod = "GET")
    @GetMapping(value = "/detail")
    public ResponseBean findOneMataObject(@RequestParam String objectCode) {
        ResponseBean resp = null;
        MetaObject metaObject = this.metaObjectServiceImpl.findByObjectCode(objectCode);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("metaObject", metaObject);
        return resp;
    }

    @ApiOperation(value = "更新元数据的指定更新表的数据", notes = "", httpMethod = "POST")
    @PostMapping(value = "/data/update")
    public ResponseBean updataManyEntity(@RequestBody MetaObjectDataRq metaObjectDataRq) {
        ResponseBean resp = null;
        String entityCode = metaObjectDataRq.getMetaObject().getObjectCode();
        sqlEntityService.updateSqlEntity(entityCode, metaObjectDataRq.getDataItem());
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        return resp;
    }

    @ApiOperation(value = "插入元数据的指定表的数据", notes = "", httpMethod = "POST")
    @PostMapping(value = "/data/insert")
    public ResponseBean insertSqlEntity(@RequestBody MetaObjectDataRq metaObjectDataRq) {
        ResponseBean resp = null;
        String entityCode = metaObjectDataRq.getMetaObject().getObjectCode();
        sqlEntityService.insertSqlEntity(entityCode, metaObjectDataRq.getDataItem());
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        return resp;
    }

    @ApiOperation(value = "删除元数据的指定表的数据", notes = "", httpMethod = "POST")
    @PostMapping(value = "/data/delete")
    public ResponseBean deleteSqlEntity(@RequestBody MetaObjectDataRq metaObjectDataRq) {
        ResponseBean resp = null;
        String entityCode = metaObjectDataRq.getMetaObject().getObjectCode();
        sqlEntityService.deleteSqlEntity(entityCode, metaObjectDataRq.getDataItem());
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        return resp;
    }

    /** 根据 objectcode 得到对应的字段情况 **/
    /**
     * 根据前台传递过来的查询参数解析生成SQL 1---- 根据查询名称 查找此表的源SQL语句 --- querySql 字段 2----
     * 根据此表的查询名称找到相应的字段表及后台需要处理逻辑 3---- 处理where 字段逻辑 包括：全局变量，JAVA函数，
     *
     * @param objectCode,queryParameter
     * @return
     */
    @ApiOperation(value = "获取元数据的sql查询数据分页", notes = "", httpMethod = "POST")
    @PostMapping(value = "/data/page")
    public ResponseBean query(@RequestParam String objectCode, @RequestBody QueryParameter queryParameter)
            throws Exception {
        ResponseBean resp = null;
        Paging<JSONObject> page = sqlEntityService.queryPageEntity(objectCode, queryParameter);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("result", page);
        return resp;
        /**
         * 前台传递过来查询参数：
         * 
         * 要查询字段名 + 值 +比较符 （字符型默认为 like ,数字，日期型默认为 = ,日期前台需要转换成时间戳 "objectCode":"查询名称",
         * [{ "field":"name", "value":"张三", "compare":"like" }, "field":"age",
         * "value":"18", "compare":"=" }, ] // 1---- 根据查询名称 查找此表的源SQL语句 --- querySql 字段
         * // 2---- 根据此表的查询名称找到相应的字段表及后台需要处理逻辑 // 3---- 处理where 字段逻辑 包括：全局变量，JAVA函数，
         * 
         * for indx:=0 to FConditionList.Count - 1 do begin
         * aCondition:=FConditionList[indx] as TCondition; // aCaption :=
         * GetKHWord(aCondition.Left, '{', '}'); aCaption:=aCondition.Left;
         * aField:=FQueryDef.FindFieldByCaption(aCaption); //对枚举值命令的处理
         * aValues:=ReadScriptCmd(aField.Command, '', 'Values'); if aValues<> '' then
         * begin for j:=1 to GetStrCount (aValues, ',')do begin s:=GetSubStr(aValues,
         * ',', j); s1:=GetSubStr(s, ':', 1); s2:=GetSubStr(s, ':', 2); if s2 =
         * aCondition.Right then aCondition.Right :=s1; end; end;
         **/
    }

}
