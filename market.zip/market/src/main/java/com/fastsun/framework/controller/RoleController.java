package com.fastsun.framework.controller;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.rbac.Role;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.service.impl.rbac.RoleServiceImpl;
import com.fastsun.framework.bean.Paging;
import com.fastsun.market.utils.StatusMsgEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(description = "角色管理", tags = { "framework.Role" })
@RestController
@RequestMapping("/api/role")
public class RoleController extends BaseController {

    @Autowired
    private CommonEntityService roleCommonEntityService;

    @ApiOperation(value = "获取角色列表", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public ResponseBean listRole(@RequestBody QueryParameter queryParameter) {
        ResponseBean res = null;
        // List<Role> roles = roleServiceImpl.getList(marketId);
        Paging<Role> paging = this.roleCommonEntityService.findPagedEntity(queryParameter, Role.class);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        res.getData().put("roles", paging);
        return res;
    }

    @ApiOperation(value = "创建角色", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ResponseBean addRole(@RequestBody Role role) {
        ResponseBean resp = null;
        if (role == null) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return resp;
        }
        boolean flag = roleCommonEntityService.save(role);
        if (flag) {
            resp = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                    StatusMsgEnum.ADD_SUCCESS.getMsg());
        } else {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_FAILED.getStatus(),
                    StatusMsgEnum.ADD_FAILED.getMsg());
        }
        return resp;
    }

    @ApiOperation(value = "修改角色", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseBean updateRole(@RequestBody Role role) {
        ResponseBean res = null;
        Role newRole = (Role) roleCommonEntityService.update(role);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        res.getData().put("role", newRole);
        return res;
    }

    @ApiOperation(value = "删除角色", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseBean deleteRole(@RequestParam Integer roleId) {
        ResponseBean resp = null;
        if (roleId == null) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return resp;
        }
        roleCommonEntityService.delete(Role.class, roleId);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.DELETE_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return resp;
    }
}
