package com.fastsun.framework.service.impl;

import com.fastsun.framework.entity.queryTemplate.MetaObject;
import com.fastsun.framework.jpa.MetaFieldJPA;
import com.fastsun.framework.jpa.MetaObjectJPA;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Service
public class CommonChooseBuilder {
    @Value("${spring.jpa.database}")
    private String database;

    @Autowired
    @PersistenceContext
    private EntityManager entityManager;

    private Session session;
    @Autowired
    private MetaFieldJPA metaFieldJPA;

    @Autowired
    private MetaObjectJPA metaObjectJPA;

    /**
     * 得到简单的sql ，在后台补 where
     *
     * @param
     * @return select * from emp where epd=[aaa] and guid={javaGuid}
     */
    public List getDataSet(String objectCode, String exp) throws Exception {

        //-----------根据 queryCode 得到 mataobject
        MetaObject mobj = metaObjectJPA.findByObjectCode(objectCode);
        // 用户编辑的sql
        String osql = mobj.getQuerySql();
        String sql = osql + " " + exp;

        return querySql(sql);
    }

    //查询返回List object
    public List querySql(String jpql) {
        session = entityManager.unwrap(Session.class);

        NativeQuery query = session.createNativeQuery(jpql);
        query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);

        List result = query.getResultList();
        return result;
    }


}
