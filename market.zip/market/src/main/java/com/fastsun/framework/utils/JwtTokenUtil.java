package com.fastsun.framework.utils;


import com.fastsun.framework.bean.JwtUser;
import com.fastsun.framework.config.Config;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class JwtTokenUtil {

          @Autowired
          private Config config;

//          public String generate(String username){
//              try {
//                  Algorithm algorithm = Algorithm.HMAC256(config.getJwt().getSecret());
//                  String token = JWT.create()
//                          .withIssuer(config.getJwt().getIssuer())
//                          .withIssuedAt(new Date())
//                          .withExpiresAt(new Date(System.currentTimeMillis() + config.getJwt().getExpiration() * 1000))
//                          .withSubject(username)
//                          .sign(algorithm);
//                  return token;
//              } catch (Exception e) {
//                  e.printStackTrace();
//                  return  null;
//              }
//          }
//
//          public String verify(String token){
//              try {
//                  Algorithm algorithm = Algorithm.HMAC256(config.getJwt().getSecret());
//                  JWTVerifier verifier = JWT.require(algorithm).withIssuer(config.getJwt().getIssuer()).build();
//                  DecodedJWT jwt = verifier.verify(token);
//                  return jwt.getSubject();
//              } catch (Exception e) {
//                  e.printStackTrace();
//                  return null;
//              }
//          }

            /**
             * 从数据声明生成令牌
             *
             * @param claims 数据声明
             * @return 令牌
             */
            private String generateToken(Map<String, Object> claims) {
                Date expirationDate = new Date(System.currentTimeMillis() + 7200 * 1000 * 100);
                return Jwts.builder().setClaims(claims).setExpiration(expirationDate).signWith(SignatureAlgorithm.HS256, config.getJwt().getSecret()).compact();
            }

            /**
             * 从令牌中获取数据声明
             *
             * @param token 令牌
             * @return 数据声明
             */
            public Claims getClaimsFromToken(String token) {
                Claims claims;
                try {
                    claims = Jwts.parser().setSigningKey(config.getJwt().getSecret()).parseClaimsJws(token).getBody();
                } catch (Exception e) {
                    claims = null;
                }
                return claims;
            }

            /**
             * 生成令牌
             *
             * @param
             * @return 令牌
             */
            public String generateToken(String userName) {
                Map<String, Object> claims = new HashMap<>(2);
                claims.put("sub", userName);
                claims.put("created", new Date());
                return generateToken(claims);
            }
            /**
             * 生成令牌,根据不同的用户生成令牌
             *
             * @param
             * @return 令牌
             */
            public String generateToken(String userName,String autidence) {
                Map<String, Object> claims = new HashMap<>(3);
                claims.put("sub", userName);
                claims.put("aud", autidence);
                claims.put("created", new Date());
                return generateToken(claims);
            }

            /**
             * 从令牌中获取用户名
             *
             * @param token 令牌
             * @return 用户名
             */
            public String getUsernameFromToken(String token) {
                String username;
                try {
                    Claims claims = getClaimsFromToken(token);
                    username = claims.getSubject();
                } catch (Exception e) {
                    username = null;
                }
                return username;
            }


            /**
             * 判断令牌是否过期
             *
             * @param token 令牌
             * @return 是否过期
             */
            public Boolean isTokenExpired(String token) {
                try {
                    Claims claims = getClaimsFromToken(token);
                    Date expiration = claims.getExpiration();
                    return expiration.before(new Date());
                } catch (Exception e) {
                    return false;
                }
            }

            /**
             * 刷新令牌
             *
             * @param token 原令牌
             * @return 新令牌
             */
            public String refreshToken(String token) {
                String refreshedToken;
                try {
                    Claims claims = getClaimsFromToken(token);
                    claims.put("created", new Date());
                    refreshedToken = generateToken(claims);
                } catch (Exception e) {
                    refreshedToken = null;
                }
                return refreshedToken;
            }

            /**
             * 验证令牌
             *
             * @param token       令牌
             * @param userDetails 用户
             * @return 是否有效
             */

    public Boolean validateToken(String token, UserDetails userDetails) {
        JwtUser user = (JwtUser) userDetails;
        String username = getUsernameFromToken(token);
        return (username.equals(user.getUsername()) && !isTokenExpired(token));
    }
}
