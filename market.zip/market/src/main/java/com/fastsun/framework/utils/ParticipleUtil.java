package com.fastsun.framework.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ParticipleUtil {
    //计算两个字符串的差异值
    //计算两个字符串的差异值
    public static int getLevenshteinDistance(String s, String t) {
        if (s == null || t == null) {
            //容错，抛出的这个异常是表明在传参的时候，传递了一个不合法或不正确的参数。 好像都这样用，illegal:非法。Argument:参数，证据。
            throw new IllegalArgumentException("Strings must not be null");
        }
        if(s.length()>=t.length()+2){
            s.substring(0,t.length());
        }
        //计算传入的两个字符串S长度
        int n = s.length();
        int m = t.length();
        //容错，直接返回结果。这个处理不错
        if (n == 0) {
            return m;
        } else if (m == 0) {
            return n;
        }
        //这一步是根据字符串长短处理，处理后t为长字符串，s为短字符串，方便后面处理
        if (n > m) {
            String tmp = s;
            s = t;
            t = tmp;
            n = m;
            m = t.length();
        }
        //开辟一个字符数组，这个n是短字符串的长度
        int p[] = new int[n + 1];
        int d[] = new int[n + 1];
        //用于交换p和d的数组
        int _d[];
        int i;
        int j;
        char t_j;
        int cost;
        //赋初值
        for (i = 0; i <= n; i++) {
            p[i] = i;
        }
        for (j = 1; j <= m; j++) {
            //t是字符串长的那个字符
            t_j = t.charAt(j - 1);
            d[0] = j;
            for (i = 1; i <= n; i++) {
                //计算两个字符是否一样，一样返回0。
                cost = s.charAt(i - 1) == t_j ? 0 : 1;
                //可以将d的字符数组全部赋值。
                d[i] = Math.min(Math.min(d[i - 1] + 1, p[i] + 1), p[i - 1] + cost);
            }
            //交换p和d
            _d = p;
            p = d;
            d = _d;
        }
        //最后的一个值即为差异值
        return p[n];
    }

    public static String moneySmartConvert(String text) {
        text = text.replaceAll("九", "9");
        text = text.replaceAll("八", "8");
        text = text.replaceAll("七", "7");
        text = text.replaceAll("六", "6");
        text = text.replaceAll("五", "5");
        text = text.replaceAll("四", "4");
        text = text.replaceAll("三", "3");
        text = text.replaceAll("二", "2");
        text = text.replaceAll("一", "1");
        text = text.replaceAll("零", "0");
        int sum = 0;
        int y_index = text.indexOf("亿");// 亿级别下标
        int w_index = text.indexOf("万");// 万级别下标
        String tempStr = "";
        // 处理亿级别
        if (y_index != -1) {
            tempStr = text.substring(0, y_index + 1);// 因为substring不包括参数二的范围，故需要+1
            sum = disposeNumUnit(tempStr,"亿",sum, 8);// 亿级别的0个数为8
        }

        // 处理万级别
        if (w_index != -1) {
            tempStr = text.substring(y_index + 1, w_index + 1);
            sum = disposeNumUnit(tempStr,"万",sum, 4);// 万级别的0个数为4

        }
        // 处理索引下标，供千级别使用
        if (w_index == -1) {
            if (y_index != -1) {
                w_index = y_index;
            } else {
                w_index = 0;
            }
        }
        // 处理千、百、十、个级别
        if (w_index < text.length()) {
            tempStr = text.substring(w_index==0?0:w_index+1, text.length());
            sum = disposeNumUnit(tempStr,null, sum, 0);
        }
        return sum + "";
    }

    // 处理数值的单位。将转换数值后的结果相加再返回。
    // content为需要转换字符内容，numUnit为数值单位，sum
    // 为用户计算转换后的数值(最后作为返回值返回)，baseZeroCount为数值单位需要补足的零个数
    private static int disposeNumUnit(String content, String numUnit, int sum,
                                      int baseZeroCount) {
        StringBuilder zeroStr = new StringBuilder();
        int tempInt = -1;
        String tempStr = "";
        Pattern pattern = null;
        Matcher matcher = null;
        for (int i = 0; i < baseZeroCount; i++) {
            zeroStr.append("0");
        }
        // ------------------------------处理千位------------------------------------
        if ((tempInt = content.indexOf("千")) != -1) {
            tempStr = content.substring(0, tempInt + 1);
            sum += Integer.parseInt(tempStr.replace("千", "000" + zeroStr));// 千单位的补足3个0+数值单位的0
        }
        // ------------------------------处理百位------------------------------------
        if ((tempInt = content.indexOf("百")) != -1) {
            tempStr = content.substring(tempInt == 0 ? 0 : tempInt - 1,
                    tempInt + 1);
            sum += Integer.parseInt(tempStr.replace("百", "00" + zeroStr));// 百为单位的补足2个0+数值单位的0
        }
        // ------------------------------处理十位-----------------------------------
        if ((tempInt = content.indexOf("十")) != -1) {
            tempStr = content.substring(tempInt == 0 ? 0 : tempInt - 1,
                    tempInt + 1);
            pattern = Pattern.compile("[123456789]十");
            matcher = pattern.matcher(tempStr);
            if (matcher.find()) {
                sum += Integer.parseInt(tempStr.replace("十", "0" + zeroStr));// 十为单位的补足1个0+数值单位的0
            } else {
                tempStr = content.substring(tempInt,
                        tempInt + 1);
                sum += Integer.parseInt(tempStr.replace("十", "10" + zeroStr));// 如果十前面没数值，表示十是数字，前缀加1，再补足1个0++数值单位的0
            }
        }
        // ------------------------------处理个位------------------------------------
        if (numUnit == null || "".equals(numUnit.trim())) {
            pattern = Pattern.compile("[123456789]$");
            matcher = pattern.matcher(content);
            if (matcher.find()) {
                String str = matcher.group();
                tempInt = content.lastIndexOf(str);// 个位应从末尾找
                tempStr = content.substring(tempInt,content.length());
                sum += Integer.parseInt(tempStr);// 个位的单位的只需补足数值单位的0
            }
        } else {
            pattern = Pattern.compile("[123456789]" + numUnit);
            matcher = pattern.matcher(content);
            if (matcher.find()) {
                String str = matcher.group();
                tempInt = content.lastIndexOf(str);// 个位应从末尾找
                tempStr = content.substring(tempInt, tempInt + 2 > content
                        .length() ? content.length() : tempInt + 2);
                sum += Integer.parseInt(tempStr.replace(numUnit, zeroStr));// 个位的单位的只需补足数值单位的0
            }
        }
        return sum;
    }

    public static String[] moneyAndWeight(String text){
        String[] arr= text.split("元");
        String price = arr[0];
        String w = arr[1];
        while(!Character.isDigit(w.charAt(0))){
            w = w.substring(1);
        }
        while(!Character.isDigit(w.charAt(w.length()-1))){
            w = w.substring(0,w.length()-1);
        }
        while(!Character.isDigit(price.charAt(0))){
            price = price.substring(1);
        }
        while(!Character.isDigit(price.charAt(price.length()-1))){
            price = price.substring(0,w.length()-1);
        }
        arr[0] = price;
        arr[1] = w;
        return arr;
    }
}
