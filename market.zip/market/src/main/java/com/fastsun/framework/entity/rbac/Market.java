package com.fastsun.framework.entity.rbac;


import com.fastsun.framework.entity.queryTemplate.EntityMetaData;
import com.fastsun.framework.entity.queryTemplate.FieldMetaData;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name = "market")
@EntityMetaData(objectName = "市场表",pkKey = "mktId")
public class Market implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer mktId;
    @NotBlank(message = "密码不能为空")
    @Column(nullable = false, length = 30)
    @FieldMetaData(recno=1,alias = "市场名称",isQuery = true,displayWidth = 30)
    private String mktName;
    @Column(nullable = true, length = 20)
    @FieldMetaData(recno=2,alias = "电话号码",isQuery = true,displayWidth = 30)
    private String telephone;
    @Column(nullable = true, length = 20)
    private String province;
    @Column(nullable = true, length = 20)
    private String city;
    @Column(nullable = true, length = 20)
    private String area;
    private BigDecimal lat;
    private BigDecimal lng;
    private Integer status;
    @Column(nullable = true, length = 100)
    private String licenseUrl;
    @Column(nullable = true, length = 10)
    private String legalPeson;
    @Column(nullable = true, length = 20)
    private String legalPhone;
    @Column(nullable = true, length = 200)
    private String menuIds;
    @Column(nullable = true, length = 10)
    private Integer creatorId;
    @Column(nullable = true, length = 10)
    private Integer auditorBy;
    @Column(nullable = true, length = 100)
    private Timestamp auditorTime;
    @Column(nullable = true, length = 2)
    private Integer auditorStatus;
    @Column(nullable = true, length = 100)
    private String auditorDesc;
    @Column()
    public BigDecimal balance = new BigDecimal(100);

    public Market() {
    }
    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }

    public String getMktName() {
        return mktName;
    }

    public void setMktName(String mktName) {
        this.mktName = mktName;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public BigDecimal getLat() {
        return lat;
    }

    public void setLat(BigDecimal lat) {
        this.lat = lat;
    }

    public BigDecimal getLng() {
        return lng;
    }

    public void setLng(BigDecimal lng) {
        this.lng = lng;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getLicenseUrl() {
        return licenseUrl;
    }

    public void setLicenseUrl(String licenseUrl) {
        this.licenseUrl = licenseUrl;
    }

    public String getLegalPeson() {
        return legalPeson;
    }

    public void setLegalPeson(String legalPeson) {
        this.legalPeson = legalPeson;
    }

    public String getLegalPhone() {
        return legalPhone;
    }

    public void setLegalPhone(String legalPhone) {
        this.legalPhone = legalPhone;
    }

    public String getMenuIds() {
        return menuIds;
    }

    public void setMenuIds(String menuIds) {
        this.menuIds = menuIds;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public Integer getAuditorBy() {
        return auditorBy;
    }

    public void setAuditorBy(Integer auditorBy) {
        this.auditorBy = auditorBy;
    }

    public Timestamp getAuditorTime() {
        return auditorTime;
    }

    public void setAuditorTime(Timestamp auditorTime) {
        this.auditorTime = auditorTime;
    }

    public Integer getAuditorStatus() {
        return auditorStatus;
    }

    public void setAuditorStatus(Integer auditorStatus) {
        this.auditorStatus = auditorStatus;
    }

    public String getAuditorDesc() {
        return auditorDesc;
    }

    public void setAuditorDesc(String auditorDesc) {
        this.auditorDesc = auditorDesc;
    }
}
