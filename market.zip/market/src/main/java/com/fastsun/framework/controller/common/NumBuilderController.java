package com.fastsun.framework.controller.common;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.service.impl.OrderNoServiceImpl;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

// @Api(value = "numBuilder",description = "序号生成")
@Api(description = "序号生成器", tags = { "framework.common.NumBuilder" })
@RestController
@RequestMapping("/api/public")
public class NumBuilderController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(NumBuilderController.class);
    @Autowired
    private OrderNoServiceImpl orderNoServiceImpl;

    private ResponseBean responseBean;

    @ApiOperation(value = "获取序号", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/getOrderNo", method = RequestMethod.GET)
    public ResponseBean getNumber(@RequestParam String key) {
        Integer orderNo = this.orderNoServiceImpl.getOrderNo(key);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        responseBean.getData().put("orderNo", orderNo);
        return responseBean;
    }
}
