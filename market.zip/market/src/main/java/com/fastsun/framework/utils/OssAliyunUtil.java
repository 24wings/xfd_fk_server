package com.fastsun.framework.utils;

import com.aliyun.oss.ClientException;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSException;
import com.aliyun.oss.model.CannedAccessControlList;
import com.aliyun.oss.model.CreateBucketRequest;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyun.oss.model.PutObjectResult;
import com.fastsun.market.entity.common.OssFile;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class OssAliyunUtil {
    private final static Logger log = LogManager.getLogger(OssAliyunUtil.class);
    private static String END_POINT = "http://oss-cn-hangzhou.aliyuncs.com";
    private static String ACCESS_KEY_ID = "LTAIgxVVBoyDegoq";
    private static String ACCESS_KEY_SECRET = "OwjalRKGrFU3QBpiOAH7WMB8UWXRC5";
    private static String BUCKET_NAME = "mryuhl";
    // 文件访问域名
    private static String FILE_HOST = "http://mryuhl.oss-cn-hangzhou.aliyuncs.com/";

    /**
     * 方法描述:上传文件
     *
     * @author leon 2016年12月16日 上午11:40:34
     * @param file 文件对象
     * @return
     */
    public static OssFile upload(File file) {
        OssFile ossFile = new OssFile();

        if (file == null) {
            return null;
        }
        // 创建OSS客户端
        OSSClient ossClient = new OSSClient(END_POINT, ACCESS_KEY_ID, ACCESS_KEY_SECRET);
        try {
            // 判断文件容器是否存在，不存在则创建
            if (!ossClient.doesBucketExist(BUCKET_NAME)) {
                ossClient.createBucket(BUCKET_NAME);
                CreateBucketRequest createBucketRequest = new CreateBucketRequest(BUCKET_NAME);
                createBucketRequest.setCannedACL(CannedAccessControlList.PublicRead);
                ossClient.createBucket(createBucketRequest);
            }
            // 创建文件路径
            String fileName = UUID.randomUUID().toString();
            ossFile.setFileName(fileName);
            String fileUrl = new SimpleDateFormat("yyyyMMdd").format(new Date()) + "/" + fileName + ".png";
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(BUCKET_NAME, fileUrl, file));
            if (null != result) {
                ossFile.setFileUrl(FILE_HOST + fileUrl);
                return ossFile;
            }
        } catch (OSSException oe) {
            log.error(oe.getMessage());
        } catch (ClientException ce) {
            log.error(ce.getMessage());
        } finally {
            // 关闭OSS服务，一定要关闭
            ossClient.shutdown();
        }
        return ossFile;
    }

    /**
     * 方法描述:上传文件
     *
     * @author leon 2016年12月26日 下午3:33:13
     * @param inputStream 文件流
     * @return
     * @throws FileNotFoundException
     */
    public static OssFile upload(InputStream inputStream) throws FileNotFoundException {
        OssFile ossFile = new OssFile();
        if (inputStream == null) {
            return null;
        }
        // 创建OSS客户端
        OSSClient ossClient = new OSSClient(END_POINT, ACCESS_KEY_ID, ACCESS_KEY_SECRET);
        try {
            // 判断文件容器是否存在，不存在则创建
            if (!ossClient.doesBucketExist(BUCKET_NAME)) {
                ossClient.createBucket(BUCKET_NAME);
                CreateBucketRequest createBucketRequest = new CreateBucketRequest(BUCKET_NAME);
                createBucketRequest.setCannedACL(CannedAccessControlList.PublicRead);
                ossClient.createBucket(createBucketRequest);
            }
            // 创建文件路径
            String fileName = UUID.randomUUID().toString();
            ossFile.setFileName(fileName);
            String fileUrl = new SimpleDateFormat("yyyyMMdd").format(new Date()) + "/" + fileName + ".png";
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(BUCKET_NAME, fileUrl, inputStream));
            if (null != result) {
                ossFile.setFileUrl(FILE_HOST + fileUrl);

            }
        } catch (OSSException oe) {
            log.error(oe.getMessage());
        } catch (ClientException ce) {
            log.error(ce.getMessage());
        } finally {
            // 关闭OSS服务，一定要关闭
            ossClient.shutdown();
        }
        return ossFile;

    }

}