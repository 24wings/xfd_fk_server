package com.fastsun.framework.controller.common;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.common.OssFile;
import com.fastsun.market.service.SmsService;
import com.fastsun.framework.utils.ImageUtil;
import com.fastsun.framework.utils.OssAliyunUtil;
import com.fastsun.market.utils.StatusMsgEnum;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Api(description = "文件下载", tags = { "framework.common.FileUpload" })
@RestController
@RequestMapping(value = "/common")
public class FileUploadController extends BaseController {

    @ApiOperation(value = "获取市场分页列表", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/msn", method = RequestMethod.GET)
    public ResponseBean listMarket() {
        ResponseBean res = ResponseUtil.createRespBean(true, 200, StatusMsgEnum.QUERY_SUCCESS.getMsg());

        try {
            SendSmsResponse data = SmsService.sendSms();
            res.getData().put("markets", data);
            return res;
        } catch (Exception e) {
            System.out.println(e.toString());

        }
        res.getData().put("markets", "false");
        return res;
    }

    @ApiOperation(value = "下载图片", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/upload-image", method = RequestMethod.POST)
    public ResponseBean upload(HttpServletRequest request, HttpServletResponse response) {
        ResponseBean resp = null;

        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(
                request.getSession().getServletContext());
        OssFile ossFile = null;
        if (multipartResolver.isMultipart(request)) {
            MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
            Iterator<String> iter = multiRequest.getFileNames();
            while (iter.hasNext()) {
                MultipartFile file = multiRequest.getFile(iter.next());
                if (file != null) {
                    String fileName = file.getOriginalFilename();
                    if (fileName.trim() != "") {
                        File newFile = new File(fileName);
                        try {
                            FileOutputStream fos = new FileOutputStream(newFile);
                            fos.write(file.getBytes());
                            fos.close();
                            file.transferTo(newFile);
                            ossFile = OssAliyunUtil.upload(newFile);

                            newFile.delete();
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }
            }
            resp = ResponseUtil.createRespBean(true, 200, "success!");
            resp.getData().put("result", ossFile);
            return resp;
        }
        String base64 = null;
        try {
            BufferedReader streamReader = new BufferedReader(new InputStreamReader(request.getInputStream(), "UTF-8"));
            // 写入数据到Stringbuilder
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = streamReader.readLine()) != null) {
                sb.append(line);
            }
            JSONObject json = JSON.parseObject(sb.toString());
            base64 = json.get("base64").toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (base64 != null) {
            try {
                ossFile = OssAliyunUtil.upload(ImageUtil.convertFileIO(base64));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        resp = ResponseUtil.createRespBean(true, 200, "success!");
        resp.getData().put("result", ossFile);
        return resp;
    }
}
