package com.fastsun.framework.entity.rbac;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "menu")
public class Menu implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer menuId;
    @NotBlank(message = "菜单文本不能为空")
    @Column(nullable = false)
    private String text;
    @Column(nullable = true,length = 10)
    private String i18n;
    @Column(nullable = true)
    private Integer parentId;
    @Column(nullable = true,length = 64)
    private String link;
    @Column(nullable = true,length = 64)
    private String externalink;
    @Column(nullable = true,length = 10)
    private String target;
    @Column(nullable = true,length = 40)
    private String icon;
    @Column(nullable = true)
    private Integer badge;
    @Column(nullable = true)
    private Boolean badge_dot;
    @Column(nullable = true,length = 20)
    private String badge_status;
    @Column(nullable = true)
    private Integer hide;
    @Column(nullable = true)
    private Integer hideInBreadcrumb;
    private String acl;
    @Column(nullable = true)
    private Integer shortcut;
    @Column(nullable = true)
    private Integer shortcut_root;
    @Column(nullable = true)
    private Integer reuse;
    @Column(nullable = false)
    private Integer menuType;
    @Column(nullable = true)
    private Integer creatorId;
    @Column(nullable = true,length = 2000)
    private String config;
    @Column(nullable = true,length = 20)
    private String menuCode;
    @ManyToMany(fetch = FetchType.LAZY,mappedBy = "menus")
    @JsonBackReference
    private List<Role> roles;

    public Menu(){}

    public Integer getMenuId() {
        return menuId;
    }

    public void setMenuId(Integer menuId) {
        this.menuId = menuId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getI18n() {
        return i18n;
    }

    public void setI18n(String i18n) {
        this.i18n = i18n;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getExternalink() {
        return externalink;
    }

    public void setExternalink(String externalink) {
        this.externalink = externalink;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public Integer getBadge() {
        return badge;
    }

    public void setBadge(Integer badge) {
        this.badge = badge;
    }

    public String getBadge_status() {
        return badge_status;
    }

    public void setBadge_status(String badge_status) {
        this.badge_status = badge_status;
    }

    public Integer getHide() {
        return hide;
    }

    public void setHide(Integer hide) {
        this.hide = hide;
    }

    public Integer getHideInBreadcrumb() {
        return hideInBreadcrumb;
    }

    public void setHideInBreadcrumb(Integer hideInBreadcrumb) {
        this.hideInBreadcrumb = hideInBreadcrumb;
    }

    public String getAcl() {
        return acl;
    }

    public void setAcl(String acl) {
        this.acl = acl;
    }

    public Integer getShortcut() {
        return shortcut;
    }

    public void setShortcut(Integer shortcut) {
        this.shortcut = shortcut;
    }

    public Integer getShortcut_root() {
        return shortcut_root;
    }

    public void setShortcut_root(Integer shortcut_root) {
        this.shortcut_root = shortcut_root;
    }

    public Integer getReuse() {
        return reuse;
    }

    public void setReuse(Integer reuse) {
        this.reuse = reuse;
    }

    public Integer getMenuType() {
        return menuType;
    }

    public void setMenuType(Integer menuType) {
        this.menuType = menuType;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public Boolean getBadge_dot() {
        return badge_dot;
    }

    public void setBadge_dot(Boolean badge_dot) {
        this.badge_dot = badge_dot;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }

    public String getMenuCode() {
        return menuCode;
    }

    public void setMenuCode(String menuCode) {
        this.menuCode = menuCode;
    }

}
