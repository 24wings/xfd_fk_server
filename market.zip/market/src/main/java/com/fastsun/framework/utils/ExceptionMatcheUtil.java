package com.fastsun.framework.utils;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.MethodArgumentNotValidException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

public class ExceptionMatcheUtil {

    public static String getErrorMessage(Exception ex) {
        if (ex instanceof ArithmeticException) {
            return "系统异常：计算错误";
        }
        if (ex instanceof NullPointerException) {
            return "系统异常：输入错误，缺少输入值";
        }
        if (ex instanceof ClassCastException) {
            return "系统异常：类型转换错误";
        }
        if (ex instanceof NegativeArraySizeException) {
            return "系统异常：集合负数";
        }
        if (ex instanceof ArrayIndexOutOfBoundsException) {
            return "系统异常：集合超出范围";
        }
        if (ex instanceof FileNotFoundException) {
            return "系统异常：文件未找到";
        }
        if (ex instanceof NumberFormatException) {
            return "系统异常：输入数字错误";
        }
        if (ex instanceof SQLException) {
            return "系统异常：数据库异常";
        }
        if (ex instanceof IOException) {
            return "系统异常：文件读写错误";
        }
        if (ex instanceof NoSuchMethodException) {
            return "系统异常：方法找不到";
        }
        if (ex instanceof java.util.NoSuchElementException){
            return "系统异常 ：没有对应的值";
        }
        if (ex instanceof javax.persistence.PersistenceException){
            return "系统异常 ：sql语句错误！";
        }
        if(ex instanceof org.hibernate.exception.DataException){
            return "系统异常：无法执行语句";
        }
        if(ex instanceof org.springframework.http.converter.HttpMessageNotReadableException){
            return "系统异常：传入参数转换错误";
        }
        if(ex instanceof org.springframework.web.bind.MethodArgumentNotValidException){
            return ((MethodArgumentNotValidException) ex).getBindingResult().getAllErrors().get(0).getDefaultMessage();
        }
        String message = null ;
        if(ex.getCause()!=null){
            message = checkKnowException(ex.getCause().toString());
        }

        if(!StringUtils.isEmpty(message)){
            return message;
        }
        return ex.getMessage();
    }
    /*
     *  map中检索是否能匹配当前异常
     */
    private static String checkKnowException(String cause){

            if(cause.indexOf("org.hibernate.exception.DataException") != -1){
                 return "系统异常：无法执行语句";
            }

        return  "";
    }

}
