package com.fastsun.framework.entity.sysConfig;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Date;

@Table(name = "user_log")
@Entity
public class UserLog implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false)
    private Integer level = 0;//日志等级
    @Column(nullable = false)
    private String logType;//日志类型
    @Column(nullable = false)
    private String title;//日志摘要
    @Column(nullable = false)
    private String content;//日志内容
    private String entity;//操作实体名称
    private String entityJson;//操作实体内容
    @Column(nullable = false)
    private Date createTime;//创建时间
    @Column(nullable = false)
    private Integer creatorId;
    @Column(nullable = false)
    private String creator;//操作员姓名
    private Integer mktId;//市场id,为空时是平台级日志

    public UserLog() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLogType() {
        return logType;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    public String getEntityJson() {
        return entityJson;
    }

    public void setEntityJson(String entityJson) {
        this.entityJson = entityJson;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }
}