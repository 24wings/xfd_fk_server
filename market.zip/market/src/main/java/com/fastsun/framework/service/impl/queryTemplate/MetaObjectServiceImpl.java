package com.fastsun.framework.service.impl.queryTemplate;

import com.fastsun.framework.entity.queryTemplate.MetaField;
import com.fastsun.framework.entity.queryTemplate.MetaObject;
import com.fastsun.framework.jpa.MetaFieldJPA;
import com.fastsun.framework.jpa.MetaObjectJPA;
import com.fastsun.framework.jpa.base.SimpleSpecificationBuilder;
import com.fastsun.framework.service.impl.BaseServiceImpl;
import com.fastsun.framework.service.impl.CommonEntityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MetaObjectServiceImpl extends BaseServiceImpl<MetaObject, Integer, MetaObjectJPA> {

    @Autowired
    private MetaFieldJPA metaFieldJPA;

    @Autowired
    private MetaObjectJPA metaObjectJPA;
    @Autowired
    private CommonEntityService commonEntityService;
    /*
     * 根据objectCode查询元数据
     */
    public MetaObject findByObjectCode(String objectCode) {
        MetaObject metaObject = metaObjectJPA.findByObjectCode(objectCode);
        if (metaObject == null) {
            throw new NullPointerException("objectCode查询元数据为空！");
        }
        return metaObject;
    }

    /*
     * 删除元数据，同时删除metaField表中相关联的数据
     */
    public void deleteByObjectCode(String objectCode) {
        metaObjectJPA.deleteByObjectCode(objectCode);
    }

    /*
     * 更新元数据
     */
    public MetaObject updateMataObject(MetaObject metaObject) {
        List<MetaField> metaFields = metaObject.getMetaFields();
        MetaField metaField = null;
        for (int i = 0; i < metaFields.size(); i++) {
            metaField = metaFields.get(i);
            metaField.setMetaObject(metaObject);
//            metaFieldJPA.save(metaField);
        }
        return (MetaObject) this.commonEntityService.update(metaObject);
    }

    // :TODO 需要修改成通用的分页查询接口
    public List<MetaObject> findAllToList() {
        List<MetaObject> metaObjects = this.findAll();
        return metaObjects;
    }

    /*
     * 查询所有，按groupName分组，返给前端一个Map
     */
    public Map<String, List<MetaObject>> findAllToMap() {
        List<MetaObject> matas = this.findAll();
        Map<String, List<MetaObject>> maps = new HashMap<String, List<MetaObject>>();
        for (MetaObject m : matas) {
            String groupName = m.getGroupName();
            if (maps.get(groupName) != null) {
                List<MetaObject> list = maps.get(groupName);
                list.add(m);
                maps.put(groupName, list);
                continue;
            }
            List<MetaObject> lists = new ArrayList<MetaObject>();
            lists.add(m);
            maps.put(groupName, lists);
        }
        return maps;
    }

    /*
     * 保存元数据
     */
    public MetaObject save(MetaObject metaObject) {
        List<MetaField> metaFields = metaObject.getMetaFields();
        MetaField metaField = null;
        for (int i = 0; i < metaFields.size(); i++) {
            metaField = metaFields.get(i);
            metaField.setMetaObject(metaObject);
            metaObject.addMetaField(metaField);
        }
        return metaObjectJPA.saveAndFlush(metaObject);
    }

    /*
     * 新增元数据时，根据objectCode判重
     */
    public Long count(MetaObject metaObject) {
        SimpleSpecificationBuilder ssb = new SimpleSpecificationBuilder<>("objectCode", "=",
                metaObject.getObjectCode());
        return this.baseRepository.count(ssb.generateSpecification());
    }
}
