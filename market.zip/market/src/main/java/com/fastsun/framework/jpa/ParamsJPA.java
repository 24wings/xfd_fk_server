package com.fastsun.framework.jpa;

import com.fastsun.framework.entity.sysConfig.Params;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface ParamsJPA extends BaseRepository<Params,Integer>,JpaSpecificationExecutor<Params> {
    List<Params> findByParamKey(String paramKey);

    Page<Params> findAll(Specification<Params> specification, Pageable pageable);

    List<Params> findAll(Specification<Params> specification);
}
