package com.fastsun.framework.controller.base;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.utils.ExceptionMatcheUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class BaseController {

    private final static Logger logger = LoggerFactory.getLogger(BaseController.class);

    @ExceptionHandler()
    public ResponseBean errorHandler(Exception e){
        logger.error("系统异常",e);
        String m =ExceptionMatcheUtil.getErrorMessage(e);
        return ResponseUtil.createRespBean(false,-1,m);
    }
}