package com.fastsun.framework.bean;

import java.util.Map;

/**
 * restful 格式统一
 */
public class ResponseBean {

      private boolean ok;

      private int status;

      private String msg;

      private Map<String,Object> data;

      public ResponseBean(){}

    public ResponseBean(boolean ok, int status, String msg, Map<String, Object> data) {
        this.ok = ok;
        this.status = status;
        this.msg = msg;
        this.data = data;
    }

    public ResponseBean(boolean ok, int status, String msg) {
        this.ok = ok;
        this.status = status;
        this.msg = msg;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }
}
