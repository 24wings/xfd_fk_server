package com.fastsun.framework.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public class AuthcationServiceImpl {
    @Autowired
    public JwtUserDetailsServiceImpl userDetail;

    public UserDetails loadCustomer(Integer mktId, String mobi) {
        return this.userDetail.loadUserByUsername(mobi + "," + mktId + "#customer");
    }
}
