package com.fastsun.framework.controller.common;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.queryTemplate.MetaField;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.jpa.MetaFieldJPA;
import com.fastsun.framework.service.impl.CommonChooseBuilder;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(description = "通用选择", tags = { "framework.common.CommonChoose" })
@RestController
@RequestMapping("/api/chooser")
public class CommonChooseController {
    @Autowired
    private CommonChooseBuilder chooseService;
    @Autowired
    private MetaFieldJPA metaFieldJPA;

    @ApiOperation(value = "得到通用选择的数据", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/getChooseData", method = RequestMethod.GET)
    public ResponseBean GetChooseData(@RequestParam String objectCode, @RequestParam String sqlExt) throws Exception {
        ResponseBean resp = null;
        if (objectCode == null || sqlExt == null || objectCode == "" || sqlExt == "") {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return resp;
        }
        List dataSet = chooseService.getDataSet(objectCode, sqlExt);

        // 得到字段中英文对照给前台
        // ----- 根据查询名称查找相应的字段属性
        List<MetaField> mataFlds = this.metaFieldJPA.findByObjectCode(objectCode);
        // ----- 将list 转成 map 方便查找
        // Map<String, MetaField> mataMap =
        // mataFlds.stream().collect(Collectors.toMap(MetaField::getFieldName, a -> a,
        // (k1, k2) -> k1));

        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("fieldMap", mataFlds);
        resp.getData().put("result", dataSet);
        return resp;
    }

}
