package com.fastsun.framework.bean;

import com.fastsun.framework.entity.queryTemplate.MetaObject;
import net.sf.json.JSONObject;

public class MetaObjectDataRq {

    private MetaObject metaObject;
    private JSONObject dataItem;

    public MetaObjectDataRq(){}

    public MetaObject getMetaObject() {
        return metaObject;
    }

    public void setMetaObject(MetaObject metaObject) {
        this.metaObject = metaObject;
    }

    public JSONObject getDataItem() {
        return dataItem;
    }

    public void setDataItem(JSONObject dataItem) {
        this.dataItem = dataItem;
    }
}
