package com.fastsun.framework.service.impl.baseSetUp;
import org.springframework.stereotype.Service;
@Service
public class ParamsServiceImpl {

}
