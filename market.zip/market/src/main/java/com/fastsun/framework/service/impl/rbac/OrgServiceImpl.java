package com.fastsun.framework.service.impl.rbac;

import org.springframework.stereotype.Service;
@Service
public class OrgServiceImpl{


}
