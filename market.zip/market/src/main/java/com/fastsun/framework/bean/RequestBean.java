package com.fastsun.framework.bean;

public class RequestBean {

      private String userName;
      private String password;
      private Integer mktId;
      public RequestBean(){}

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
            return password;
      }

      public void setPassword(String password) {
            this.password = password;
      }

    public Integer getMktId() {
        return mktId;
    }

    public void setMktId(Integer mktId) {
        this.mktId = mktId;
    }
}
