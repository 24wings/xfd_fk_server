package com.fastsun.framework.service.impl.queryTemplate;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Created by ww on 2018-07-03 13:35 sql 中有函数的情况
 */
public class SqlMethods {

    /**
     * 反射调用java类
     *
     * @param methodName
     * @param args
     * @return
     * @throws Exception
     */
    public Object invokeMethod(String methodName, Object[] args) throws Exception {
        Class ownerClass = this.getClass();
        Class[] argsClass = new Class[args.length];
        for (int i = 0, j = args.length; i < j; i++) {
            argsClass[i] = args[i].getClass();
        }
        Method method = ownerClass.getMethod(methodName, argsClass);

        return method.invoke(this, args);
    }

    public String getGuid() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }
}
