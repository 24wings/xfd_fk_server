package com.fastsun.framework.bean;

public class MemberAccTuple<Member,Account> {

    public final Member first;
    public final Account second;

    public MemberAccTuple(Member first, Account second){
        this.first = first;
        this.second = second;
    }
}
