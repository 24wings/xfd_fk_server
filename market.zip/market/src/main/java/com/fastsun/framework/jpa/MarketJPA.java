package com.fastsun.framework.jpa;

import com.fastsun.framework.entity.rbac.Market;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface MarketJPA extends BaseRepository<Market, Integer>, JpaSpecificationExecutor<Market> {
      List<Market> findByMktName(String mktName);
}
