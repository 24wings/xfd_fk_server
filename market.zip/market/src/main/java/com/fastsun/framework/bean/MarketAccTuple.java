package com.fastsun.framework.bean;

public class MarketAccTuple<Market,Account> {
    public final Market first;
    public final Account second;

    public MarketAccTuple(Market first, Account second){
        this.first = first;
        this.second = second;
    }
}
