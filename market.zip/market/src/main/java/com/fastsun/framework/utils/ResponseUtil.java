package com.fastsun.framework.utils;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.jpa.base.SimpleSpecificationBuilder;

import java.lang.reflect.Field;
import java.util.*;

public class ResponseUtil {

    public static ResponseBean createRespBean(boolean ok, int status, String msg) {
        ResponseBean resp = new ResponseBean(ok, status, msg);
        Map<String, Object> map = new HashMap<String, Object>();
        resp.setData(map);
        return resp;
    }

    /*
     * 将origin中的属性合并到destination,简单Entity的属性合并(不含集合属性)
     */
    public static <T> void mergeObject(T origin, T destination) {
        if (origin == null || destination == null)
            return;
        if (!origin.getClass().equals(destination.getClass()))
            return;

        Field[] fields = origin.getClass().getDeclaredFields();
        // Field[] fieldDestination = origin.getClass().getDeclaredFields();
        Field field = null;
        for (int i = 0; i < fields.length; i++) {
            field = fields[i];
            try {
                field.setAccessible(true);
                Object value = field.get(origin);
                if (null != value) {
                    field.set(destination, value);
                }
                field.setAccessible(false);

            } catch (Exception e) {
            }
        }
    }

    /*
     * 将origin中的属性合并到destination,复杂Entity的属性合并，pkName为Entity的Id属性名
     */
    public static <T> void mergeObject(T origin, T destination, String pkName) {
        if (origin == null || destination == null)
            return;
        if (!origin.getClass().equals(destination.getClass()))
            return;

        Field[] fields = origin.getClass().getDeclaredFields();
        // Field[] fieldDestination = origin.getClass().getDeclaredFields();
        Field field = null;
        Field childField = null;
        for (int i = 0; i < fields.length; i++) {
            field = fields[i];
            try {
                if (List.class.isAssignableFrom(field.getType())) {
                    List listClient = new ArrayList<>();
                    listClient.addAll((Collection) field.get(origin));
                    List listDB = new ArrayList<>();
                    listDB.addAll((Collection) field.get(destination));

                    field.setAccessible(true);
                    field.set(destination, mergeList(listClient, listDB, pkName));
                    field.setAccessible(false);
                } else {
                    field.setAccessible(true);
                    Object value = field.get(origin);
                    if (null != value) {
                        field.set(destination, value);
                    }
                    field.setAccessible(false);
                }
            } catch (Exception e) {
            }
        }
    }

    public static <T> List<T> mergeList(List<T> origin, List<T> destination, String pkName) {
        Map<Integer, T> mapOrigin = new HashMap<>();
        for (T t : origin) {
            mapOrigin.put(getPKValue(t, pkName), t);
        }

        Map<Integer, T> mapDestination = new HashMap<>();
        for (T t : destination) {
            mapDestination.put(getPKValue(t, pkName), t);
        }

        for (T t : mapOrigin.values()) {
            T t2 = mapDestination.get(getPKValue(t, pkName));
            if (t2 != null) {
                mergeObject(t, t2);
            } else {
                destination.add(t2);
            }
        }

        for (T t : mapDestination.values()) {
            T t2 = mapOrigin.get(getPKValue(t, pkName));
            if (t2 == null) {
                mapDestination.remove(getPKValue(t, pkName));
            }
        }

        return destination;
    }

    public static <T> Integer getPKValue(T object, String pkName) {
        Integer index = null;
        pkName = pkName.substring(0, 1).toUpperCase() + pkName.substring(1);
        try {
            index = (Integer) object.getClass().getMethod("get" + pkName).invoke(object);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return index;
    }

    /*
     * pageParamList 为不加入查询参数中的参数集合
     */
    public static <T> SimpleSpecificationBuilder createSimpleSpecification(T object, List<String> pageParamList) {
        if (object == null)
            return null;
        // List<String> pageParamList = new ArrayList<>();{"page","pageSize","text"};
        SimpleSpecificationBuilder ssb = new SimpleSpecificationBuilder();
        Field[] fields = object.getClass().getDeclaredFields();
        Field field = null;
        for (int i = 0; i < fields.length; i++) {
            field = fields[i];
            try {
                Object value = field.get(object);
                String fieldName = field.getName();
                if (null != value && pageParamList.contains(fieldName)) {
                    ssb.add(fieldName, "=", value);
                }
            } catch (Exception e) {
            }
        }
        return ssb;
    }
}
