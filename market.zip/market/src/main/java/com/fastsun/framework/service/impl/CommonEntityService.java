package com.fastsun.framework.service.impl;

import com.fastsun.framework.bean.PageParameter;
import com.fastsun.framework.bean.QueryCondition;
import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.SummaryParameter;
import com.fastsun.framework.entity.queryTemplate.EntityMetaData;
import com.fastsun.framework.entity.queryTemplate.FieldMetaData;
import com.fastsun.framework.entity.queryTemplate.MetaField;
import com.fastsun.framework.entity.queryTemplate.MetaObject;
import com.fastsun.framework.service.impl.queryTemplate.SqlEntityService;
import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.utils.DateUtil;
import com.fastsun.framework.utils.ReflectUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;
import javax.persistence.criteria.*;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class CommonEntityService {
    @PersistenceContext
    protected EntityManager entityManager;

    public Paging findPagedEntity(QueryParameter queryParameter, String className) throws ClassNotFoundException {
        Class clazz=Class.forName(className);
        return findPagedEntity(queryParameter,clazz);
    }

    public Paging findPagedEntity(QueryParameter queryParameter, Class clazz){
        List<QueryCondition> queryConditions = queryParameter.getQueryConditions();
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery criteriaQuery = cb.createQuery(clazz);
        Root root = criteriaQuery.from(clazz);
        Predicate predicate = null;
        predicate = cb.conjunction();
        List<Predicate> andPredicates = new ArrayList<>();
        List<Predicate> orPredicates = new ArrayList<>();
        if (queryConditions != null) {
            for (int i = 0; i < queryConditions.size(); i++) {
                QueryCondition qc = queryConditions.get(i);
                if ("and".equals(qc.getAndOr())) {
                    andPredicates.add(getPredicateByCondition(root, cb, qc,clazz));
                }
                if ("or".equals(qc.getAndOr())) {
                    orPredicates.add(getPredicateByCondition(root, cb, qc,clazz));
                }
            }
            if (orPredicates != null && orPredicates.size() != 0) {
                predicate = cb.or(orPredicates.toArray(new Predicate[orPredicates.size()]));
            }
            if (andPredicates != null && andPredicates.size() != 0) {
                predicate = cb.and(andPredicates.toArray(new Predicate[andPredicates.size()]));
            }
        }
        //取得汇总及记录数数据
        Paging paging = new Paging();
        Object[] object = getSummaryValues(queryParameter,clazz);
        List<SummaryParameter> list = queryParameter.getSummaryParameters();
        for (int i = 1; i < object.length; i++) {
            list.get(i - 1).setSumValue(object[i]);
        }
        paging.setSummaryParameters(list);
        long recordCount = (long) object[0];
        paging.setCount(recordCount);
        criteriaQuery.select(root);
        if (predicate.getExpressions().size() != 0) {
            criteriaQuery = criteriaQuery.where(predicate);
        }
        PageParameter page=queryParameter.getPageParameter();
        if(page != null){
            if(page.getSortField()!= null && !page.getSortField().isEmpty()){
                if(page.getSortByAsc()){
                    criteriaQuery.orderBy(cb.asc(root.get(page.getSortField())));
                }else{
                    criteriaQuery.orderBy(cb.desc(root.get(page.getSortField())));
                }
            }
        }
        Query typedQuery = entityManager.createQuery(criteriaQuery);
        if(page!=null && page.getPageSize()!= 0){
            typedQuery.setFirstResult((page.getPageIndex())*page.getPageSize());
            typedQuery.setMaxResults(page.getPageSize());
        }
        List result =  typedQuery.getResultList();
        paging.setRows(result);
        return paging;
    }


    public long getRecordCount(QueryParameter queryParameter, Class clazz){
        return (long) getSummaryValues(queryParameter,clazz)[0];
    }

    public Object[] getSummaryValues(QueryParameter queryParameter, Class clazz){
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery query=cb.createQuery();
        Root root=query.from(clazz);
        query=query.select(root);

        List<QueryCondition> queryConditions=queryParameter.getQueryConditions();
        Predicate predicate = null;
        predicate = cb.conjunction();
        List<Predicate> andPredicates = new ArrayList<>();
        List<Predicate> orPredicates = new ArrayList<>();
        if (queryConditions != null) {
            for (int i = 0; i < queryConditions.size(); i++) {
                QueryCondition qc = queryConditions.get(i);
                if ("and".equals(qc.getAndOr())) {
                    andPredicates.add(getPredicateByCondition(root, cb, qc,clazz));
                }
                if ("or".equals(qc.getAndOr())) {
                    orPredicates.add(getPredicateByCondition(root, cb, qc,clazz));
                }
            }
            if (orPredicates != null && orPredicates.size() != 0) {
                predicate = cb.or(orPredicates.toArray(new Predicate[orPredicates.size()]));
            }
            if (andPredicates != null && andPredicates.size() != 0) {
                predicate = cb.and(andPredicates.toArray(new Predicate[andPredicates.size()]));
            }
        }
        if (predicate.getExpressions().size() != 0) {
            query = query.where(predicate);
        }
        List<Selection> selections=new ArrayList<>();
        Selection selection=cb.count(root);
        selections.add(selection);
        List<SummaryParameter> summarys = queryParameter.getSummaryParameters();
        if (summarys != null) {
            for (int i = 0; i < summarys.size(); i++) {
                SummaryParameter sp = summarys.get(i);
                switch (sp.getSumType().toUpperCase()) {
                    case "SUM":
                        selections.add(cb.sum(root.get(sp.getFieldName())));
                        break;
                    case "COUNT":
                        selections.add(cb.count(root.get(sp.getFieldName())));
                        break;
                    case "AVG":
                        selections.add(cb.avg(root.get(sp.getFieldName())));
                        break;
                    default:
                        break;
                }
            }
        }
        query = query.multiselect(selections);
        Object object = entityManager.createQuery(query).getSingleResult();
        if(object.getClass().isArray())
        {
            return (Object[]) object;
        }else{
            Object[] objects=new Object[1];
            objects[0]=object;
            return objects;
        }
    }

    @Transactional
    public boolean save(Object entity) {
        boolean flag = false;
        try {
            this.entityManager.persist(entity);
            flag = true;
        } catch (Exception e) {
            System.out.println("---------------保存出错---------------");
            throw e;
        }
        return flag;
    }

    @Transactional
    public Object update(Object entity) {
        Object object = this.entityManager.merge(entity);
        this.entityManager.flush();
        this.entityManager.clear();
        return object;
    }

    @Transactional
    public void delete(Object entity) {
        this.entityManager.remove(entity);
        this.entityManager.flush();
        this.entityManager.clear();
    }

    @Transactional
    public void delete(String className, Integer id) throws ClassNotFoundException {
        Class clazz = Class.forName(className);
        this.entityManager.remove(this.entityManager.find(clazz, id));
        this.entityManager.flush();
        this.entityManager.clear();
    }

    @Transactional
    public void delete(Class clazz, Integer id){
        this.entityManager.remove(this.entityManager.find(clazz, id));
        this.entityManager.flush();
        this.entityManager.clear();
    }

    public Object findById(String className, Integer id) throws ClassNotFoundException {
        Class clazz = Class.forName(className);
        return entityManager.find(clazz, id);
    }

    public Object findById(Class clazz,Integer id){
        return this.entityManager.find(clazz,id);
    }

    private Predicate getPredicateByCondition(Root root, CriteriaBuilder criteriaBuilder,
            QueryCondition queryCondition,Class clazz) {
        if ("in".equalsIgnoreCase(queryCondition.getCompare())) {
            Predicate predicate;
            String[]  strings=queryCondition.getValue().toString().split(",");
            predicate=criteriaBuilder.in(root.get(queryCondition.getField()));
            for (String s:strings) {
                predicate=((CriteriaBuilder.In) predicate).value(s);
            }
            return predicate;
        } else if ("=".equalsIgnoreCase(queryCondition.getCompare())) {
//            if(queryCondition.getValue() instanceof Number){
//                return criteriaBuilder.equal(root.get(queryCondition.getField()), queryCondition.getValue());
//            }
            if(ReflectUtil.getFieldTypeClass(clazz,queryCondition.getField()).isEnum()){
                Integer enumKey = ReflectUtil.getEnumKey(ReflectUtil.getFieldTypeClass(clazz,queryCondition.getField()),queryCondition.getValue());
                return criteriaBuilder.equal(root.get(queryCondition.getField()),enumKey);
            }
            return criteriaBuilder.equal(root.get(queryCondition.getField()), queryCondition.getValue());
        } else if (">=".equalsIgnoreCase(queryCondition.getCompare())) {
            if(queryCondition.getValue() instanceof Number){
                return criteriaBuilder.ge(root.get(queryCondition.getField()), (Number) queryCondition.getValue());
            }
            return criteriaBuilder.greaterThanOrEqualTo(root.<Date>get(queryCondition.getField()), DateUtil.parse(String.valueOf(queryCondition.getValue())));
        } else if ("<=".equalsIgnoreCase(queryCondition.getCompare())) {
            if(queryCondition.getValue() instanceof Number){
                return criteriaBuilder.le(root.get(queryCondition.getField()), (Number) queryCondition.getValue());
            }
            return criteriaBuilder.lessThanOrEqualTo(root.<Date>get(queryCondition.getField()),  DateUtil.parse(String.valueOf(queryCondition.getValue())));
        } else if (">".equalsIgnoreCase(queryCondition.getCompare())) {
            if(queryCondition.getValue() instanceof Number){
                return criteriaBuilder.gt(root.get(queryCondition.getField()),(Number) queryCondition.getValue());
            }
            return criteriaBuilder.greaterThan(root.<Date>get(queryCondition.getField()),  DateUtil.parse(String.valueOf(queryCondition.getValue())));
        } else if ("<".equalsIgnoreCase(queryCondition.getCompare())) {
            if(queryCondition.getValue() instanceof Number){
                return criteriaBuilder.lt(root.get(queryCondition.getField()),(Number) queryCondition.getValue());
            }
            return criteriaBuilder.lessThan(root.<Date>get(queryCondition.getField()),  DateUtil.parse(String.valueOf(queryCondition.getValue())));
        } else if (":".equalsIgnoreCase(queryCondition.getCompare())) {
            return criteriaBuilder.like(root.get(queryCondition.getField()), "%" + queryCondition.getValue() + "%");
        } else if ("l:".equalsIgnoreCase(queryCondition.getCompare())) {
            return criteriaBuilder.like(root.get(queryCondition.getField()), queryCondition.getValue() + "%");
        } else if (":l".equalsIgnoreCase(queryCondition.getCompare())) {
            return criteriaBuilder.like(root.get(queryCondition.getField()), "%" + queryCondition.getValue());
        } else if ("null".equalsIgnoreCase(queryCondition.getCompare())) {
            return criteriaBuilder.isNull(root.get(queryCondition.getField()));
        } else if ("!null".equalsIgnoreCase(queryCondition.getCompare())) {
            return criteriaBuilder.isNotNull(root.get(queryCondition.getField()));
        } else if ("!=".equalsIgnoreCase(queryCondition.getCompare())) {
            return criteriaBuilder.notEqual(root.get(queryCondition.getField()), queryCondition.getValue());
        }
        return null;
    }

    public MetaObject getEntityMetaObject(String className) throws ClassNotFoundException {
        MetaObject metaObject = new MetaObject();
        Class clz = Class.forName(className);
        EntityMetaData clzAnno= (EntityMetaData) clz.getDeclaredAnnotation(EntityMetaData.class);
        metaObject.setObjectCode(className);
        metaObject.setObjectName(clzAnno.objectName());
        Table tbAnno= (Table) clz.getDeclaredAnnotation(Table.class);
        if(tbAnno!=null){metaObject.setTableName(tbAnno.name());}
        metaObject.setConfig(clzAnno.config());
        metaObject.setDefaultOrder(clzAnno.defaultOrder());
        metaObject.setGroupName(clzAnno.groupName());
        metaObject.setPkKey(clzAnno.pkKey());
        metaObject.setParentKey(clzAnno.parentKey());

        ArrayList<MetaField> metaFields=new ArrayList<>();
        Field[] fields = clz.getDeclaredFields();
        int i=0;
        for (Field field : fields) {
            MetaField metaField=new MetaField();
            i++;
            metaField.setId(i);
            metaField.setObjectCode(metaObject.getObjectCode());
            metaField.setFieldName(field.getName());
            metaField.setPlaceholder(field.getName());
            metaField.setIsQuery(false);
            metaField.setIsShow(false);
            metaField.setIsUpdate(false);
            Id idAnno=field.getAnnotation(Id.class);
            if(idAnno!=null){
                metaObject.setPkKey(field.getName());
            }
            String type= SqlEntityService.getJdbcTypeByJava(field.getType().getTypeName());
            metaField.setFieldType(type);
            FieldMetaData metaAnno = field.getAnnotation(FieldMetaData.class);
            if (metaAnno!=null) {
                metaField.setRecno(metaAnno.recno());
                metaField.setAlias(metaAnno.alias());
                metaField.setConfig(metaAnno.config());
                metaField.setDisplayWidth(metaAnno.displayWidth());
                metaField.setIsQuery(metaAnno.isQuery());
                metaField.setIsShow(metaAnno.isShow());
                metaField.setIsUpdate(metaAnno.isUpdate());
                metaField.setPlaceholder(metaAnno.placeholder());
                metaField.setPresetValue(metaAnno.presetValue());
            }
            metaFields.add(metaField);
        }
        metaObject.setMetaFields(metaFields);
        return metaObject;
    }

}
