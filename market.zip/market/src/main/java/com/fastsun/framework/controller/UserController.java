package com.fastsun.framework.controller;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.rbac.Role;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.RequestUtil;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.service.impl.rbac.UserServiceImpl;
import com.fastsun.framework.bean.Paging;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.jpa.CustomerJPA;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import com.fastsun.market.utils.StatusMsgEnum;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@Api(description = "员工管理", tags = { "framework.User" })
@RestController
@RequestMapping("/api/employee")

public class UserController extends BaseController {

    private static final Logger LOGGER = LogManager.getLogger(UserController.class);

    @Autowired
    private UserServiceImpl userServiceImpl;

    @Autowired
    private CommonEntityService userCommonEntityService;
    @Autowired
    private CustomerJPA customerJPA;

    @ApiOperation(value = "创建员工", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    // @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseBean addEmployee(HttpServletRequest request, @Valid @RequestBody User user) {
        ResponseBean resp = null;
        if (user == null) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return resp;
        }
        long count = this.userCommonEntityService.getRecordCount(RequestUtil.getQueryParameter(user, "or", "userName"),
                User.class);
        if (count > 0) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_REPEAT.getStatus(),
                    StatusMsgEnum.ADD_REPEAT.getMsg());
            return resp;
        }
        userServiceImpl.saveEmployee(user,request);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        return resp;
    }

    @ApiOperation(value = "修改员工", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseBean updateEmployee(@RequestBody User user) {
        ResponseBean res = null;
        User newUser = (User) userCommonEntityService.update(user);
        //userServiceImpl.saveEmployee(user);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        res.getData().put("user",newUser);
        return res;
    }

    @ApiOperation(value = "删除员工", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseBean deleteEmployee(@RequestParam Integer epId) {
        ResponseBean res = null;
        userServiceImpl.deleteEmployee(epId);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.DELETE_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return res;
    }

    @ApiOperation(value = "获取员工列表", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public ResponseBean ListEmployee(@RequestBody QueryParameter queryParameter) {
        ResponseBean res = null;
        // List<User> employeesPage = userServiceImpl.listEmployee(orgId, marketId);
        Paging<User> paging = userCommonEntityService.findPagedEntity(queryParameter, User.class);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        res.getData().put("employees", paging);
        return res;
    }

    @RequestMapping(value = "/operation",method = RequestMethod.GET)
    public ResponseBean disabledEmployee(@RequestParam Integer epId,@RequestParam Integer status) {
        ResponseBean res = null;
        userServiceImpl.changeStatus(epId,status);
        res = ResponseUtil.createRespBean(true,200,"禁用成功");
        return res;
    }

//    @RequestMapping(value = "/active",method = RequestMethod.GET)
//    public ResponseBean activeEmployee(@RequestParam Integer epId) {
//        ResponseBean res = null;
//        userServiceImpl.active(epId);
//        res = ResponseUtil.createRespBean(true,200,"启用成功");
//        return res;
//    }
    @ApiOperation(value = "修改员工密码",notes = "" ,httpMethod = "POST")
    @RequestMapping(value = "/reset-password",method = RequestMethod.POST)
    public ResponseBean updateEmployeePassWorld(@RequestBody User user) {
        ResponseBean res = null;
        User newUser = (User) userCommonEntityService.update(user);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.RESET_PASSWORD_SUCCESS.getStatus(),
                StatusMsgEnum.RESET_PASSWORD_SUCCESS.getMsg());
        return res;
    }

    @ApiOperation(value = "角色批量赋权给员工", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/role/bat-add", method = RequestMethod.POST)
    public ResponseBean roleBatAdd(@RequestBody Role role) {
        ResponseBean res = null;
        userServiceImpl.roleAdd(role);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_ROLE_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_ROLE_SUCCESS.getMsg());
        return res;
    }

    @ApiOperation(value = "员工批量删除角色", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/role/bat-less", method = RequestMethod.POST)
    public ResponseBean roleBatLess(@RequestBody Role role) {
        ResponseBean res = null;
        userServiceImpl.roleBat(role);
        res = ResponseUtil.createRespBean(true,StatusMsgEnum.DELETE_ROLE_SUCCESS.getStatus(),StatusMsgEnum.DELETE_ROLE_SUCCESS.getMsg());
        return res;
    }

    @ApiOperation(value = "查询员工", notes = "根据员工id查询", httpMethod = "GET")
    @GetMapping(value = "/detail")
    public ResponseBean findById(@RequestParam Integer epId) {
        ResponseBean resp = null;
        User user = (User) this.userCommonEntityService.findById(User.class, epId);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("employee", user);
        return resp;
    }

    @ApiOperation(value = "通过手机查询会员信息", notes = "根据员工id查询", httpMethod = "GET")
    @GetMapping(value = "/queryMemberByPhone")
    public ResponseBean queryMemberByPhone(@RequestParam String phone, @RequestParam Integer mktId) {
        Customer customer = this.customerJPA.findByMktIdAndMobi(mktId, phone);
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "查询成功");
        if (customer != null) {
            success.getData().put("member", customer.getMember());
            return success;
        } else {
            success.setStatus(404);
            success.setMsg("不存在的会员");
        }
        return success;

    }

}
