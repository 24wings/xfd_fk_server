package com.fastsun.framework.controller;

// import com.alibaba.fastjson.JSON;
// import com.alibaba.fastjson.JSONObject;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.queryTemplate.MetaField;
import com.fastsun.framework.entity.queryTemplate.MetaObject;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.service.impl.queryTemplate.MetaFieldServiceImpl;
import com.fastsun.framework.service.impl.queryTemplate.MetaObjectServiceImpl;
import com.fastsun.framework.service.impl.queryTemplate.SqlEntityService;
import com.fastsun.market.utils.StatusMsgEnum;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import net.sf.json.JSONObject;
import net.sf.json.JSON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

// @Api(value = "fileSelect", description = "字段管理")
@Api(value = "开发者业务平台", description = "平台开发者制定的规范", tags = { "framework.MetaField" })
@RestController
@RequestMapping("/api/design")
public class MetaFieldController extends BaseController {

    @Autowired
    private MetaFieldServiceImpl metaFieldServiceImpl;

    @Autowired
    private MetaObjectServiceImpl metaObjectServiceImpl;
    @Autowired
    private SqlEntityService sqlEntityService;

    @ApiOperation(value = "获取SQL元数据", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/field", method = RequestMethod.POST)
    public ResponseBean getFields(HttpServletRequest request, HttpServletResponse response) {
        ResponseBean resp = null;
        BufferedReader streamReader = null;
        JSONObject json = null;
        try {
            streamReader = new BufferedReader(new InputStreamReader(request.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = streamReader.readLine()) != null) {
                sb.append(line);
            }
            json = JSONObject.fromObject(sb.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        String sql = (String) json.get("sql");
        // sqlEntityService.queryPageEntity(entityCode, queryParameter)
        List<JSONObject> fields = this.sqlEntityService.getFieldInfoBySql(sql);
        resp = ResponseUtil.createRespBean(true, 200, "");
        resp.getData().put("fields", fields);
        return resp;
    }

    @ApiOperation(value = "得到查询定义器定义的所有查询列表", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/getQueryList", method = RequestMethod.POST)
    public ResponseBean getQueryList(HttpServletRequest request, HttpServletResponse response) {
        ResponseBean resp = null;
        Map<String, List<MetaObject>> maps = this.metaObjectServiceImpl.findAllToMap();
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("map", maps);
        return resp;
    }

    @ApiOperation(value = "得到查询定义器定义的所有查询列表", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/getQueryDetail", method = RequestMethod.POST)
    public ResponseBean getQueryDetail(@RequestParam String objectCode) {
        ResponseBean resp = null;
        if (objectCode == null) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return resp;
        }
        List<MetaField> lists = this.metaFieldServiceImpl.findByObjectCode(objectCode);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("mataFiled", lists);
        return resp;
    }

}
