package com.fastsun.framework.controller;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.rbac.Menu;
import com.fastsun.framework.jpa.MenuJPA;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.bean.Paging;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(description = "菜单管理", tags = { "framework.Menu" })
@RestController
@RequestMapping(value = "/api/menu")
public class MenuController extends BaseController {

    @Autowired
    private CommonEntityService menuCommonEntityService;
    @Autowired
    private MenuJPA menuJPA;

    @ApiOperation(value = "创建菜单", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ResponseBean add(@RequestBody Menu menu) {
        ResponseBean resp = null;
        if (menu == null) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return resp;
        }
        Boolean flag = menuCommonEntityService.save(menu);
        if (flag) {
            resp = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                    StatusMsgEnum.ADD_SUCCESS.getMsg());
        } else {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_FAILED.getStatus(),
                    StatusMsgEnum.ADD_FAILED.getMsg());
        }
        return resp;
    }

    @ApiOperation(value = "获取菜单列表", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public ResponseBean listByMenuType(@RequestBody QueryParameter queryParameter) {
        ResponseBean resp = null;
        // List<Menu> menus = menuService.getMenuList(menuType);
        Paging<Menu> paging = menuCommonEntityService.findPagedEntity(queryParameter, Menu.class);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("menus", paging);
        return resp;
    }

    @ApiOperation(value = "修改菜单", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseBean update(@RequestBody Menu menu) {
        ResponseBean resp = null;
        Menu menuNew = (Menu) menuCommonEntityService.update(menu);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        resp.getData().put("menu", menuNew);
        return resp;
    }

    @ApiOperation(value = "删除菜单", notes = "", httpMethod = "Get")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseBean delete(@RequestParam Integer menuId) {
        ResponseBean resp = null;
        menuCommonEntityService.delete(Menu.class, menuId);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.DISABLED_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return resp;
    }

    @ApiOperation(value = "获取菜单详情", notes = "", httpMethod = "GET")
    @GetMapping(value = "/detail")
    public ResponseBean getOne(@RequestParam Integer menuId) {
        ResponseBean resp = null;
        Menu menu = (Menu) menuCommonEntityService.findById(Menu.class, new Integer(menuId));
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("menu", menu);
        return resp;

    }

    @ApiOperation(value = "获取菜单详情", notes = "", httpMethod = "GET")
    @GetMapping(value = "/getByMenuCode")
    public ResponseBean getByMenuCode(@RequestParam String menuCode) {
        ResponseBean resp = null;
        Menu menu = menuJPA.findByMenuCode(menuCode);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("menu", menu);
        return resp;
    }

}
