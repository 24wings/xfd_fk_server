package com.fastsun.framework.entity.rbac;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;


@Entity
@Table(name = "developer",uniqueConstraints = {@UniqueConstraint(columnNames = "devUserName")})
public class Developer implements Serializable {
      @Id
      @GeneratedValue(strategy = GenerationType.IDENTITY)
      private int devId;
      @NotBlank(message = "开发人员姓名不能为空")
      @Column(nullable = false,length = 30)
      private String devUserName;
      @NotBlank(message = "密码不能为空")
      @Column(nullable = false,length = 100)
      private String password;
      @Column(nullable = true,length = 200)
      private String passwordHash;
      private Timestamp createTime;
      private Timestamp updateTime;
      @Transient
      private List<String> authorities;
//      @ManyToMany(fetch = FetchType.EAGER)
//      @JoinTable(name = "menu",joinColumns = {@JoinColumn(name = "r_id")})
//      public List<Menu> menus;

      public Developer(){}

    public int getDevId() {
        return devId;
    }

    public void setDevId(int devId) {
        this.devId = devId;
    }

    public String getDevUserName() {
        return devUserName;
    }

    public void setDevUserName(String devUserName) {
        this.devUserName = devUserName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    public List<String> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(List<String> authorities) {
        this.authorities = authorities;
    }
}

