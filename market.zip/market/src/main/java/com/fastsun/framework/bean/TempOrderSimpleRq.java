package com.fastsun.framework.bean;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@NoArgsConstructor
public class TempOrderSimpleRq {
    String name;
    String orderNo;
    String phoneNo;
    String createTime;
}
