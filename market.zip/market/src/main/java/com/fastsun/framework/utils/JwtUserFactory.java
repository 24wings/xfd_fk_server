package com.fastsun.framework.utils;

import com.fastsun.framework.bean.JwtUser;
import com.fastsun.framework.entity.rbac.Developer;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.market.entity.member.Customer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.List;
import java.util.stream.Collectors;

public final class JwtUserFactory {

    private JwtUserFactory() {
    }

    public static JwtUser create(User ep) {
        return new JwtUser(ep.getUserName(), ep.getPassword(), mapToGranteAuthorities(ep.getAuthorities()));

    }

    public static JwtUser createDev(Developer developer) {
        return new JwtUser(developer.getDevUserName(), developer.getPassword(),
                mapToGranteAuthorities(developer.getAuthorities()));

    }

    public static JwtUser createCustomer(Customer customer) {
        return new JwtUser(customer.getMobi()+","+ customer.getMktId() +"#customer", customer.getPassword(),
                mapToGranteAuthorities(customer.getAuthorities()));

    }

    private static List<GrantedAuthority> mapToGranteAuthorities(List<String> authorities) {

        return authorities.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
    }

}
