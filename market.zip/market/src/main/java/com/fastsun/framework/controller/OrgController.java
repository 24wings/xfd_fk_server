package com.fastsun.framework.controller;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.rbac.Org;
import com.fastsun.framework.jpa.OrgJPA;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.controller.base.BaseController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import com.fastsun.market.utils.StatusMsgEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(description = "组织管理", tags = { "framework.Org" })
@RestController
@RequestMapping("/api/org")
public class OrgController extends BaseController {
    @Autowired
    private OrgJPA orgJPA;

    @Autowired
    private CommonEntityService orgCommonEntityService;

    @ApiOperation(value = "创建组织", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ResponseBean add(@RequestBody Org org) {
        ResponseBean resp = null;
        if (org == null) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return resp;
        }
        long count = this.orgJPA.findByOrgName(org.getOrgName()).size();
        if (count > 0) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_REPEAT.getStatus(),
                    StatusMsgEnum.ADD_REPEAT.getMsg());
            return resp;
        }
        boolean flag = this.orgCommonEntityService.save(org);
        if (flag) {
            resp = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                    StatusMsgEnum.ADD_SUCCESS.getMsg());
        } else {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_FAILED.getStatus(),
                    StatusMsgEnum.ADD_FAILED.getMsg());
        }
        return resp;
    }

    @ApiOperation(value = "获取组织列表", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public ResponseBean getAll(@RequestBody QueryParameter queryParameter) {
        ResponseBean resp = null;
        Paging<Org> paging = orgCommonEntityService.findPagedEntity(queryParameter, Org.class);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("orgs", paging);
        return resp;
    }

    @ApiOperation(value = "修改组织", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseBean update(@RequestBody Org org) {
        ResponseBean resp = null;
        Org orgDBNew = (Org)this.orgCommonEntityService.update(org);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        resp.getData().put("org", orgDBNew);
        return resp;
    }

    @ApiOperation(value = "删除组织", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseBean delete(@RequestParam Integer orgId) {
        ResponseBean resp = null;
        this.orgCommonEntityService.delete(Org.class, orgId);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.DELETE_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return resp;

    }

    @ApiOperation(value = "获取组织详情", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/detail", method = RequestMethod.GET)
    public ResponseBean getByOrgId(@RequestParam Integer orgId) {
        ResponseBean resp = null;
        Org org = (Org) this.orgCommonEntityService.findById(Org.class, orgId);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("org", org);
        return resp;
    }

    @ApiOperation(value = "分页", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/page", method = RequestMethod.POST)
    public ResponseBean getPage(@RequestBody QueryParameter queryParameter) {
        ResponseBean resp = null;
        // Page<Org> orgs =
        // this.orgServiceImpl.findAll(SimplePageBuilder.generate(page,pageSize,SimpleSortBuilder.generateSort("orgName")));
        Paging<Org> paging = this.orgCommonEntityService.findPagedEntity(queryParameter, Org.class);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("orgs", paging);
        return resp;
    }

}
