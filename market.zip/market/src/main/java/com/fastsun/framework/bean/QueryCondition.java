package com.fastsun.framework.bean;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class QueryCondition {

    private String field;
    private String compare;// compare 分类：> <
    private Object value;
    private String andOr;

    public QueryCondition() {
    }

    public QueryCondition(String field, String compare, Object value, String andOr) {
        this.field = field;
        this.compare = compare;
        this.value = value;
        this.andOr = andOr;
    }

    public String getAndOr() {
        return andOr;
    }

    public void setAndOr(String andOr) {
        this.andOr = andOr;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public String getCompare() {
        return compare;
    }

    public void setCompare(String compare) {
        this.compare = compare;
    }
}
