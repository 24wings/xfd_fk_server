package com.fastsun.framework.jpa;

import com.fastsun.framework.entity.rbac.Developer;
import com.fastsun.framework.jpa.base.BaseRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;


public interface DeveloperJPA extends BaseRepository<Developer,Integer>,JpaSpecificationExecutor<Developer> {

         Developer findByDevUserName(String devUserName);
}
