package com.fastsun.framework.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class CreatePrintJsonUtils {

    public  static String createPrintStr(String[] masterField, String[] detailField, List<JSONObject> masterData, List<JSONObject> detailData) {

        StringBuffer masterFieldBuff = new StringBuffer();
        masterFieldBuff.append("MasterFields:[");
        StringBuffer masterDataBuff = new StringBuffer();
        masterDataBuff.append("MasterData:[");
        String fieldName = null;
        String[] fieldNames = new String[masterField.length];
        for(int i=0;i<masterField.length;i++) {
            fieldName = "Field"+i;
            masterFieldBuff.append("{FieldName:\""+fieldName+"\",DisplayLabel:\""+masterField[i]+"\"},");
            fieldNames[i] = fieldName;
        }
        masterFieldBuff.deleteCharAt(masterFieldBuff.length()-1);
        masterFieldBuff.append("]");
        JSONObject obj1 = null ;
        for(int i=0;i<masterData.size();i++) {
            obj1 = masterData.get(i);
            masterDataBuff.append("{");
            for(int j=0;j<fieldNames.length;j++) {
                masterDataBuff.append(fieldNames[j]+ ":\"" + obj1.getString(fieldNames[j])+"\",");
            }
            masterDataBuff.deleteCharAt(masterDataBuff.length()-1);
            masterDataBuff.append("}");
        }
        masterDataBuff.append("]");
        //后半部分
        //String fieldName = null;
        //JSONObject obj1 = null ;
        StringBuffer detailFieldBuff = new StringBuffer();
        detailFieldBuff.append("DetailFields:[");
        StringBuffer detailDataBuff = new StringBuffer();
        detailDataBuff.append("DetailData:[");
        String[] detailFieldNames = new String[detailField.length];
        int index = masterField.length;
        for(int i=0;i<detailField.length;i++) {
            fieldName = "Field"+(i+index);
            detailFieldBuff.append("{FieldName:\""+fieldName+"\",DisplayLabel:\""+detailField[i]+"\"},");
            detailFieldNames[i] = fieldName;

        }
        detailFieldBuff.deleteCharAt(detailFieldBuff.length()-1);
        detailFieldBuff.append("]");

        for(int i=0;i<detailData.size();i++) {
            obj1 = detailData.get(i);
            detailDataBuff.append("{");
            for(int j=0;j<detailFieldNames.length;j++) {
                if(StringUtils.isEmpty(obj1.get(detailFieldNames[j]))){
                    detailDataBuff.append(detailFieldNames[j]+ ":\"" + ""+"\",");
                }else {
                    detailDataBuff.append(detailFieldNames[j]+ ":\"" + obj1.getString(detailFieldNames[j])+"\",");
                }
            }
            detailDataBuff.deleteCharAt(detailDataBuff.length()-1);
            detailDataBuff.append("},");
        }
        detailDataBuff.deleteCharAt(detailDataBuff.length()-1);
        detailDataBuff.append("]");


        //System.out.println(masterFieldBuff.toString());
        //System.out.println(masterDataBuff.toString());
        //System.out.println(detailFieldBuff.toString());
        //System.out.println(detailDataBuff.toString());
        return "{"+masterFieldBuff.toString()+ "," + masterDataBuff.toString() + "," + detailFieldBuff.toString() +"," + detailDataBuff.toString()+"}";
    }

    public static List<JSONObject> createDetailData(String jsonListStr,int startIndex,String[] detailFields,String[] dataIndex){
        JSONArray jsonArray = JSON.parseArray(jsonListStr);
        String[] fieldName = new String[detailFields.length];
        for(int i=0;i<detailFields.length;i++) {
            fieldName[i] = "Field"+(i+startIndex);
        }
        List<JSONObject> detailData = new ArrayList<JSONObject>();
        JSONObject object = null;
        JSONObject obj1 = null;
        for(int j =0;j<jsonArray.size();j++) {
            obj1 = jsonArray.getJSONObject(j);
            object = new JSONObject();
            for(int i =0;i<fieldName.length;i++) {

                object.put(fieldName[i], obj1.getString(dataIndex[i])== null?"":obj1.getString(dataIndex[i]));
            }
            detailData.add(object);
        }
        return detailData;
    }

    public static JSONObject  createMasterData(String jsonObjectStr,String[] dataIndex,String[] masterFields){
        String[] fieldName = new String[masterFields.length];
        for(int i=0;i<masterFields.length;i++) {
            fieldName[i] = "Field"+i;
        }
        JSONObject jsonObject = JSON.parseObject(jsonObjectStr);
        JSONObject masterData = new JSONObject();
        for(int i = 0; i<dataIndex.length; i++){
            masterData.put(fieldName[i], jsonObject.getString(dataIndex[i])== null?"":jsonObject.getString(dataIndex[i]));
        }
        return masterData;
    }


}
