package com.fastsun.framework.controller;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.market.entity.common.ProdCatalog;
import com.fastsun.market.entity.common.RecvPaySubject;
import com.fastsun.market.service.impl.ProdCatalogServiceImpl;
import com.fastsun.market.service.impl.SubjectServiceImpl;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(description = "平台开发者制定的规范", tags = { "framework.DeveloperManage" })
@RequestMapping("/api/dev")
@RestController
public class DeveloperManageController extends BaseController {

      private ResponseBean responseBean;

}
