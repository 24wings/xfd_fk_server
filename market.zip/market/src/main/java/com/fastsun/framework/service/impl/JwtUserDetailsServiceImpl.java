package com.fastsun.framework.service.impl;

import com.fastsun.framework.entity.rbac.Developer;
import com.fastsun.framework.entity.rbac.Role;
import com.fastsun.framework.entity.rbac.User;
import com.fastsun.market.entity.member.Customer;
import com.fastsun.market.jpa.CustomerJPA;
import com.fastsun.framework.jpa.DeveloperJPA;
import com.fastsun.framework.jpa.UserJPA;
import com.fastsun.framework.jpa.RoleJPA;
import com.fastsun.framework.utils.JwtUserFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class JwtUserDetailsServiceImpl implements UserDetailsService {
    @Autowired
    private UserJPA userJPA;
    @Autowired
    private DeveloperJPA developerJPA;
    @Autowired
    private RoleJPA roleJPA;
    @Autowired
    private CustomerJPA customerJPA;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        if (username.indexOf("#") < 0) {
            User user = userJPA.findByUserName(username);
            if (user != null) {
                if (user.getRoleIds() != null) {
                    List<String> list = new ArrayList<>();
                    String roleIds = user.getRoleIds();
                    String[] str = roleIds.split(",");
                    int[] ints = new int[str.length];
                    for (int i = 0; i < str.length; i++) {
                        ints[i] = Integer.parseInt(str[i]);
                    }
                    List<Role> roles = roleJPA.findByRoleIdIn(ints);
                    roles.stream().map(role -> list.add(role.getRoleCode())).collect(Collectors.toList());
                    user.setAuthorities(list);
                }
            } else {
                Developer developer = developerJPA.findByDevUserName(username);
                List<String> authorities = new ArrayList<>();
                authorities.add("ROLE_DEVELOPER");
                developer.setAuthorities(authorities);
                if (developer == null) {
                    throw new UsernameNotFoundException(String.format("输入用户未找到.", username));
                } else {
                    return JwtUserFactory.createDev(developer);
                }
            }
            if (user == null) {
                throw new UsernameNotFoundException(String.format("输入用户未找到 '%s'.", username));
            } else {
                return JwtUserFactory.create(user);
            }
        } else {
            String[] nameTypePair = username.split("#");
            String name = nameTypePair[0];
            String type = nameTypePair[1];
            switch (type) {
            case "customer":
                String[] strs = name.split(",");
                String mobi = strs[0];
                Customer customer = customerJPA.findByMktIdAndMobi(Integer.parseInt(strs[1]), mobi);
                List<String> authorities = new ArrayList<>();
                authorities.add("ROLE_CUSTOMER");
                customer.setAuthorities(authorities);
                if (customer == null) {
                    throw new UsernameNotFoundException(String.format("输入App用户未找到.", mobi));
                } else {
                    return JwtUserFactory.createCustomer(customer);
                }

            }
            return null;
        }

    }
}
