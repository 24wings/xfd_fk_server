package com.fastsun.framework.controller;

import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.rbac.Developer;
import com.fastsun.framework.entity.rbac.Menu;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.bean.RequestBean;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.jpa.DeveloperJPA;
import com.fastsun.framework.jpa.MenuJPA;
import com.fastsun.framework.jpa.base.SimplePageBuilder;
import com.fastsun.framework.jpa.base.SimpleSortBuilder;
import com.fastsun.framework.utils.JwtTokenUtil;
import com.fastsun.market.entity.common.ProdCatalog;
import com.fastsun.market.entity.common.RecvPaySubject;
import com.fastsun.market.utils.StatusMsgEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.List;

@Api(description = "开发者管理", tags = { "framework.Developer" })
@RestController
@RequestMapping("/dev")
// @PreAuthorize("hasRole('ROLE_ADMIN')")
public class DeveloperController extends BaseController {

    private static final Logger LOGGER = LogManager.getLogger(DeveloperController.class);
    private ResponseBean responseBean;
    @Autowired
    private DeveloperJPA developerJPA;

    @Autowired
    private MenuJPA menuJPA;
    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;
    //
    // public ResponseBean login(@RequestParam("username") String
    // username,@RequestParam("password") String password){
    // UsernamePasswordAuthenticationToken upToken = new
    // UsernamePasswordAuthenticationToken(username, password);
    // Authentication authentication = authenticationManager.authenticate(upToken);
    // SecurityContextHolder.getContext().setAuthentication(authentication);
    // UserDetails userDetails = userDetailsService.loadUserByUsername(username);
    // ResponseBean resp = new ResponseBean();
    // resp.setStatus(0);
    // resp.setMsg("Logined Successfully!");
    // resp.setData(jwtTokenUtil.generateToken(userDetails));
    // return resp;
    // }

    @ApiOperation(value = "开发者登录", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/login", produces = "application/json", method = RequestMethod.POST)
    public ResponseBean login(@RequestBody RequestBean requestBean) {
        UsernamePasswordAuthenticationToken upToken = new UsernamePasswordAuthenticationToken(requestBean.getUserName(),
                requestBean.getPassword());
        Authentication authentication = authenticationManager.authenticate(upToken);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        UserDetails userDetails = userDetailsService.loadUserByUsername(requestBean.getUserName());
        final String token = jwtTokenUtil.generateToken(userDetails.getUsername(), "developer");
        Developer dev = developerJPA.findByDevUserName(requestBean.getUserName());
        ResponseBean resp = null;
        if (dev == null) {
            resp = ResponseUtil.createRespBean(false, 100, "Logining error!Not Found The developer!");
            return resp;
        }
        // if(!requestBean.getPassword().equals(dev.getPassword())){
        //
        // resp = ResponseUtil.createRespBean(false,101,"Logining error!Username or
        // password is error!");
        // return resp;
        // }
        resp = ResponseUtil.createRespBean(true, 200, "Logined Successfully!");
        // jwtTokenUtil.generateToken(dev.getDev_name());
        resp.getData().put("dev", dev);
        List<Menu> menus = menuJPA.findAll();
        resp.getData().put("menus", menus);
        resp.getData().put("token", token);
        return resp;

    }

    @ApiOperation(value = "新增开发者", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ResponseBean addDeveloper(@RequestBody Developer developer) {
        ResponseBean res = null;
        if (developer == null) {
            res = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return res;
        }
        developer.setCreateTime(new Timestamp(System.currentTimeMillis()));
        developer.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        developer.setPassword(passwordEncoder.encode(developer.getPassword()));
        Developer de = developerJPA.save(developer);
        res = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        res.getData().put("developer", de);
        return res;
    }

    @ApiOperation(value = "修改开发者", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseBean updateDeveloper(@RequestBody Developer developer) {
        ResponseBean res = null;
        Developer oldDeveloper = developerJPA.findById(developer.getDevId()).get();
        ResponseUtil.mergeObject(developer, oldDeveloper);
        oldDeveloper.setPassword(passwordEncoder.encode(oldDeveloper.getPassword()));
        Developer newDeveloper = developerJPA.saveAndFlush(oldDeveloper);
        res = ResponseUtil.createRespBean(true, 200, "");
        return res;
    }

    @ApiOperation(value = "删除开发者", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseBean deleteDeveloper(@RequestParam Integer devId) {
        ResponseBean res = null;
        if (devId == null) {
            res = ResponseUtil.createRespBean(false, 103, "The parameters is null!");
        }
        try {
            developerJPA.deleteById(devId);
        } catch (Exception e) {
            e.printStackTrace();
            res = ResponseUtil.createRespBean(false, 102, "delete Not successfully!");
            return res;
        }
        res = ResponseUtil.createRespBean(true, 200, "delete  successfully!");
        return res;
    }

    @ApiOperation(value = "获取开发者分页", notes = "", httpMethod = "GET")
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    public ResponseBean listDeveloper(@RequestParam(value = "page", defaultValue = "0") Integer page,
            @RequestParam Integer pageSize) {
        Pageable pageable = SimplePageBuilder.generate(page, pageSize, SimpleSortBuilder.generateSort("devId"));
        Page<Developer> developerPage = developerJPA.findAll(pageable);
        ResponseBean res = ResponseUtil.createRespBean(true, 200, "find Successfully");
        Paging<Developer> paging = new Paging<>();
        paging.setCount(developerPage.getTotalElements());
        paging.setRows(developerPage.getContent());
        res.getData().put("developers", paging);
        return res;
    }

    public ResponseBean register(@RequestBody Developer dev) {
        developerJPA.save(dev);
        return new ResponseBean();
    }

    @Autowired
    private CommonEntityService recvPaySubjectCommonEntityService;
    @Autowired
    private CommonEntityService prodCatalogCommonEntityService;

    @ApiOperation(value = "新增固定收支科目", notes = "平台开发者新增固定收支科目", httpMethod = "POST")
    @PostMapping(value = "/subject/create")
    public ResponseBean createSubject(@RequestBody RecvPaySubject subject) {
        Boolean subjectDB = this.recvPaySubjectCommonEntityService.save(subject);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        responseBean.getData().put("subject", subjectDB);
        return responseBean;
    }

    @ApiOperation(value = "更新固定收支科目", notes = "", httpMethod = "POST")
    @PostMapping(value = "/subject/update")
    public ResponseBean updateSubject(@RequestBody RecvPaySubject subject) {
        RecvPaySubject subjectDB = (RecvPaySubject) this.recvPaySubjectCommonEntityService.update(subject);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        responseBean.getData().put("subject", subjectDB);
        return responseBean;
    }

    @ApiOperation(value = "新建商品品类", notes = "开发者新建国标品类", httpMethod = "POST")
    @PostMapping(value = "/category/create")
    public ResponseBean createCategory(@RequestBody ProdCatalog category) {
        boolean categoryDB = this.prodCatalogCommonEntityService.save(category);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        responseBean.getData().put("category", categoryDB);
        return responseBean;
    }

    @ApiOperation(value = "更新商品品类", notes = "", httpMethod = "POST")
    @PostMapping(value = "/category/update")
    public ResponseBean updateCategory(@RequestBody ProdCatalog category) {
        ProdCatalog categoryDB = (ProdCatalog) this.prodCatalogCommonEntityService.update(category);
        responseBean = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        responseBean.getData().put("category", categoryDB);
        return responseBean;
    }

}
