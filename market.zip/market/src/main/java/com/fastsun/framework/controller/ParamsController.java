package com.fastsun.framework.controller;

import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.jpa.ParamsJPA;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.bean.Paging;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.entity.sysConfig.Params;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import com.fastsun.market.utils.StatusMsgEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(description = "配置参数管理", tags = { "framework.Params" })
@RestController
@RequestMapping("/api/param")
public class ParamsController extends BaseController {

    @Autowired
    private ParamsJPA paramsJPA;

    @Autowired
    private CommonEntityService paramsCommonEntityService;

    @ApiOperation(value = "创建配置参数", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ResponseBean add(@RequestBody Params params) {
        ResponseBean resp = null;
        if (params == null) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.PARAM_NULL.getStatus(),
                    StatusMsgEnum.PARAM_NULL.getMsg());
            return resp;
        }
        long count = this.paramsJPA.findByParamKey(params.getParamKey()).size();
        if (count > 0) {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_REPEAT.getStatus(),
                    StatusMsgEnum.ADD_REPEAT.getMsg());
            return resp;
        }
        Boolean flag = this.paramsCommonEntityService.save(params);
        if (flag) {
            resp = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                    StatusMsgEnum.ADD_SUCCESS.getMsg());
        } else {
            resp = ResponseUtil.createRespBean(false, StatusMsgEnum.ADD_FAILED.getStatus(),
                    StatusMsgEnum.ADD_FAILED.getMsg());
        }
        return resp;
    }

    @ApiOperation(value = "修改配置参数", notes = "", httpMethod = "POST")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseBean update(@RequestBody Params params) {
        ResponseBean resp = null;
        Params paramsDBNew = (Params) this.paramsCommonEntityService.update(params);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        resp.getData().put("param", paramsDBNew);
        return resp;
    }

    @ApiOperation(value = "删除配置参数", notes = "", httpMethod = "Get")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseBean delete(@RequestParam Integer id) {
        ResponseBean resp = null;
        this.paramsCommonEntityService.delete(Params.class, id);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.DELETE_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return resp;
    }

    @ApiOperation(value = "获取配置参数列表", notes = "", httpMethod = "Post")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public ResponseBean getParamsPage(@RequestBody QueryParameter queryParameter) {
        ResponseBean resp = null;
        Paging<Params> paging = this.paramsCommonEntityService.findPagedEntity(queryParameter, Params.class);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("paging", paging);
        return resp;
    }

    @ApiOperation(value = "通过市场id和参数名获取配置参数", notes = "", httpMethod = "Post")
    @PostMapping(value = "/getByName")
    public ResponseBean getOneParams(@RequestBody QueryParameter queryParameter) {
        ResponseBean resp = null;
        Paging<Params> paging = this.paramsCommonEntityService.findPagedEntity(queryParameter, Params.class);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("paging", paging);
        return resp;
    }
}
