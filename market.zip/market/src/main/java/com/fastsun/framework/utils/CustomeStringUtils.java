package com.fastsun.framework.utils;



import java.util.List;

public class CustomeStringUtils
{
    /**
     * List<String> 转String
     * */
    public static String listToString(List<String> list)
    {
        if(list==null)
        {
            return null;
        }
        StringBuilder result = new StringBuilder();
        boolean first = true;
        //第一个前面不拼接","
        for(String string :list)
        {
            if(first)
            {
                first=false;
            }
            else
            {
                result.append(",");
            }
            result.append(string);
        }
        return result.toString();
    }

}
