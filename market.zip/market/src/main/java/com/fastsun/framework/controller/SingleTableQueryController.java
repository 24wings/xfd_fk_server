package com.fastsun.framework.controller;

import com.fastsun.framework.bean.MetaObjectDataRq;
import com.fastsun.framework.bean.QueryParameter;
import com.fastsun.framework.bean.ResponseBean;
import com.fastsun.framework.entity.queryTemplate.MetaObject;
import com.fastsun.framework.service.impl.CommonEntityService;
import com.fastsun.framework.utils.ResponseUtil;
import com.fastsun.framework.controller.base.BaseController;
import com.fastsun.framework.bean.Paging;
import com.fastsun.market.utils.StatusMsgEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import net.sf.json.JSONObject;

@Api(description = "角色管理", tags = { "framework.SingleTableQuery" })
@RestController
@RequestMapping("/app/stq")
public class SingleTableQueryController extends BaseController {
    @Autowired
    CommonEntityService commonEntityService;

    @ApiOperation(value = "单表查询", notes = "", httpMethod = "Post")
    @PostMapping(value = "/query")
    public ResponseBean query(@RequestParam String className, @RequestBody QueryParameter queryParameter)
            throws Exception {
        Paging paging = commonEntityService.findPagedEntity(queryParameter, className);
        ResponseBean success = ResponseUtil.createRespBean(true, 200, "成功");
        success.getData().put("paging", paging);
        return success;
    }

    @ApiOperation(value = "获取Entity元数据详情", notes = "", httpMethod = "GET")
    @GetMapping(value = "/entity/meta")
    public ResponseBean getEntityMeta(@RequestParam String className) {
        ResponseBean resp = null;
        try {
            MetaObject metaObject = commonEntityService.getEntityMetaObject(className);
            resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                    StatusMsgEnum.QUERY_SUCCESS.getMsg());
            resp.getData().put("metaObject", metaObject);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return resp;
    }

    @ApiOperation(value = "获取Entity查询数据分页", notes = "", httpMethod = "POST")
    @PostMapping(value = "/entity/query")
    public ResponseBean queryEntity(@RequestParam String className, @RequestBody QueryParameter queryParameter)
            throws Exception {
        ResponseBean resp = null;
        Paging pagedEntity = commonEntityService.findPagedEntity(queryParameter, className);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.QUERY_SUCCESS.getStatus(),
                StatusMsgEnum.QUERY_SUCCESS.getMsg());
        resp.getData().put("result", pagedEntity);
        return resp;
    }

    @ApiOperation(value = "更新Entity的数据", notes = "", httpMethod = "POST")
    @PostMapping(value = "/entity/update")
    public ResponseBean updataEntity(@RequestBody MetaObjectDataRq metaObjectDataRq) throws ClassNotFoundException {
        ResponseBean resp = null;
        String entityCode = metaObjectDataRq.getMetaObject().getObjectCode();
        String keyField = metaObjectDataRq.getMetaObject().getPkKey();
        JSONObject data = metaObjectDataRq.getDataItem();
        Object entity = JSONObject.toBean(data, Class.forName(entityCode));
        commonEntityService.update(entity);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.UPDATE_SUCCESS.getStatus(),
                StatusMsgEnum.UPDATE_SUCCESS.getMsg());
        return resp;
    }

    @ApiOperation(value = "插入Entity的数据", notes = "", httpMethod = "POST")
    @PostMapping(value = "/entity/insert")
    public ResponseBean insertEntity(@RequestBody MetaObjectDataRq metaObjectDataRq) throws ClassNotFoundException {
        ResponseBean resp = null;
        String entityCode = metaObjectDataRq.getMetaObject().getObjectCode();
        String keyField = metaObjectDataRq.getMetaObject().getPkKey();
        JSONObject data = metaObjectDataRq.getDataItem();
        Object entity = JSONObject.toBean(data, Class.forName(entityCode));
        commonEntityService.save(entity);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.ADD_SUCCESS.getStatus(),
                StatusMsgEnum.ADD_SUCCESS.getMsg());
        return resp;
    }

    @ApiOperation(value = "删除Entity的数据", notes = "", httpMethod = "POST")
    @PostMapping(value = "/entity/delete")
    public ResponseBean deleteEntity(@RequestBody MetaObjectDataRq metaObjectDataRq) throws ClassNotFoundException {
        ResponseBean resp = null;
        String entityCode = metaObjectDataRq.getMetaObject().getObjectCode();
        String keyField = metaObjectDataRq.getMetaObject().getPkKey();
        JSONObject data = metaObjectDataRq.getDataItem();
        Object entity = commonEntityService.findById(entityCode, data.getInt(keyField));
        commonEntityService.delete(entity);
        resp = ResponseUtil.createRespBean(true, StatusMsgEnum.DELETE_SUCCESS.getStatus(),
                StatusMsgEnum.DELETE_SUCCESS.getMsg());
        return resp;
    }

}