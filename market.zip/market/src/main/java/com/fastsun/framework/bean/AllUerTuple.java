package com.fastsun.framework.bean;

public class AllUerTuple<Developer, User, Customer> {

    public final Developer first;
    public final User second;
    public final Customer three;

    public AllUerTuple(Developer first, User second, Customer three) {
        this.first = first;
        this.second = second;
        this.three = three;
    }
}
