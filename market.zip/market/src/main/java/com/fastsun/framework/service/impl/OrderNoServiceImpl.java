package com.fastsun.framework.service.impl;

import com.fastsun.market.entity.common.OrderNo;
import com.fastsun.market.jpa.OrderNoJPA;
import com.fastsun.framework.utils.SexyLockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderNoServiceImpl {

    @Autowired
    private SexyLockUtil sexyLockUtil;

    @Autowired
    private OrderNoJPA orderNoJPA;

    @Autowired
    private CommonEntityService orderNoCommonEntityService;

    public Integer getOrderNo(String key){
        Integer number = 1;
        SexyLockUtil.KeyLocker keyLocker = sexyLockUtil.getKeyLocker(key);
        keyLocker.lock();// 锁key
        OrderNo orderNo = this.orderNoJPA.findByCurrentKey(key);
        if (orderNo != null) {
            number = orderNo.getCurrentValue();
            number++;
            orderNo.setCurrentValue(number);
            this.orderNoCommonEntityService.update(orderNo);
        }else{
            orderNo = new OrderNo();
            orderNo.setCurrentKey(key);
            orderNo.setCurrentValue(number);
            this.orderNoJPA.save(orderNo);
        }
        keyLocker.unlock();// 解锁key
        return number;
    }
}
