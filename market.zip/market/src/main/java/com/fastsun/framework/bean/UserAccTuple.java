package com.fastsun.framework.bean;

public class UserAccTuple<User,Account> {

    public final User first;
    public final Account second;
    public UserAccTuple(User first,Account second){
        this.first = first;
        this.second = second;
    }
}
