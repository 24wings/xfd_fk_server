scp -P 28489  ./build/libs/demo.jar root@104.224.150.203:/

scp   ./build/libs/demo.jar root@47.105.77.239:/
