package com.fastsun.xfd.entity.enums;

public enum OrderStatusEnum {
    UNSUBMITTED, SUBMITTED, CONFIRMED, DEPOSIT_PAID, ALL_PAID, TICKET_OUT, CANCELED
}