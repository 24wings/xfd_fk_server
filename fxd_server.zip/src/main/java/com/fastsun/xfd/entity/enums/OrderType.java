package com.fastsun.xfd.entity.enums;

public enum OrderType {
    TRANS, // 交易
    RECHARGE, // 充值
    CLEAR; // 清零
}
