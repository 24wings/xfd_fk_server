scp -P 28489  ./build/libs/demo.jar root@104.224.150.203:/
47.95.203.108
scp   ./build/libs/demo.jar root@47.105.77.239:/

 !*@&#%$N1N

 /usr/local/share/applications/xfd_fk


 scp ./demo.jar root@47.95.203.108:/usr/local/share/applications/xfd_fk